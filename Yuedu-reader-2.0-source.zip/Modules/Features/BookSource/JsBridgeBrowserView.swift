import SwiftUI
import WebKit
import Combine
import ObjectiveC

/// Paragraph-review sheets deliberately use only the source page's own UI.
/// Login and other source browsers keep `JsBridgeBrowserView`'s normal toolbar.
enum ParagraphReviewBrowserPresentationPolicy {
    static let hidesToolbar = true
}

struct SourceBrowserPresentationConfiguration: Equatable {
    var heightPercentage: Double?
    var skipCollapsed = false
    var isHideable = true
    var expandedCornersRadius: Double?

    init(json: String) {
        guard let data = json.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return
        }
        if let value = object["heightPercentage"] as? NSNumber,
           value.doubleValue > 0,
           value.doubleValue <= 1 {
            heightPercentage = value.doubleValue
        }
        if let value = object["skipCollapsed"] as? Bool { skipCollapsed = value }
        if let value = object["isHideable"] as? Bool { isHideable = value }
        if let value = object["expandedCornersRadius"] as? NSNumber,
           value.doubleValue >= 0,
           value.doubleValue <= 120 {
            expandedCornersRadius = value.doubleValue
        }
        // `hardwareAccelerated` is accepted as a no-op: WKWebView already uses
        // accelerated compositing and iOS exposes no per-page switch for it.
    }

    var detents: Set<PresentationDetent> {
        guard let heightPercentage else { return [.medium, .large] }
        let expanded: PresentationDetent = heightPercentage >= 1
            ? .large
            : .fraction(heightPercentage)
        return skipCollapsed ? [expanded] : [.medium, expanded]
    }
}

// Modal WebView launched by `java.startBrowser` / `java.startBrowserAwait`.
// Shows a loading state (spinner + top progress bar) while the page loads so
// slow login/key servers don't appear as a frozen blank sheet, plus an error
// state with retry. Syncs WKWebView cookies into CookieStore and
// HTTPCookieStorage when the user taps "Done" (and on each navigation finish).

struct JsBridgeBrowserView: View {
    let urlString: String
    let title: String
    let onDismiss: (_ body: String?) -> Void
    let hidesToolbar: Bool
    let initialHTML: String?
    let initialRequest: URLRequest?
    let injectedJavaScript: String
    let sourceRunHandler: ((String) async throws -> String)?
    let sourceConfigurationUpdateHandler: ((String) -> Void)?
    /// The source's User-Agent. Legado opens a source's page with it, and Cloudflare ties
    /// `cf_clearance` to the User-Agent that solved the challenge: cleared under any other,
    /// the cookie is useless to the source's own requests. nil keeps `SourceWebIdentity`.
    let userAgent: String?
    /// Legado's `sourceVerificationEnable` (a page `java.startBrowserAwait` waits for): once
    /// a Cloudflare challenge on the page clears, the page finishes as if ✓ were tapped.
    let finishesWhenChallengeClears: Bool

    init(
        urlString: String,
        title: String = "",
        hidesToolbar: Bool = false,
        initialHTML: String? = nil,
        initialRequest: URLRequest? = nil,
        injectedJavaScript: String = "",
        sourceRunHandler: ((String) async throws -> String)? = nil,
        sourceConfigurationUpdateHandler: ((String) -> Void)? = nil,
        userAgent: String? = nil,
        finishesWhenChallengeClears: Bool = false,
        onDismiss: @escaping (_ body: String?) -> Void
    ) {
        self.urlString = urlString
        self.title = title
        self.hidesToolbar = hidesToolbar
        self.initialHTML = initialHTML
        self.initialRequest = initialRequest
        self.injectedJavaScript = injectedJavaScript
        self.sourceRunHandler = sourceRunHandler
        self.sourceConfigurationUpdateHandler = sourceConfigurationUpdateHandler
        self.userAgent = userAgent
        self.finishesWhenChallengeClears = finishesWhenChallengeClears
        self.onDismiss = onDismiss
    }

    @StateObject private var bridge = JsBridgeBrowserBridge()
    @State private var isSyncing = false

    private var navTitle: String { title.isEmpty ? localized("瀏覽器") : title }

    var body: some View {
        if hidesToolbar {
            contentView
        } else {
            NavigationStack {
                contentView
                    .navigationTitle(navTitle)
                    .toolbarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button {
                                // XHR-based login can set cookies after the last
                                // navigation finished. Persist that final jar even
                                // on cancellation; nil still tells source JS that
                                // the browser was dismissed without confirmation.
                                isSyncing = true
                                guard let sync = bridge.syncCookiesAndDismiss else {
                                    onDismiss(nil)
                                    return
                                }
                                sync { _ in onDismiss(nil) }
                            } label: {
                                Label(localized("取消"), systemImage: "xmark")
                                    .labelStyle(.iconOnly)
                            }
                            .accessibilityLabel(localized("取消"))
                            .disabled(isSyncing)
                        }
                        // The page's own address, after its redirects and the reader's taps:
                        // what a reader debugging the source's rules pastes into 調試規則.
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button {
                                SourceWebPage.copy(bridge.currentURL?.absoluteString ?? urlString)
                            } label: {
                                Label(localized("複製網址"), systemImage: "doc.on.doc")
                                    .labelStyle(.iconOnly)
                            }
                            .accessibilityLabel(localized("複製網址"))
                        }
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button {
                                bridge.reload?()
                            } label: {
                                Label(localized("網頁：重新整理"), systemImage: "arrow.clockwise")
                                    .labelStyle(.iconOnly)
                            }
                            .accessibilityLabel(localized("網頁：重新整理"))
                            .disabled(isSyncing)
                        }
                        ToolbarItem(placement: .navigationBarTrailing) {
                            if isSyncing {
                                ProgressView().scaleEffect(0.85)
                            } else {
                                Button {
                                    confirm()
                                } label: {
                                    Label(localized("完成"), systemImage: "checkmark")
                                        .labelStyle(.iconOnly)
                                }
                                .accessibilityLabel(localized("完成"))
                            }
                        }
                    }
                    .onChange(of: bridge.challengeCleared) { _, cleared in
                        if cleared, !isSyncing { confirm() }
                    }
            }
        }
    }

    /// ✓: keep the page's cookies and hand its HTML back.
    private func confirm() {
        isSyncing = true
        guard let sync = bridge.syncCookiesAndDismiss else {
            onDismiss(nil)
            return
        }
        sync { body in onDismiss(body) }
    }

    private var contentView: some View {
        ZStack(alignment: .top) {
            JsBridgeBrowserRepresentable(
                urlString: urlString,
                initialHTML: initialHTML,
                injectedJavaScript: injectedJavaScript,
                sourceRunHandler: sourceRunHandler,
                sourceConfigurationUpdateHandler: sourceConfigurationUpdateHandler,
                bridge: bridge,
                initialRequest: initialRequest,
                userAgent: userAgent,
                finishesWhenChallengeClears: finishesWhenChallengeClears
            )
                .edgesIgnoringSafeArea(hidesToolbar ? .all : [])

            // Full-screen state until the page has drawn its first content. Not lifted at
            // commit: until the page paints, WebKit shows its own white, which is all a 段評
            // sheet over a dark reader showed while the page's synchronous `java.ajax` ran
            // (#21, #54, #55).
            switch bridge.phase {
            case .loading, .committed:
                loadingOverlay
            case .failed:
                errorOverlay
            case .painted, .finished:
                EmptyView()
            }

            // Safari-style thin progress bar across the top while loading.
            if bridge.phase != .failed, bridge.phase != .finished, bridge.progress < 1 {
                ProgressView(value: max(bridge.progress, 0.03))
                    .progressViewStyle(.linear)
                    .tint(DSColor.accent)
                    .transition(.opacity)
            }
        }
        .animation(DSAnimation.fast, value: bridge.phase)
        .animation(DSAnimation.fast, value: bridge.progress)
    }

    // MARK: - Overlays

    private var loadingOverlay: some View {
        ZStack {
            DSColor.background.ignoresSafeArea()
            VStack(spacing: DSSpacing.md) {
                ProgressView()
                    .controlSize(.large)
                Text(localized("載入中…"))
                    .font(DSFont.subheadline)
                    .foregroundStyle(DSColor.textSecondary)
            }
        }
        .transition(.opacity)
    }

    private var errorOverlay: some View {
        ZStack {
            DSColor.background.ignoresSafeArea()
            VStack(spacing: DSSpacing.md) {
                Image(systemName: "wifi.exclamationmark")
                    .font(DSFont.largeTitle)
                    .foregroundStyle(DSColor.textSecondary)
                Text(localized("載入失敗"))
                    .font(DSFont.headline)
                    .foregroundStyle(DSColor.textPrimary)
                if let detail = bridge.errorText, !detail.isEmpty {
                    Text(detail)
                        .font(DSFont.caption)
                        .foregroundStyle(DSColor.textSecondary)
                        .multilineTextAlignment(.center)
                }
                Button(localized("重試")) { bridge.reload?() }
                    .buttonStyle(.bordered)
                    .tint(DSColor.accent)
            }
            .padding(DSSpacing.lg)
        }
        .transition(.opacity)
    }
}

/// Presents a decoded paragraph-review target. Source-authored pages keep the same native
/// sheet/browser shell as ordinary review URLs, but receive the `window.run` bridge they need
/// to call back into their own shared Legado runtime.
struct LegadoReviewBrowserView: View {
    let target: ReaderHTMLUtilities.ReviewTarget
    let onDismiss: (_ body: String?) -> Void
    @State private var configurationJSON: String

    init(
        target: ReaderHTMLUtilities.ReviewTarget,
        onDismiss: @escaping (_ body: String?) -> Void
    ) {
        self.target = target
        self.onDismiss = onDismiss
        _configurationJSON = State(initialValue: target.sourceBrowserPage?.configurationJSON ?? "")
    }

    var body: some View {
        Group {
            if let page = target.sourceBrowserPage {
            JsBridgeBrowserView(
                urlString: page.baseURL,
                title: target.title,
                hidesToolbar: ParagraphReviewBrowserPresentationPolicy.hidesToolbar,
                initialHTML: page.html,
                initialRequest: target.browserRequest,
                injectedJavaScript: page.injectedJavaScript,
                sourceRunHandler: { script in
                    try await LegadoReviewActionRunner.shared.runSourcePageScript(
                        script,
                        sourceURL: page.sourceURL,
                        actionContext: page.actionContext
                    )
                },
                sourceConfigurationUpdateHandler: { configurationJSON = $0 },
                onDismiss: onDismiss
            )
            } else {
                JsBridgeBrowserView(
                    urlString: target.url,
                    title: target.title,
                    hidesToolbar: ParagraphReviewBrowserPresentationPolicy.hidesToolbar,
                    initialRequest: target.browserRequest,
                    onDismiss: onDismiss
                )
            }
        }
        .presentationDetents(presentationConfiguration.detents)
        .presentationDragIndicator(
            presentationConfiguration.skipCollapsed ? .hidden : .visible
        )
        .interactiveDismissDisabled(!presentationConfiguration.isHideable)
        .presentationCornerRadius(
            presentationConfiguration.expandedCornersRadius.map { CGFloat($0) }
        )
    }

    private var presentationConfiguration: SourceBrowserPresentationConfiguration {
        SourceBrowserPresentationConfiguration(
            json: configurationJSON
        )
    }
}

// MARK: - JsBridgeBrowserBridge

@MainActor
final class JsBridgeBrowserBridge: @MainActor ObservableObject {
    enum Phase {
        case loading
        /// The page's document has replaced the last one, but nothing of it is drawn yet.
        case committed
        /// The parsed document has been drawn; subresources may still be loading.
        case painted
        case finished
        case failed
    }

    var syncCookiesAndDismiss: ((@escaping (String?) -> Void) -> Void)?
    var reload: (() -> Void)?

    @Published var progress: Double = 0
    /// The web view's current page; nil until its first navigation starts.
    @Published var currentURL: URL?
    @Published var phase: Phase = .loading
    @Published var errorText: String?
    /// A Cloudflare challenge on the page has cleared (see `finishesWhenChallengeClears`).
    @Published var challengeCleared = false
}

// MARK: - UIViewRepresentable

struct JsBridgeBrowserRepresentable: UIViewRepresentable {
    let urlString: String
    let initialHTML: String?
    let injectedJavaScript: String
    let sourceRunHandler: ((String) async throws -> String)?
    let sourceConfigurationUpdateHandler: ((String) -> Void)?
    let bridge: JsBridgeBrowserBridge
    var initialRequest: URLRequest? = nil
    var userAgent: String? = nil
    var finishesWhenChallengeClears = false

    static let sourceJavaPromptName = SourceWebUIDelegate.sourceBridgePromptName

    static func sourcePageBootstrap(injectedJavaScript: String) -> String {
        let unavailableMessage = javaScriptStringLiteral(
            localized("段評執行環境不可用")
        )
        return """
        window.java = window.java || {};
        window.cache = window.cache || {};
        window.source = window.source || {};
        (function () {
            if (window.java.__yueduSourceNetworkInstalled) return;
            function callNative(method, args) {
                var payload = JSON.stringify({
                    method: method,
                    arguments: Array.prototype.slice.call(args)
                });
                var value = window.prompt('\(sourceJavaPromptName)', payload);
                if (value === null) {
                    throw new Error(\(unavailableMessage) + ': java.' + method);
                }
                return value;
            }
            ['ajax', 'get', 'post', 'head', 'connect', 'upConfig'].forEach(function (method) {
                Object.defineProperty(window.java, method, {
                    configurable: true,
                    value: function () { return callNative(method, arguments); }
                });
            });
            window.java.__yueduSourceNetworkInstalled = true;
        })();
        window.run = function (script) {
            return window.webkit.messageHandlers.\(Coordinator.sourceRunMessageName)
                .postMessage(String(script == null ? '' : script));
        };
        \(injectedJavaScript)
        """
    }

    private static func javaScriptStringLiteral(_ value: String) -> String {
        guard let data = try? JSONEncoder().encode(value),
              let encoded = String(data: data, encoding: .utf8) else {
            return "\"\""
        }
        return encoded
    }

    /// Android exposes `upConfig` on `WebJsExtensions`, not on the parser's
    /// `JsExtensions`. A source-authored page calls it to update the active
    /// four-argument `showBrowser` sheet configuration (for example, resizing a
    /// comments panel after it has measured its content).
    static func sourceConfigurationJSON(forPromptPayload payload: String) throws -> String? {
        guard payload.utf8.count <= 256 * 1024,
              let data = payload.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let method = object["method"] as? String else {
            throw sourcePageBridgeError()
        }
        guard method == "upConfig" else { return nil }
        guard let arguments = object["arguments"] as? [Any],
              arguments.count == 1,
              let configurationJSON = arguments[0] as? String,
              configurationJSON.utf8.count <= 64 * 1024,
              let configurationData = configurationJSON.data(using: .utf8),
              (try? JSONSerialization.jsonObject(with: configurationData)) is [String: Any] else {
            throw sourcePageBridgeError()
        }
        return configurationJSON
    }

    private static func sourcePageBridgeError() -> NSError {
        NSError(
            domain: "SourcePageJavaBridge",
            code: 1,
            userInfo: [NSLocalizedDescriptionKey: localized("段評執行環境不可用")]
        )
    }

    /// Turns a bounded WebView request into source-runtime JS. Only Android's browser-page
    /// network surface is accepted; the method name is never interpolated before allowlisting,
    /// and argument JSON is re-encoded before it reaches JavaScriptCore. The evaluated call then
    /// travels through the same `ModernParserBridge` / `BookSourceSession` request pipeline as
    /// chapter parsing, preserving source headers, login headers, cookies, and AnalyzeUrl options.
    static func sourceJavaScript(forPromptPayload payload: String) throws -> String {
        guard payload.utf8.count <= 256 * 1024,
              let data = payload.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let method = object["method"] as? String,
              ["ajax", "get", "post", "head", "connect"].contains(method),
              let arguments = object["arguments"] as? [Any],
              !arguments.isEmpty,
              arguments.count <= 4,
              arguments[0] is String,
              JSONSerialization.isValidJSONObject(arguments),
              let argumentsData = try? JSONSerialization.data(
                withJSONObject: arguments,
                options: [.withoutEscapingSlashes]
              ),
              let argumentsJSON = String(data: argumentsData, encoding: .utf8) else {
            throw sourcePageBridgeError()
        }

        let call = "java.\(method).apply(java, \(argumentsJSON))"
        if method == "head" {
            return """
            (function () {
                var response = \(call);
                var headers = response && typeof response.headers === 'function'
                    ? response.headers() : response;
                if (!headers) return '{}';
                if (typeof headers.keySet === 'function' && typeof headers.get === 'function') {
                    var object = {};
                    var keys = headers.keySet();
                    for (var i = 0; i < keys.length; i++) object[String(keys[i])] = headers.get(keys[i]);
                    return JSON.stringify(object);
                }
                return JSON.stringify(headers);
            })()
            """
        }
        if method == "connect" {
            return """
            (function () {
                var response = \(call);
                if (response == null) return '';
                return typeof response.toString === 'function'
                    ? String(response.toString()) : String(response);
            })()
            """
        }
        return """
        (function () {
            var response = \(call);
            if (response == null) return '';
            if (typeof response.body === 'function') {
                var body = response.body();
                return String(body == null ? '' : body);
            }
            return String(response);
        })()
        """
    }

    func makeUIView(context: Context) -> WKWebView {
        // Let JavaScript-driven input focus raise the keyboard (SMS 验证码 fields focus a hidden
        // <input> on tap; the 番茄 验证码 step couldn't open the keyboard otherwise). One-time,
        // process-wide WKContentView patch.
        _ = WKWebView.patchKeyboardFocusOnce

        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        prefs.preferredContentMode = SourceWebIdentity.contentMode(desktop: false)
        config.defaultWebpagePreferences = prefs
        // A captcha/OAuth widget that opens itself (not from a tap) is blocked before
        // the UI delegate is ever consulted unless script-opened windows are allowed.
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        context.coordinator.clipboardBridge.install(in: config.userContentController)
        context.coordinator.sourceRunHandler = sourceRunHandler
        context.coordinator.sourceConfigurationUpdateHandler = sourceConfigurationUpdateHandler
        if sourceRunHandler != nil {
            context.coordinator.uiDelegate.sourceBridgePromptHandler = { [weak coordinator = context.coordinator] payload, completion in
                guard let coordinator else {
                    completion(nil)
                    return
                }
                coordinator.handleSourceJavaPrompt(payload, completion: completion)
            }
            config.userContentController.addScriptMessageHandler(
                context.coordinator,
                contentWorld: .page,
                name: Coordinator.sourceRunMessageName
            )
            let bootstrap = Self.sourcePageBootstrap(injectedJavaScript: injectedJavaScript)
            config.userContentController.addUserScript(
                WKUserScript(source: bootstrap, injectionTime: .atDocumentStart, forMainFrameOnly: true)
            )
        }
        // In a world of its own, out of the page's reach, as every page here needs it.
        config.userContentController.addScriptMessageHandler(
            context.coordinator,
            contentWorld: .defaultClient,
            name: Coordinator.firstPaintMessageName
        )
        config.userContentController.addUserScript(WKUserScript(
            source: Coordinator.firstPaintScript,
            injectionTime: .atDocumentEnd,
            forMainFrameOnly: true,
            in: .defaultClient
        ))

        let wv = WKWebView(frame: .zero, configuration: config)
        SourceWebIdentity.apply(desktop: false, to: wv)
        if let userAgent {
            wv.customUserAgent = userAgent
        }
        context.coordinator.finishesWhenChallengeClears = finishesWhenChallengeClears
        wv.navigationDelegate = context.coordinator
        // `uiDelegate` is weak — the Coordinator owns it. Without it the page's
        // `window.open` / `alert` / `confirm` are dropped without a trace.
        wv.uiDelegate = context.coordinator.uiDelegate
        context.coordinator.webView = wv
        context.coordinator.bridge = bridge

        // Drive the progress bar from the live load estimate.
        context.coordinator.progressObservation = wv.observe(\.estimatedProgress, options: [.new]) { [weak bridge] web, _ in
            DispatchQueue.main.async { [bridge] in bridge?.progress = web.estimatedProgress }
        }
        context.coordinator.urlObservation = wv.observe(\.url, options: [.new]) { [weak bridge] web, _ in
            DispatchQueue.main.async { [bridge] in bridge?.currentURL = web.url }
        }

        context.coordinator.installKeyboardReFocusWorkaround()

        let coordinator = context.coordinator
        bridge.syncCookiesAndDismiss = { [weak coordinator] completion in
            guard let wv = coordinator?.webView else { completion(nil); return }
            coordinator?.syncCookiesAndDismiss(from: wv, completion: completion)
        }
        bridge.reload = { [weak coordinator, weak bridge] in
            guard let coordinator, let wv = coordinator.webView else { return }
            bridge?.phase = .loading
            bridge?.errorText = nil
            bridge?.progress = 0
            coordinator.loadInitial(
                urlString: urlString,
                html: initialHTML,
                request: initialRequest,
                in: wv
            )
        }

        context.coordinator.loadInitial(urlString: urlString, html: initialHTML, request: initialRequest, in: wv)
        return wv
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator() }

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        uiView.configuration.userContentController.removeScriptMessageHandler(
            forName: Coordinator.sourceRunMessageName,
            contentWorld: .page
        )
        uiView.configuration.userContentController.removeScriptMessageHandler(
            forName: Coordinator.firstPaintMessageName,
            contentWorld: .defaultClient
        )
        coordinator.clipboardBridge.remove(from: uiView.configuration.userContentController)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandlerWithReply {
        static let sourceRunMessageName = "yueduSourceRun"
        static let firstPaintMessageName = "yueduFirstPaint"
        /// Posts once the parsed document has been drawn. It runs when parsing ends, after the
        /// page's own scripts, a synchronous `java.ajax` among them; the first frame callback
        /// comes before the frame that draws the document, the second before the next one, by
        /// when the first has been drawn.
        static let firstPaintScript = """
        requestAnimationFrame(function () {
            requestAnimationFrame(function () {
                window.webkit.messageHandlers.\(firstPaintMessageName).postMessage('');
            });
        });
        """

        weak var webView: WKWebView?
        weak var bridge: JsBridgeBrowserBridge?
        var progressObservation: NSKeyValueObservation?
        var urlObservation: NSKeyValueObservation?
        var sourceRunHandler: ((String) async throws -> String)?
        var sourceConfigurationUpdateHandler: ((String) -> Void)?
        var finishesWhenChallengeClears = false
        /// A page of this navigation history was a Cloudflare challenge.
        private(set) var sawChallenge = false
        /// Strongly held: `WKWebView.uiDelegate` is weak.
        let uiDelegate = SourceWebUIDelegate()
        let clipboardBridge = SourceWebClipboardBridge()
        private var keyboardHideObserver: NSObjectProtocol?

        /// WKWebView keeps the tapped `<input>` as `document.activeElement` after the keyboard is
        /// dismissed, so tapping it again fires no new focus event and the keyboard never returns
        /// (e.g. you collapse the 番茄 验证码 keyboard, then can't reopen it). Blur the active
        /// element once the keyboard is fully gone so the next tap is a fresh focus.
        func installKeyboardReFocusWorkaround() {
            keyboardHideObserver = NotificationCenter.default.addObserver(
                forName: UIResponder.keyboardDidHideNotification,
                object: nil,
                queue: .main
            ) { [weak self] _ in
                // Delivered on `.main` (the queue above).
                MainActor.assumeIsolated {
                    self?.webView?.evaluateJavaScript(
                        "if (document.activeElement && document.activeElement.blur) { document.activeElement.blur(); }",
                        completionHandler: nil
                    )
                }
            }
        }

        isolated deinit {
            if let keyboardHideObserver {
                NotificationCenter.default.removeObserver(keyboardHideObserver)
            }
        }

        func setPhase(_ phase: JsBridgeBrowserBridge.Phase, error: String? = nil) {
            DispatchQueue.main.async { [weak self] in
                guard let bridge = self?.bridge else { return }
                // A first paint counts only for the page that committed: not one that finished
                // before its frames came round, nor the last page's, posted as a new one started.
                if phase == .painted, bridge.phase != .committed { return }
                bridge.phase = phase
                if let error { bridge.errorText = error }
            }
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping @MainActor (WKNavigationActionPolicy) -> Void
        ) {
            // Intercept book-source import deep links so WKWebView doesn't try to
            // navigate to them (an unhandled custom scheme fails as "unsupported URL").
            // We handle our own `yuedu://` scheme (來源配置 and module links) plus Legado's
            // `legado://import/...`, which most 書源 update pages emit (e.g. the 更新書源
            // download button).
            guard let url = navigationAction.request.url else {
                decisionHandler(.allow)
                return
            }
            let scheme = url.scheme?.lowercased()
            let isImportDeepLink = scheme == "yuedu"
                || (scheme == "legado" && url.host?.lowercased() == "import")
            guard isImportDeepLink else {
                decisionHandler(.allow)
                return
            }

            handleImportURL(url, webView: webView)
            decisionHandler(.cancel)
        }

        func load(url: URL, request initialRequest: URLRequest? = nil, in webView: WKWebView) {
            // Attach source credentials only to the exact destination prepared by its runtime.
            let request: URLRequest
            if let initialRequest, initialRequest.url == url {
                request = initialRequest
            } else {
                request = URLRequest(url: url)
            }
            let cookies = Self.cookiesForInitialLoad(url: url)
            guard !cookies.isEmpty else {
                webView.load(request)
                return
            }

            let cookieStore = webView.configuration.websiteDataStore.httpCookieStore
            let group = DispatchGroup()
            for cookie in cookies {
                group.enter()
                cookieStore.setCookie(cookie) {
                    group.leave()
                }
            }
            group.notify(queue: .main) {
                webView.load(request)
            }
        }

        func loadInitial(urlString: String, html: String?, request: URLRequest? = nil, in webView: WKWebView) {
            if let html {
                webView.loadHTMLString(html, baseURL: URL(string: urlString))
            } else if let url = URL(string: urlString) {
                load(url: url, request: request, in: webView)
            }
        }

        // Matches the SDK requirement exactly (`WK_SWIFT_UI_ACTOR` on the protocol and the reply
        // block). Without the annotations, complete concurrency checking rejects the conformance.
        @MainActor
        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage,
            replyHandler: @escaping @MainActor (Any?, String?) -> Void
        ) {
            if message.name == Self.firstPaintMessageName {
                setPhase(.painted)
                replyHandler(nil, nil)
                return
            }
            guard message.name == Self.sourceRunMessageName,
                  let script = message.body as? String,
                  let sourceRunHandler else {
                replyHandler(nil, localized("段評執行環境不可用"))
                return
            }
            Task {
                do {
                    replyHandler(try await sourceRunHandler(script), nil)
                } catch {
                    replyHandler(nil, error.localizedDescription)
                }
            }
        }

        func handleSourceJavaPrompt(
            _ payload: String,
            completion: @escaping @MainActor (String?) -> Void
        ) {
            do {
                if let configurationJSON = try JsBridgeBrowserRepresentable
                    .sourceConfigurationJSON(forPromptPayload: payload) {
                    sourceConfigurationUpdateHandler?(configurationJSON)
                    completion("")
                    return
                }
            } catch {
                AppLogger.parse("source page upConfig rejected request", context: [
                    "error": error.localizedDescription
                ])
                completion(nil)
                return
            }
            guard let sourceRunHandler else {
                completion(nil)
                return
            }
            let script: String
            do {
                script = try JsBridgeBrowserRepresentable.sourceJavaScript(
                    forPromptPayload: payload
                )
            } catch {
                AppLogger.parse("source page java bridge rejected request", context: [
                    "error": error.localizedDescription
                ])
                completion(nil)
                return
            }
            Task { @MainActor in
                do {
                    completion(try await sourceRunHandler(script))
                } catch {
                    AppLogger.parse("source page java bridge failed", context: [
                        "error": error.localizedDescription
                    ])
                    completion(nil)
                }
            }
        }

        // MARK: Navigation phases (drive the loading / error UI)

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            setPhase(.loading)
        }

        func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
            setPhase(.committed)
        }

        /// Also what lifts the overlay where no first paint is posted: a document no user script
        /// runs in (a PDF), or a web view off screen, whose frames never come round.
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async { [weak self] in
                self?.bridge?.progress = 1
            }
            setPhase(.finished)
            syncCookiesAndDismiss(from: webView, completion: nil)
            if finishesWhenChallengeClears {
                checkCloudflareChallenge(in: webView)
            }
        }

        /// Legado-E and MD3 both ask every finished page `!!window._cf_chl_opt` — the object
        /// Cloudflare's challenge script defines — and finish the verification on the first
        /// page after a challenge that no longer has it.
        private func checkCloudflareChallenge(in webView: WKWebView) {
            webView.evaluateJavaScript("!!window._cf_chl_opt") { [weak self] result, error in
                guard let self else { return }
                if let error {
                    AppLogger.parse("source page Cloudflare check failed", context: [
                        "error": error.localizedDescription
                    ])
                    return
                }
                if (result as? Bool) == true {
                    self.sawChallenge = true
                } else if self.sawChallenge {
                    self.sawChallenge = false
                    self.bridge?.challengeCleared = true
                }
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            setPhase(.failed, error: error.localizedDescription)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            // Ignore the benign "cancelled" that follows decidePolicy(.cancel) for
            // intercepted yuedu:// / legado:// import links.
            if (error as NSError).code == NSURLErrorCancelled { return }
            setPhase(.failed, error: error.localizedDescription)
        }

        func syncCookiesAndDismiss(from webView: WKWebView, completion: ((String?) -> Void)?) {
            webView.evaluateJavaScript("document.documentElement.outerHTML") { body, _ in
                let pageBody = body as? String
                webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
                    guard !cookies.isEmpty else { completion?(pageBody); return }

                    cookies.forEach { HTTPCookieStorage.shared.setCookie($0) }

                    var byDomain: [String: [HTTPCookie]] = [:]
                    for cookie in cookies {
                        let domain = cookie.domain.hasPrefix(".")
                            ? String(cookie.domain.dropFirst()) : cookie.domain
                        byDomain["https://\(domain)", default: []].append(cookie)
                    }
                    for (domainKey, domainCookies) in byDomain {
                        let joined = domainCookies.map { "\($0.name)=\($0.value)" }.joined(separator: "; ")
                        CookieStore.shared.set(url: domainKey, cookie: joined)
                    }

                    completion?(pageBody)
                }
            }
        }

        private func handleImportURL(_ url: URL, webView: WKWebView) {
            // A module link (Phase 6e-2) opens the module import, over this page.
            if case .module(let address) = BookSourceImportDeepLink.target(from: url) {
                RuleModuleLinkPresenter.present(address)
                return
            }
            guard let sourceURL = Self.onlineImportSourceURL(from: url) else {
                presentImportResult(localized("無效的來源配置導入連結"), in: webView)
                return
            }

            URLSession.shared.dataTask(with: sourceURL) { data, _, error in
                DispatchQueue.main.async {
                    if let error {
                        self.presentImportResult(error.localizedDescription, in: webView)
                        return
                    }
                    guard let data else {
                        self.presentImportResult(localized("無法讀取來源配置資料"), in: webView)
                        return
                    }
                    do {
                        let ext = sourceURL.pathExtension.isEmpty ? "json" : sourceURL.pathExtension
                        // Parse only; the confirmation list decides what gets written.
                        let sources = try BookSourceStore.shared.parseForImport(
                            data: data,
                            fileExtension: ext
                        )
                        self.presentImportReview(sources, in: webView)
                    } catch {
                        self.presentImportResult(error.localizedDescription, in: webView)
                    }
                }
            }.resume()
        }

        private func presentImportResult(_ message: String, in webView: WKWebView) {
            guard let top = Self.topPresenter(in: webView) else { return }
            let alert = UIAlertController(title: localized("來源配置導入"), message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: localized("完成"), style: .default))
            top.present(alert, animated: true)
        }

        /// Shows the import confirmation list over the in-page browser. This importer lives in
        /// a `WKWebView` coordinator with no SwiftUI sheet host, so the list is hosted in a
        /// UIKit controller presented from the same presenter the result alert uses.
        private func presentImportReview(_ sources: [BookSource], in webView: WKWebView) {
            guard let top = Self.topPresenter(in: webView) else { return }
            // The dismiss callbacks need the controller that does not exist yet when its own
            // `rootView` is built. The box holds it weakly, so nothing retains a cycle.
            final class PresentedControllerBox {
                weak var controller: UIViewController?
            }
            let box = PresentedControllerBox()
            let host = UIHostingController(
                rootView: BookSourceImportReviewHost(
                    sources: sources,
                    onFinish: { [weak self] count in
                        box.controller?.dismiss(animated: true) {
                            self?.presentImportResult(
                                String(format: localized("成功匯入 %d 個來源配置"), count),
                                in: webView
                            )
                        }
                    },
                    onCancel: { box.controller?.dismiss(animated: true) }
                )
            )
            box.controller = host
            top.present(host, animated: true)
        }

        private static func topPresenter(in webView: WKWebView) -> UIViewController? {
            guard let root = webView.window?.rootViewController else { return nil }
            var top = root
            while let presented = top.presentedViewController {
                top = presented
            }
            return top
        }

        static func onlineImportSourceURL(from url: URL) -> URL? {
            // Single source of truth: shared with the system-level deep-link
            // handler in `yuedu_appApp`. One path for this concern.
            BookSourceImportDeepLink.sourceURL(from: url)
        }

        static func cookiesForInitialLoad(url: URL) -> [HTTPCookie] {
            HTTPCookieStorage.shared.cookies(for: url) ?? []
        }
    }
}

// MARK: - Keyboard-on-programmatic-focus patch
//
// WKWebView suppresses the on-screen keyboard when a web page focuses an `<input>` via JavaScript
// instead of a direct tap. SMS login pages (番茄 included) render the 验证码 field as styled boxes
// whose tap handler calls `input.focus()` — so the phone-number field (a real `<input>` you tap)
// raises the keyboard, but the 验证码 boxes never do. There is no public API for this, so we
// swizzle the private `WKContentView` focus callback ONCE to always report user interaction.
// Runtime-only: no private symbols are linked (looked up via NSClassFromString / sel_getUid).
extension WKWebView {
    /// Lazily-evaluated, thread-safe one-shot patch. Touch `WKWebView.patchKeyboardFocusOnce`
    /// from any web view's `makeUIView` to install it process-wide.
    static let patchKeyboardFocusOnce: Void = {
        guard let contentViewClass = NSClassFromString("WKContentView") else { return }

        // (self, _cmd, focusedElementInfo, userIsInteracting, blurPreviousNode,
        //  activityStateChanges, userObject)
        typealias FocusIMP = @convention(c) (Any, Selector, UnsafeRawPointer, Bool, Bool, UInt, Any?) -> Void

        // iOS 13+ uses `activityStateChanges`; the older `changingActivityState` name is kept as a
        // defensive fallback. Patch whichever exists.
        let selectorNames = [
            "_elementDidFocus:userIsInteracting:blurPreviousNode:activityStateChanges:userObject:",
            "_elementDidFocus:userIsInteracting:blurPreviousNode:changingActivityState:userObject:",
        ]

        for name in selectorNames {
            let selector = sel_getUid(name)
            guard let method = class_getInstanceMethod(contentViewClass, selector) else { continue }
            let originalIMP = method_getImplementation(method)
            let original = unsafeBitCast(originalIMP, to: FocusIMP.self)
            let override: @convention(block) (Any, UnsafeRawPointer, Bool, Bool, UInt, Any?) -> Void = {
                received, element, _, blurPreviousNode, activityStateChanges, userObject in
                // Force `userIsInteracting` = true so the keyboard appears for JS-driven focus.
                original(received, selector, element, true, blurPreviousNode, activityStateChanges, userObject)
            }
            method_setImplementation(method, imp_implementationWithBlock(override))
            return
        }
    }()
}

// MARK: - Preview

#Preview {
    JsBridgeBrowserView(
        urlString: "https://example.com",
        title: "密鑰獲取",
        onDismiss: { _ in }
    )
}
