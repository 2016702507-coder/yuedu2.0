import Combine
import Foundation

// MARK: - Safe Decoding Extensions (null / missing key / type mismatch tolerance)

extension KeyedDecodingContainer {
    /// Returns "" when encountering null or missing key, without throwing
    func safeString(forKey key: Key) -> String {
        if let s = try? decodeIfPresent(String.self, forKey: key) { return s }
        // Some Legado fields may be serialized as numbers instead of strings
        if let i = try? decodeIfPresent(Int.self, forKey: key) { return String(i) }
        if let d = try? decodeIfPresent(Double.self, forKey: key) { return String(d) }
        if let b = try? decodeIfPresent(Bool.self, forKey: key) { return b ? "true" : "false" }
        return ""
    }

    /// Int tolerant decoding: accepts Int, String("0"), Double, Bool
    func safeInt(forKey key: Key) -> Int {
        if let i = try? decodeIfPresent(Int.self, forKey: key) { return i }
        if let s = try? decodeIfPresent(String.self, forKey: key), let i = Int(s) { return i }
        if let d = try? decodeIfPresent(Double.self, forKey: key) { return Int(d) }
        if let b = try? decodeIfPresent(Bool.self, forKey: key) { return b ? 1 : 0 }
        return 0
    }

    /// Int64 tolerant decoding: accepts Int64, Int, String, Double
    func safeInt64(forKey key: Key) -> Int64 {
        if let i = try? decodeIfPresent(Int64.self, forKey: key) { return i }
        if let i = try? decodeIfPresent(Int.self, forKey: key) { return Int64(i) }
        if let s = try? decodeIfPresent(String.self, forKey: key), let i = Int64(s) { return i }
        if let d = try? decodeIfPresent(Double.self, forKey: key) { return Int64(d) }
        return 0
    }

    /// Bool tolerant decoding: accepts Bool, Int(0/1), String("true"/"false"/"0"/"1")
    func safeBool(forKey key: Key, defaultValue: Bool = false) -> Bool {
        if let b = try? decodeIfPresent(Bool.self, forKey: key) { return b }
        if let i = try? decodeIfPresent(Int.self, forKey: key) { return i != 0 }
        if let s = try? decodeIfPresent(String.self, forKey: key) {
            let lower = s.lowercased()
            if lower == "true" || lower == "1" { return true }
            if lower == "false" || lower == "0" { return false }
        }
        return defaultValue
    }

    /// Legado rules may be objects or JSON strings (double-encoded during backup/export)
    func decodeRule<T: Decodable>(_ type: T.Type, forKey key: Key) -> T? {
        if let obj = try? decodeIfPresent(T.self, forKey: key) { return obj }
        if let str = try? decodeIfPresent(String.self, forKey: key),
           let data = str.data(using: .utf8),
           let obj = try? JSONDecoder().decode(T.self, from: data) { return obj }
        return nil
    }
}

// MARK: - Rule Structures (Legado compatible, high tolerance)

struct SearchRule: Codable {
    var checkKeyWord: String = ""
    var bookList: String = ""
    var name: String = ""
    var author: String = ""
    var coverUrl: String = ""
    var intro: String = ""
    var bookUrl: String = ""
    var wordCount: String = ""
    var lastChapter: String = ""
    var updateTime: String = ""
    var kind: String = ""
    /// Legado: JS evaluated against the page body ("result") that decides
    /// whether a next result page exists. Blank = fall back to heuristics.
    var hasMoreRule: String = ""

    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        checkKeyWord  = c.safeString(forKey: .checkKeyWord)
        bookList      = c.safeString(forKey: .bookList)
        name          = c.safeString(forKey: .name)
        author        = c.safeString(forKey: .author)
        coverUrl      = c.safeString(forKey: .coverUrl)
        intro         = c.safeString(forKey: .intro)
        bookUrl       = c.safeString(forKey: .bookUrl)
        wordCount     = c.safeString(forKey: .wordCount)
        lastChapter   = c.safeString(forKey: .lastChapter)
        updateTime    = c.safeString(forKey: .updateTime)
        kind          = c.safeString(forKey: .kind)
        hasMoreRule   = c.safeString(forKey: .hasMoreRule)
    }
}

struct BookInfoRule: Codable {
    var initScript: String = ""   // Legado JSON key: "init"
    var name: String = ""
    var author: String = ""
    var coverUrl: String = ""
    var intro: String = ""
    var kind: String = ""
    var wordCount: String = ""
    var lastChapter: String = ""
    var updateTime: String = ""
    var tocUrl: String = ""
    var canReName: String = ""
    var downloadUrls: String = ""  // Legado: download URL rule
    var ttsDice: String = ""       // Legado: TTS random selector

    enum CodingKeys: String, CodingKey {
        case initScript = "init"
        case name, author, coverUrl, intro, kind, wordCount, lastChapter, updateTime, tocUrl, canReName
        case downloadUrls, ttsDice
    }

    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        initScript    = c.safeString(forKey: .initScript)
        name          = c.safeString(forKey: .name)
        author        = c.safeString(forKey: .author)
        coverUrl      = c.safeString(forKey: .coverUrl)
        intro         = c.safeString(forKey: .intro)
        kind          = c.safeString(forKey: .kind)
        wordCount     = c.safeString(forKey: .wordCount)
        lastChapter   = c.safeString(forKey: .lastChapter)
        updateTime    = c.safeString(forKey: .updateTime)
        tocUrl        = c.safeString(forKey: .tocUrl)
        canReName     = c.safeString(forKey: .canReName)
        downloadUrls  = c.safeString(forKey: .downloadUrls)
        ttsDice       = c.safeString(forKey: .ttsDice)
    }
}

struct TOCRule: Codable {
    var preUpdateJs: String = ""
    var chapterList: String = ""
    var chapterName: String = ""
    var chapterUrl: String = ""
    var formatJs: String = ""   // Legado: chapter formatting JS
    var isVolume: String = ""
    var isVip: String = ""
    var isPay: String = ""
    var updateTime: String = ""
    var nextTocUrl: String = ""

    enum CodingKeys: String, CodingKey {
        case preUpdateJs, chapterList, chapterName, chapterUrl, formatJs
        case isVolume, isVip, isPay, updateTime, nextTocUrl
    }

    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        preUpdateJs = c.safeString(forKey: .preUpdateJs)
        chapterList = c.safeString(forKey: .chapterList)
        chapterName = c.safeString(forKey: .chapterName)
        chapterUrl  = c.safeString(forKey: .chapterUrl)
        formatJs    = c.safeString(forKey: .formatJs)
        isVolume    = c.safeString(forKey: .isVolume)
        isVip       = c.safeString(forKey: .isVip)
        isPay       = c.safeString(forKey: .isPay)
        updateTime  = c.safeString(forKey: .updateTime)
        nextTocUrl  = c.safeString(forKey: .nextTocUrl)
    }
}

struct ContentRule: Codable {
    var content: String = ""
    var title: String = ""
    var nextContentUrl: String = ""
    var webJs: String = ""
    var sourceRegex: String = ""
    var replaceRegex: String = ""
    var imageStyle: String = ""
    var imageDecode: String = ""   // Legado: image decode rule
    var payAction: String = ""
    /// legado-E / MD3 `ruleContent.callBackJs`: the script the app runs on book and UI events
    /// (`SourceCallBack`) when the source sets `eventListener`. Optional so a source without one
    /// encodes exactly as before.
    var callBackJs: String?

    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        content        = c.safeString(forKey: .content)
        title          = c.safeString(forKey: .title)
        nextContentUrl = c.safeString(forKey: .nextContentUrl)
        webJs          = c.safeString(forKey: .webJs)
        sourceRegex    = c.safeString(forKey: .sourceRegex)
        replaceRegex   = c.safeString(forKey: .replaceRegex)
        imageStyle     = c.safeString(forKey: .imageStyle)
        imageDecode    = c.safeString(forKey: .imageDecode)
        payAction      = c.safeString(forKey: .payAction)
        let callBack   = c.safeString(forKey: .callBackJs)
        callBackJs     = callBack.isEmpty ? nil : callBack
    }
}

// MARK: - Discover Page Rules (Legado ExploreRule)

struct ExploreRule: Codable {
    var bookList: String = ""
    var name: String = ""
    var author: String = ""
    var intro: String = ""
    var kind: String = ""
    var lastChapter: String = ""
    var updateTime: String = ""
    var bookUrl: String = ""
    var coverUrl: String = ""
    var wordCount: String = ""
    /// Legado: JS evaluated against the page body ("result") that decides
    /// whether a next discover page exists. Blank = fall back to heuristics.
    var hasMoreRule: String = ""

    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        bookList    = c.safeString(forKey: .bookList)
        name        = c.safeString(forKey: .name)
        author      = c.safeString(forKey: .author)
        intro       = c.safeString(forKey: .intro)
        kind        = c.safeString(forKey: .kind)
        lastChapter = c.safeString(forKey: .lastChapter)
        updateTime  = c.safeString(forKey: .updateTime)
        bookUrl     = c.safeString(forKey: .bookUrl)
        coverUrl    = c.safeString(forKey: .coverUrl)
        wordCount   = c.safeString(forKey: .wordCount)
        hasMoreRule = c.safeString(forKey: .hasMoreRule)
    }
}

// MARK: - Review Rules (Legado ReviewRule)

struct ReviewRule: Codable {
    var review: String = ""

    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        review = c.safeString(forKey: .review)
    }
}

// MARK: - Book Source

struct BookSource: Identifiable, Codable {
    var id: UUID = UUID()
    var bookSourceName: String = ""
    var bookSourceUrl: String = ""
    var bookSourceGroup: String = ""

    var cleanedBookSourceURL: String {
        if let hashIdx = bookSourceUrl.firstIndex(of: "#") {
            return String(bookSourceUrl[..<hashIdx]).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return bookSourceUrl
    }
    var bookSourceComment: String = ""
    var bookSourceType: Int = 0       // 0 = text, 1 = audio, 2 = image, 3 = file, 4 = video
    var bookUrlPattern: String = ""   // Legado: URL match pattern
    var customOrder: Int = 0          // Legado: custom ordering
    var enabled: Bool = true
    var enabledExplore: Bool = true   // Legado: discover page toggle
    /// Legado's automatic-cookie-management switch. **Carried, not honored:**
    /// `CookieStore` saves and replays cookies for every source unconditionally, so
    /// this flag gates nothing here — it is decoded and re-encoded so an imported
    /// source round-trips intact, and exposed to rule JS as `source.enabledCookieJar`.
    /// No editor control, because a switch that changes nothing reads as a bug.
    var enabledCookieJar: Bool = false
    /// Legado's 段评 switch, which there enables the source's `ruleReview`.
    /// **Carried, not honored:** this app has no `ruleReview` parsing path at all —
    /// paragraph reviews are detected from the review markers a source embeds in the
    /// chapter HTML (`ReaderViewModel.recordParagraphReviewsIfPresent`), which no flag
    /// gates. Kept for round-tripping and for `source.enabledReview` in rule JS.
    var enabledReview: Bool = false
    /// legado-E / MD3 `eventListener`: run `ruleContent.callBackJs` on book and UI events
    /// (`SourceCallBackService`). Optional so a source that never set it encodes as before.
    var eventListener: Bool?
    /// legado-E / MD3 `customButton`: show the source-controlled button (book detail, reader
    /// menu, audiobook player) whose taps reach `callBackJs` as `clickCustomButton`.
    var customButton: Bool?
    /// Whether `java.androidId()` hands this source a device identifier.
    ///
    /// **On by default**, matching upstream: Legado's `androidId()` returns
    /// `Settings.Secure.ANDROID_ID` unconditionally and falls back to the string
    /// `"null"` — never empty, never absent, no per-source switch. Sources are
    /// written against that guarantee, so 知秋番茄's `x-android-id` and 企点's
    /// `&device=` get a value the way their authors assumed.
    ///
    /// It defaulted to OFF for one release on the theory that answering broke
    /// 书山聚合, whose `deviceType()` reads any non-empty answer as proof of
    /// Android. That was observed while `androidId()` still returned
    /// `identifierForVendor` — a 36-character uppercase UUID, not an ANDROID_ID —
    /// and the same commit that fixed the format also added the opt-in, so the
    /// theory was never retested against the corrected value. Retested since: 书山
    /// works either way, because its `deviceType()` reaches `deviceID()` on the
    /// second branch and its server accepts both `X-Device-Type` values. Off was
    /// protecting a source that did not need protecting, at the cost of every
    /// source that did.
    ///
    /// The switch stays as an escape hatch with the meaning reversed: turn it OFF
    /// for a source that genuinely must not be taken for Android.
    ///
    /// Optional in the decoder: archives written before this field exists must
    /// keep loading, and they take the new default.
    var presentsAndroidIdentity: Bool = true
    var searchUrl: String = ""
    var exploreUrl: String = ""       // Discover/category page URL (common Legado field)
    var concurrentRate: String = ""   // Concurrency rate limit
    var header: String = ""           // JSON string, e.g. {"User-Agent":"..."}
    var loginUrl: String = ""
    var loginUi: String = ""          // Legado: login UI configuration JSON
    var loginCheckJs: String = ""     // Legado: executed after search response; skip parsing if login is required
    var respondTime: Int64 = 180000   // Legado: response time (milliseconds)
    var lastUpdateTime: Int64 = 0     // Legado: last update timestamp
    var weight: Int = 0
    var variableComment: String = ""  // Legado: variable comment
    var exploreScreen: String = ""    // Legado: discover page configuration
    var coverDecodeJs: String = ""    // Legado: cover decode JS
    var jsLib: String = ""            // Legado: shared JS library evaluated at source init
    var ruleSearch: SearchRule = SearchRule()
    var ruleExplore: ExploreRule = ExploreRule()  // Legado: discover page rule
    var ruleBookInfo: BookInfoRule = BookInfoRule()
    var ruleToc: TOCRule = TOCRule()
    var ruleContent: ContentRule = ContentRule()
    var ruleReview: ReviewRule = ReviewRule()      // Legado: review rule

    /// Whether this book source must be fetched through a real WebView.
    ///
    /// `bookSourceType` is a CONTENT type (0=text, 1=audio, 2=image, 3=file, 4=video), NOT a transport
    /// hint — audio sources are ordinary HTTP/JSON APIs and must never be forced through a
    /// WebView (doing so broke audiobook search/detail). Genuine WebView needs are driven
    /// per-request (`requestSpec.useWebView`), by chapter JS (`hasWebJs`), or by the
    /// empty-result WebView retry in TOC/chapter fetch — none of which depend on this flag.
    var needsWebView: Bool { false }

    enum CodingKeys: String, CodingKey {
        case id
        case bookSourceName, bookSourceUrl, bookSourceGroup, bookSourceComment
        case bookSourceType, bookUrlPattern, customOrder
        case enabled, enabledExplore, enabledCookieJar, enabledReview
        case eventListener, customButton
        case searchUrl, exploreUrl, concurrentRate
        case header, loginUrl, loginUi, loginCheckJs
        case presentsAndroidIdentity
        case respondTime, lastUpdateTime, weight
        case variableComment, exploreScreen, coverDecodeJs, jsLib
        case ruleSearch, ruleExplore, ruleBookInfo, ruleToc, ruleContent, ruleReview
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id               = (try? c.decodeIfPresent(UUID.self, forKey: .id)) ?? UUID()
        bookSourceName   = c.safeString(forKey: .bookSourceName)
        bookSourceUrl    = c.safeString(forKey: .bookSourceUrl)
        bookSourceGroup  = c.safeString(forKey: .bookSourceGroup)
        bookSourceComment = c.safeString(forKey: .bookSourceComment)
        bookSourceType   = c.safeInt(forKey: .bookSourceType)
        bookUrlPattern   = c.safeString(forKey: .bookUrlPattern)
        customOrder      = c.safeInt(forKey: .customOrder)
        searchUrl        = c.safeString(forKey: .searchUrl)
        exploreUrl       = c.safeString(forKey: .exploreUrl)
        concurrentRate   = c.safeString(forKey: .concurrentRate)
        header           = c.safeString(forKey: .header)
        loginUrl         = c.safeString(forKey: .loginUrl)
        loginUi          = c.safeString(forKey: .loginUi)
        loginCheckJs     = c.safeString(forKey: .loginCheckJs)
        respondTime      = c.safeInt64(forKey: .respondTime)
        if respondTime == 0 { respondTime = 180000 }  // Legado default value
        lastUpdateTime   = c.safeInt64(forKey: .lastUpdateTime)
        weight           = c.safeInt(forKey: .weight)
        variableComment  = c.safeString(forKey: .variableComment)
        exploreScreen   = c.safeString(forKey: .exploreScreen)
        coverDecodeJs   = c.safeString(forKey: .coverDecodeJs)
        jsLib           = c.safeString(forKey: .jsLib)
        // Legado's enabled field may be Bool, Int 1/0, or String "true"/"false"
        enabled          = c.safeBool(forKey: .enabled, defaultValue: true)
        enabledExplore   = c.safeBool(forKey: .enabledExplore, defaultValue: true)
        enabledCookieJar = c.safeBool(forKey: .enabledCookieJar, defaultValue: false)
        presentsAndroidIdentity = c.safeBool(forKey: .presentsAndroidIdentity, defaultValue: true)
        enabledReview    = c.safeBool(forKey: .enabledReview, defaultValue: false)
        eventListener    = c.contains(.eventListener) ? c.safeBool(forKey: .eventListener, defaultValue: false) : nil
        customButton     = c.contains(.customButton) ? c.safeBool(forKey: .customButton, defaultValue: false) : nil
        // Rule structures: Legado may use objects or JSON strings (double-encoded during backup)
        ruleSearch   = c.decodeRule(SearchRule.self,   forKey: .ruleSearch)   ?? SearchRule()
        ruleExplore  = c.decodeRule(ExploreRule.self,  forKey: .ruleExplore)  ?? ExploreRule()
        ruleBookInfo = c.decodeRule(BookInfoRule.self, forKey: .ruleBookInfo) ?? BookInfoRule()
        ruleToc      = c.decodeRule(TOCRule.self,      forKey: .ruleToc)      ?? TOCRule()
        ruleContent  = c.decodeRule(ContentRule.self,  forKey: .ruleContent)  ?? ContentRule()
        ruleReview   = c.decodeRule(ReviewRule.self,   forKey: .ruleReview)   ?? ReviewRule()
    }

    init() {}

    init(bookSourceUrl: String, bookSourceName: String) {
        self.init()
        self.bookSourceUrl = bookSourceUrl
        self.bookSourceName = bookSourceName
    }
}

// MARK: - Search Results / Book Info

struct OnlineBook: Identifiable, Codable, Sendable {
    var id = UUID()
    var name: String
    var author: String
    var intro: String
    var coverUrl: String
    var bookUrl: String
    var tocUrl: String  // TOC page URL (may be identical to bookUrl)
    var wordCount: String
    var lastChapter: String
    var kind: String  // Category / tag
    var sourceId: UUID
    var sourceName: String
    var runtimeVariables: [String: String]? = nil
}

enum OnlineBookContentKind: Equatable, Sendable {
    case text
    case audio
    case manga
    /// legado `bookSourceType` 4, the same value in legado-E, Sigma, MD3 and huajideshutiao:
    /// each chapter's content is the episode's stream link, and a volume row is a 線路.
    case video
}

enum OnlineBookContentInference {
    static func infer(
        sourceType: Int?,
        runtimeVariables: [String: String]? = nil,
        urls: [String] = [],
        metadataText: [String] = []
    ) -> OnlineBookContentKind {
        if let sourceKind = kind(fromSourceType: sourceType), sourceKind != .text {
            return sourceKind
        }
        return explicitKind(
            runtimeVariables: runtimeVariables,
            urls: urls,
            metadataText: metadataText
        ) ?? .text
    }

    /// Returns only content types that the book itself explicitly carries.
    /// Unlike `infer`, this deliberately preserves `nil` for untyped results so
    /// validation can use them as a neutral candidate without mistaking them for
    /// an explicitly declared text/audio/manga entry.
    static func explicitKind(
        runtimeVariables: [String: String]? = nil,
        urls: [String] = [],
        metadataText: [String] = []
    ) -> OnlineBookContentKind? {
        let runtimeKind = kind(fromRuntimeVariables: runtimeVariables)
        if let runtimeKind, runtimeKind != .text {
            return runtimeKind
        }
        let urlKind = urls.lazy.compactMap { kind(fromURL: $0) }.first
        // A text book type does not rule a video out: legado has no book type a source can
        // set for one without probing legado-E (`getAppVariant`), so an aggregate source
        // declares its videos text and plays them from the content script — UAA's TOC sets
        // `book.type = 8` beside a `{"type":"video"}` URL.
        if urlKind == .video {
            return .video
        }
        if let runtimeKind {
            return runtimeKind
        }
        if let urlKind {
            return urlKind
        }
        for text in metadataText {
            if let metadataKind = kind(fromMetadataText: text) {
                return metadataKind
            }
        }
        return nil
    }

    private static func kind(fromSourceType sourceType: Int?) -> OnlineBookContentKind? {
        switch sourceType {
        case 1: return .audio
        case 2: return .manga
        case 4: return .video
        default: return .text
        }
    }

    private static func kind(fromRuntimeVariables vars: [String: String]?) -> OnlineBookContentKind? {
        guard let vars, !vars.isEmpty else { return nil }

        // legado-E's `BookType.video` (0b100) and the original's (1 << 11). Read from the book
        // type alone: as a URL value, `?type=4` is usually a novel category.
        if let bookType = vars["book.type"].flatMap({ Int($0) }), bookType == 4 || bookType == 2048 {
            return .video
        }

        for key in ["book.type", "type", "media", "tab", "find_tab", "contentType"] {
            if let kind = kind(fromStructuredValue: vars[key]) {
                return kind
            }
        }

        for (key, value) in vars where key.lowercased().contains("type") || key.lowercased().contains("tab") {
            if let kind = kind(fromStructuredValue: value) {
                return kind
            }
        }

        return nil
    }

    private static func kind(fromURL rawURL: String) -> OnlineBookContentKind? {
        let trimmed = rawURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        for payload in dataURLPayloads(from: trimmed) {
            if let kind = kind(fromJSONObject: payload) {
                return kind
            }
        }

        // legado's `url,{options}`. Its `type` only asks for the response in hex, so an
        // aggregate source can carry the kind in it: UAA's TOC URL ends `,{"type":"video"}`.
        // Only a kind's name counts there: any value turns hex on, so a number is no kind.
        if let options = legadoOptions(in: trimmed) {
            for (key, value) in options where isContentKindKey(key) {
                if let name = value as? String, Int(name) == nil, let kind = kind(fromStructuredValue: name) {
                    return kind
                }
            }
        }

        let requestURL = trimmed.split(separator: ",", maxSplits: 1).first.map(String.init) ?? trimmed
        guard let components = URLComponents(string: requestURL) else { return nil }
        for item in components.queryItems ?? [] {
            if ["tab", "type", "media", "mode", "category"].contains(item.name.lowercased()),
               let kind = kind(fromStructuredValue: item.value) {
                return kind
            }
        }
        // A video under a text source has no book type to say so (see `explicitKind`), and
        // an aggregate API names it in the path: UAA's `/video/info`, 番茄四合一's
        // `/api/video/detail`, 七猫-OE's 短剧 `/api/drama/detail`.
        if components.path.split(separator: "/").contains(where: { ["video", "drama"].contains($0.lowercased()) }) {
            return .video
        }
        return nil
    }

    /// The JSON object after a legado URL's first `,{`, when it parses as one.
    private static func legadoOptions(in text: String) -> [String: Any]? {
        guard let comma = text.range(of: #",\s*\{"#, options: .regularExpression) else { return nil }
        let json = text[text.index(before: comma.upperBound)...]
        guard let data = json.data(using: .utf8) else { return nil }
        // Many options are JS object literals rather than JSON; those name no kind here.
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    /// The JSON payloads of a URL's base64 `data:` parts. A data URL may name a media type
    /// before `;base64` (RFC 2397), and 书山聚合 names its parts there (`data:catalogUrl;base64,`).
    private static func dataURLPayloads(from text: String) -> [[String: Any]] {
        let marker = #"data:[^;,]*;base64,"#
        var payloads: [[String: Any]] = []
        var searchStart = text.startIndex

        while let markerRange = text.range(
            of: marker,
            options: [.caseInsensitive, .regularExpression],
            range: searchStart..<text.endIndex
        ) {
            let base64Start = markerRange.upperBound
            let base64End = text[base64Start...].firstIndex(of: ",") ?? text.endIndex
            let rawBase64 = String(text[base64Start..<base64End])
            let decodedBase64 = rawBase64.removingPercentEncoding ?? rawBase64
            if let data = Data(base64Encoded: decodedBase64),
               let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                payloads.append(json)
            }
            searchStart = base64End
        }

        return payloads
    }

    private static func kind(fromJSONObject object: Any) -> OnlineBookContentKind? {
        if let dictionary = object as? [String: Any] {
            for (key, value) in dictionary {
                if isContentKindKey(key), let kind = kind(fromStructuredValue: value) {
                    return kind
                }
                if let kind = kind(fromJSONObject: value) {
                    return kind
                }
            }
        } else if let array = object as? [Any] {
            for value in array {
                if let kind = kind(fromJSONObject: value) {
                    return kind
                }
            }
        }
        return nil
    }

    private static func isContentKindKey(_ key: String) -> Bool {
        let normalized = key
            .lowercased()
            .replacingOccurrences(of: "_", with: "")
            .replacingOccurrences(of: "-", with: "")
        return normalized == "tab"
            || normalized == "type"
            || normalized == "media"
            || normalized == "mode"
            || normalized == "category"
            || normalized == "findtab"
            || normalized == "booktype"
            || normalized == "contenttype"
    }

    private static func kind(fromStructuredValue value: Any?) -> OnlineBookContentKind? {
        guard let value else { return nil }
        if let intValue = value as? Int {
            return kind(fromTypeNumber: intValue)
        }
        if let doubleValue = value as? Double {
            return kind(fromTypeNumber: Int(doubleValue))
        }

        let text = String(describing: value).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        if let intValue = Int(text) {
            return kind(fromTypeNumber: intValue)
        }

        let normalized = text
            .lowercased()
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "_", with: "")
            .replacingOccurrences(of: "-", with: "")
        if normalized == "听书" || normalized == "聽書" || normalized == "有声"
            || normalized == "有聲" || normalized == "audio" || normalized == "audiobook" {
            return .audio
        }
        if normalized == "漫画" || normalized == "漫畫" || normalized == "comic"
            || normalized == "manga" || normalized == "image" {
            return .manga
        }
        if normalized == "小说" || normalized == "小說" || normalized == "novel"
            || normalized == "text" || normalized == "文字" {
            return .text
        }
        // 光遇 and 大灰狼 name the tab 短剧 / 视频; UAA's type is `video`.
        if normalized == "视频" || normalized == "視頻" || normalized == "影片" || normalized == "video"
            || normalized == "短剧" || normalized == "短劇" {
            return .video
        }
        return nil
    }

    private static func kind(fromTypeNumber value: Int) -> OnlineBookContentKind? {
        switch value {
        case 0, 8:
            return .text
        case 1, 32:
            return .audio
        case 2, 64:
            return .manga
        default:
            return nil
        }
    }

    private static func kind(fromMetadataText text: String) -> OnlineBookContentKind? {
        let normalized = text
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
            .replacingOccurrences(of: " ", with: "")
        guard !normalized.isEmpty else { return nil }

        let audioMarkers = ["当前模式：听书", "当前模式:听书", "目前模式：聽書", "模式：听书", "模式:听书"]
        if audioMarkers.contains(where: { normalized.contains($0) }) {
            return .audio
        }

        let mangaMarkers = ["当前模式：漫画", "当前模式:漫画", "目前模式：漫畫", "模式：漫画", "模式:漫画"]
        if mangaMarkers.contains(where: { normalized.contains($0) }) {
            return .manga
        }

        return kind(fromStructuredValue: normalized)
    }

    /// Mode markers (听书 / 漫画 / 小说…) read from the *source's* persisted runtime
    /// variables. Aggregate sources (光遇 family) keep the active 类型/搜索模式 there
    /// — individual search/discover results often carry no per-book marker at all,
    /// so the source's current mode is the only signal left for routing. Feed these
    /// into `infer`'s `metadataText` (weakest priority: any per-book marker wins).
    static func sourceRuntimeModeMarkers(for source: BookSource?) -> [String] {
        sourceRuntimeModeMarkers(forSourceURL: source?.bookSourceUrl)
    }

    /// URL-only form for Sendable search-presentation snapshots. The imported
    /// source value itself is not needed to read its persisted runtime markers.
    static func sourceRuntimeModeMarkers(forSourceURL sourceURL: String?) -> [String] {
        guard let sourceURL,
              let json = BookSourceRuntimeStateStore.shared
                  .sourceVariableJSON(for: sourceURL),
              let data = json.data(using: .utf8),
              let dict = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return [] }

        var markers: [String] = []
        for key in ["发现页类型", "搜索模式"] {
            if let value = dict[key] as? String,
               !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                markers.append(value)
            }
        }
        if let more = dict["更多设置"] as? [String: Any],
           let value = more["搜索模式"] as? String,
           !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            markers.append(value)
        }
        return markers
    }
}

extension OnlineBook {
    func inferredContentKind(source: BookSource?) -> OnlineBookContentKind {
        OnlineBookContentInference.infer(
            sourceType: source?.bookSourceType,
            runtimeVariables: runtimeVariables,
            urls: [bookUrl, tocUrl],
            metadataText: [kind, intro, lastChapter, sourceName]
                + OnlineBookContentInference.sourceRuntimeModeMarkers(for: source)
        )
    }

    var explicitlyInferredContentKind: OnlineBookContentKind? {
        OnlineBookContentInference.explicitKind(
            runtimeVariables: runtimeVariables,
            urls: [bookUrl, tocUrl],
            metadataText: [kind, intro, lastChapter]
        )
    }
}

/// Picks one deterministic validation candidate without crossing an explicitly
/// declared content boundary. Aggregate sources can return text, audio and manga
/// in the same result list; validating the first URL blindly can therefore test a
/// secondary mode instead of the source's declared primary mode.
enum OnlineBookValidationSelector {
    static func preferredBook(from books: [OnlineBook], for source: BookSource) -> OnlineBook? {
        let candidates = books.filter {
            !$0.bookUrl.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        guard let expectedKind = declaredContentKind(for: source.bookSourceType) else {
            return candidates.first
        }
        if let matching = candidates.first(where: {
            $0.explicitlyInferredContentKind == expectedKind
        }) {
            return matching
        }
        return candidates.first(where: { $0.explicitlyInferredContentKind == nil })
    }

    private static func declaredContentKind(for sourceType: Int) -> OnlineBookContentKind? {
        switch sourceType {
        case 0: return .text
        case 1: return .audio
        case 2: return .manga
        case 4: return .video
        default: return nil
        }
    }
}

// MARK: - Online Chapter Reference

struct OnlineChapterRef: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var index: Int
    var title: String
    var url: String
    var isVolume: Bool = false
    var isVip: Bool = false
    var isPay: Bool = false
    /// What the source's `ruleToc.updateTime` read for this row — legado keeps it as
    /// `BookChapter.tag` — shown verbatim under the title in 目錄. A source writes whatever it
    /// likes there (「2024-05-01」, 「卷一 | 3小時前」), so it stays text. Nil when the source
    /// has no such rule or the rule read nothing, which also keeps a list from a source
    /// without one encoding exactly as before.
    var updateTime: String? = nil
    /// Set by builds up to 3.0.0 (136) whenever a chapter was cached; nothing sets it now,
    /// and nothing decides by it — the cached file is the record (`isChapterCached`). Lists
    /// saved before still carry it, and the refresh carries it over, so no list is written
    /// again just to drop it.
    var cachedFilename: String? = nil
    var runtimeVariables: [String: String]? = nil
    var audioStartSeconds: Double? = nil
    var audioDurationSeconds: Double? = nil
    /// Local PDF books: how many document pages this chapter covers. Books saved
    /// before PDF support leave this unset.
    var pdfPageCount: Int? = nil
}

extension OnlineChapterRef {
    private enum CodingKeys: String, CodingKey {
        case id, index, title, url, isVolume, isVip, isPay, updateTime, cachedFilename
        case runtimeVariables, audioStartSeconds, audioDurationSeconds, pdfPageCount
    }

    /// Stored property defaults do not apply to synthesized Decodable. Older
    /// chapter records predate the volume/payment flags and media metadata, so
    /// decode those missing fields using the same defaults as newly created refs.
    /// Defining this in an extension preserves the existing memberwise initializer.
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        index = try values.decode(Int.self, forKey: .index)
        title = try values.decode(String.self, forKey: .title)
        url = try values.decode(String.self, forKey: .url)
        isVolume = try values.decodeIfPresent(Bool.self, forKey: .isVolume) ?? false
        isVip = try values.decodeIfPresent(Bool.self, forKey: .isVip) ?? false
        isPay = try values.decodeIfPresent(Bool.self, forKey: .isPay) ?? false
        updateTime = try values.decodeIfPresent(String.self, forKey: .updateTime)
        cachedFilename = try values.decodeIfPresent(String.self, forKey: .cachedFilename)
        runtimeVariables = try values.decodeIfPresent([String: String].self, forKey: .runtimeVariables)
        audioStartSeconds = try values.decodeIfPresent(Double.self, forKey: .audioStartSeconds)
        audioDurationSeconds = try values.decodeIfPresent(Double.self, forKey: .audioDurationSeconds)
        pdfPageCount = try values.decodeIfPresent(Int.self, forKey: .pdfPageCount)
    }

    var sanitizedContentURL: String {
        RuleEngine.sanitizeExtractedURL(url)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var hasLoadableContentURL: Bool {
        !sanitizedContentURL.isEmpty
    }

    var shouldRenderAsVolumeSeparator: Bool {
        isVolume || hasStrongVolumeSeparatorTitle || (!hasLoadableContentURL && hasVolumeSeparatorTitle)
    }

    var hasVolumeSeparatorTitle: Bool { Self.isVolumeSeparatorTitle(title) }

    /// Whether a chapter title reads as a volume heading rather than a chapter. Shared with
    /// the AI book summaries, which group chapters by volume.
    static func isVolumeSeparatorTitle(_ rawTitle: String) -> Bool {
        let title = ReaderHTMLUtilities.compactTitle(rawTitle)
        guard !title.isEmpty else { return false }
        if Self.strongVolumeSeparatorTitles.contains(title)
            || ["正文", "番外卷", "番外"].contains(title) {
            return true
        }
        // The pattern needs a leading 第 and a 卷; checking both first keeps the two regex
        // compilations below off the ordinary chapter title, asked once per chapter.
        if title.hasPrefix("第"), title.contains("卷"),
           title.range(of: #"^第[0-9一二三四五六七八九十百千万]+卷"#, options: .regularExpression) != nil,
           title.range(of: #"[章节章回][0-9一二三四五六七八九十百千万]*"#, options: .regularExpression) == nil {
            return true
        }
        return false
    }

    private var hasStrongVolumeSeparatorTitle: Bool {
        Self.strongVolumeSeparatorTitles.contains(ReaderHTMLUtilities.compactTitle(title))
    }

    private static var strongVolumeSeparatorTitles: Set<String> {
        ["作品相关", "作品相關", "正文卷"]
    }
}

extension BookSource {
    var legadoReviewContext: ReaderHTMLUtilities.LegadoReviewContext {
        ReaderHTMLUtilities.LegadoReviewContext(
            sourceName: bookSourceName,
            sourceURL: bookSourceUrl,
            sourceVariableJSON: BookSourceRuntimeStateStore.shared.sourceVariableJSON(for: bookSourceUrl)
        )
    }

    var usesLegadoRuntimeSession: Bool {
        !jsLib.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    /// Legado checks each stage's first response with this script (`loginCheckJs`).
    var hasLoginCheckJs: Bool {
        !loginCheckJs.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    /// Whether two sources carry the same rules and settings — everything except the
    /// `lastUpdateTime` sync clock.
    ///
    /// Compared as sorted-key JSON. Without `.sortedKeys`, `JSONEncoder` orders keys
    /// differently on every call, so two encodes of one unchanged source seldom matched:
    /// re-importing a pack or re-saving an untouched source advanced the sync clock, and
    /// closing an untouched source editor asked whether to discard changes.
    func hasSameContent(as other: BookSource) -> Bool {
        var lhs = self
        var rhs = other
        lhs.lastUpdateTime = 0
        rhs.lastUpdateTime = 0
        let encoder = JSONEncoder()
        encoder.outputFormatting = .sortedKeys
        do {
            return try encoder.encode(lhs) == encoder.encode(rhs)
        } catch {
            AppLogger.cache("BookSource could not be encoded for comparison", error: error)
            return false
        }
    }

    func shouldUseLegadoRuntimeFetch(for ruleUrl: String? = nil) -> Bool {
        let url = ruleUrl?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        // Options go to the runtime however they are spaced (`url , {…}` too): the native
        // search path no longer parses them, after its own copy serialized a scalar `body`
        // into an Objective-C exception that crashed the app.
        return url.hasPrefix("data:")
            || AnalyzeUrl.hasOptions(url)
            || url.hasPrefix("<js>")
            || url.hasPrefix("@js:")
            || (usesLegadoRuntimeSession && urlContainsRuntimeTemplate(url))
    }

    private func urlContainsRuntimeTemplate(_ url: String) -> Bool {
        guard url.contains("{{") else { return false }
        guard let regex = try? NSRegularExpression(pattern: #"\{\{([\s\S]*?)\}\}"#) else {
            return false
        }

        let nsRange = NSRange(url.startIndex..., in: url)
        return regex.matches(in: url, range: nsRange).contains { match in
            guard let range = Range(match.range(at: 1), in: url) else { return false }
            let expression = String(url[range])
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .replacingOccurrences(of: " ", with: "")
                .lowercased()
            return !Self.fastSearchTemplateExpressions.contains(expression)
        }
    }

    private static let fastSearchTemplateExpressions: Set<String> = [
        "key",
        "page",
        "key,gb2312",
        "key,gbk"
    ]
}
