import YueduCoreText
import Combine
import UIKit

/// Native EPUB reader adapter. Reflowable BrowserAuto chapters use the YueduCoreText
/// package through BrowserLayoutPageEngine for pagination and continuous scrolling.
/// CoreTextPageEngine remains the legacy delegate; fixed-layout EPUB has its own route.
@MainActor
final class EPUBPageRenderer: ObservableObject {

    // MARK: - CoreText engine

    private(set) var engine: (any PageRenderingProvider)? {
        didSet { bindPageBarsToEngine() }
    }

    /// The reader owns this before an asynchronous EPUB open creates its engine.
    /// Keep it on the renderer so every engine creation/replacement receives the
    /// same bar settings, including TXT and online source replacements.
    var pageBarsProvider: ((Int) -> ReaderPageBars?)? {
        didSet { bindPageBarsToEngine() }
    }

    private func bindPageBarsToEngine() {
        guard let provider = engine as? PageBarsProviding else { return }
        provider.pageBarsProvider = pageBarsProvider
        provider.refreshPageBars()
    }
    @Published private(set) var layoutMode: EPUBLayoutMode = .reflowable
    @Published private(set) var pageProgressionDirection: EPUBPageProgressionDirection = .default
    @Published private(set) var fixedLayoutSpread: FixedLayoutSpread = .auto
    @Published private(set) var fixedLayoutOrientation: FixedLayoutOrientation = .auto
    @Published private(set) var fixedLayoutViewport: FixedLayoutViewport?
    @Published private(set) var mediaOverlaysByChapter: [Int: EPUBMediaOverlay] = [:]
    /// Which way the publisher EPUB being read reads, known before its first layout
    /// (`resolveWritingModes(for:)`). Nil for a book laid out in the user's 排版方向: TXT, online,
    /// Aozora.
    @Published private(set) var bookDirection: BookDirection?
    /// The writing mode of the scroll *segment* on screen: consecutive chapters of one mode, which
    /// scroll mode shows on that mode's axis. Nil until scroll mode first shows the book, and for a book
    /// laid out in one mode. The reader's scroll settings and axis follow it.
    @Published private(set) var scrollSegmentMode: ReaderWritingMode?
    /// Latest wins among overlapping `enterScrollSegment` calls.
    private var scrollSegmentGeneration: UInt64 = 0
    /// The EPUB's writing modes with the ingestion they were read from, which `load` hands its browser
    /// engine so the chapters the resolver read are not ingested again.
    private var writingModes: (session: PublicationSession, modes: BookWritingModes,
                               resource: EPUBBrowserLayoutResourceAdapter)?
    /// Holds the EPUB builder so notifyViewportSize can update renderSize.
    private var epubBuilder: EPUBAttributedStringBuilder?
    private var onlineBuilder: OnlineProviderAttributedStringBuilder?
    private var publicationSession: PublicationSession?
    /// Whichever builder the current book loaded, kept only so whole-book text can be read
    /// without the layout engine. The three typed properties above serve layout; this one
    /// answers "what does chapter N say", which the layout cache cannot — it holds five
    /// chapters, and the AI features need the book.
    private var contentBuilder: (any AttributedStringBuilding)?
    /// The one document store the paged and scroll engines share for the current book.
    private var chapterDocumentStore: ChapterDocumentStore?
    /// 整章翻譯's translations for the book being read. Handed to every document store, so
    /// both engines lay out the same translated chapters.
    var translationSource: (any ReaderTranslationSource)? {
        didSet { chapterDocumentStore?.translationSource = translationSource }
    }
    /// Handed to every browser engine this renderer makes:
    /// `BrowserLayoutPageEngine.onBrowserChapterPictures`.
    var onBrowserChapterPictures: ((_ spine: Int, _ sourceText: String, _ pictures: BrowserPictureOffsets) -> Void)? {
        didSet { (engine as? BrowserLayoutPageEngine)?.onBrowserChapterPictures = onBrowserChapterPictures }
    }

    /// Scroll-mode-specific engine (alongside the page engine). Created automatically when builder is available.
    @Published private(set) var scrollEngine: CoreTextScrollEngine? {
        didSet {
            // Bridge the nested engine's isReady into a property the view observes
            // directly, so the scroll body can gate on a ready engine without a
            // white/blank flash. SwiftUI does not observe nested ObservableObjects.
            guard oldValue !== scrollEngine else { return }
            // ⟐ engine-churn probe. A device log showed the scroll reader being stood up four
            // times for a single book open, each with its own engine, each restoring the reading
            // position independently — which is most of what the user sees as "jumping". The
            // count is what tells the next capture whether a fix landed; the caller is named by
            // the matching `⟐ rebuildPages` line.
            if scrollEngine != nil {
                scrollEngineCreations += 1
                AppLogger.render("⟐ scrollEngine created #\(scrollEngineCreations)")
            }
            scrollEngineReady = scrollEngine?.isReady ?? false
            scrollReadyCancellable = scrollEngine?.$isReady
                .receive(on: DispatchQueue.main)
                .sink { [weak self] ready in self?.scrollEngineReady = ready }
            scrollInsertionCancellable = scrollEngine?.events
                .sink { [weak self] event in
                    if case .chunksInserted = event { self?.scrollChapterInsertions &+= 1 }
                }
        }
    }

    /// Counts chapters the scroll engine has laid out, so the view can react to a chapter's
    /// text becoming available — 整章翻譯 cannot start on a chapter before that.
    @Published private(set) var scrollChapterInsertions: UInt64 = 0
    private var scrollInsertionCancellable: AnyCancellable?

    /// How many scroll engines this renderer has created. Diagnostics only; see the probe above.
    private var scrollEngineCreations = 0

    /// Mirrors `scrollEngine?.isReady` reactively for the SwiftUI body.
    @Published private(set) var scrollEngineReady: Bool = false
    private var scrollReadyCancellable: AnyCancellable?

    @Published var isCoreTextReady: Bool = false
    @Published private(set) var pendingVisibleRefreshCommit: ReaderVisibleRefreshCommit?

    private struct RefreshRevisionSnapshot {
        let layout: UInt64
        let appearance: UInt64
        let content: UInt64
    }

    private struct RefreshRevisionCoverage {
        let layout: UInt64?
        let appearance: UInt64?
        let content: UInt64?

        static let none = RefreshRevisionCoverage(
            layout: nil,
            appearance: nil,
            content: nil
        )
    }

    private struct RefreshAppliedRevisionSnapshot {
        let pagedLayout: UInt64
        let pagedAppearance: UInt64
        let pagedContent: UInt64
        let scrollLayout: UInt64
        let scrollAppearance: UInt64
        let scrollContent: UInt64
    }

    private struct RefreshTransactionContext {
        let request: ReaderRenderRefreshRequest
        let revisions: RefreshRevisionSnapshot
        /// Resumed exactly once, then cleared. A superseded transaction answers its
        /// caller immediately but stays registered while its visible commit is still
        /// outstanding, so the host's acknowledgement can still record the coverage.
        var continuation: CheckedContinuation<ReaderRenderRefreshResult, Never>?
        var coverage: RefreshRevisionCoverage = .none
    }

    private enum RefreshPreparationResult {
        case requiresVisibleCommit(RefreshRevisionCoverage)
        case completed(RefreshRevisionCoverage)
        case failed(ReaderRenderRefreshFailure)
    }

    @MainActor
    private struct RefreshPreparation {
        let request: ReaderRenderRefreshRequest
        let revisions: RefreshRevisionSnapshot
        let applied: RefreshAppliedRevisionSnapshot
        let engine: (any PageRenderingProvider)?
        let scrollEngine: CoreTextScrollEngine?

        func run() async -> RefreshPreparationResult {
            switch request.mode {
            case .paged:
                return await preparePaged()
            case .scroll:
                return await prepareScroll()
            }
        }

        private func preparePaged() async -> RefreshPreparationResult {
            guard let engine else {
                return .failed(.engineUnavailable(.paged))
            }

            // A refresh that arrives before the view has reported a size finds the engine still
            // waiting in `pendingStartBookId`: there is nothing to lay out yet, and the deferred
            // start will do it at the right size with the settings `beginRefreshTransaction` has
            // already stored. Laying out at zero would shrink the engine to nothing. Not a
            // fallback — it is the precondition a layout has. Appearance and chapter content
            // need no size, so they still run.
            switch request.intent {
            case .layout, .documentStyle, .modeActivation:
                guard request.viewportSize.width > 0, request.viewportSize.height > 0 else {
                    return .completed(.none)
                }
            case .appearance, .chapterContent:
                break
            }

            if let browser = engine as? BrowserLayoutPageEngine {
                await browser.activatePagedLayout()
                await browser.preloadChapter(at: request.position.spineIndex)
            }
            let coverage: RefreshRevisionCoverage
            switch request.intent {
            case .layout, .documentStyle:
                await invalidatePagedLayout(
                    engine,
                    newSize: request.viewportSize,
                    ensuringSpine: request.position.spineIndex
                )
                coverage = RefreshRevisionCoverage(
                    layout: revisions.layout,
                    appearance: nil,
                    content: nil
                )
            case .appearance:
                engine.applyThemeChange(
                    textColor: request.settings.textColor,
                    backgroundColor: request.settings.backgroundColor
                )
                if let browser = engine as? BrowserLayoutPageEngine {
                    await browser.refreshRegexHighlightAppearanceIfNeeded()
                }
                coverage = RefreshRevisionCoverage(
                    layout: nil,
                    appearance: revisions.appearance,
                    content: nil
                )
            case .chapterContent(let chapterIndex):
                // Chapter *supply* deliberately does not happen here — same rule as
                // `prepareScroll`. This closure runs inside a latest-wins transaction whose
                // successor cancels it and calls `cancelPendingWork()`, so loading a chapter
                // from in here let one chapter's arrival kill another's mid-load. Because
                // `notifyChapterDataChanged` clears the layout before rebuilding it, the
                // victim was left with nothing and no announcement, stranding the visible
                // chapter on its placeholder forever. `submitChapterContentRefresh` feeds
                // the engine directly and this intent only re-places the visible page.
                coverage = RefreshRevisionCoverage(
                    layout: nil,
                    appearance: nil,
                    content: revisions.content
                )
                if chapterIndex != request.position.spineIndex {
                    return .completed(coverage)
                }
            case .modeActivation:
                let needsLayout = applied.pagedLayout < revisions.layout
                let needsAppearance =
                    applied.pagedAppearance < revisions.appearance
                let needsContent = applied.pagedContent < revisions.content
                guard needsLayout || needsAppearance || needsContent else {
                    return .completed(.none)
                }
                await invalidatePagedLayout(
                    engine,
                    newSize: request.viewportSize,
                    ensuringSpine: request.position.spineIndex
                )
                coverage = RefreshRevisionCoverage(
                    layout: needsLayout ? revisions.layout : nil,
                    appearance: needsAppearance ? revisions.appearance : nil,
                    content: needsContent ? revisions.content : nil
                )
            }

            guard hasPagedLayout(
                for: request.position,
                engine: engine
            ) else {
                return .failed(
                    .layoutUnavailable(request.position.spineIndex)
                )
            }
            return .requiresVisibleCommit(coverage)
        }

        private func prepareScroll() async -> RefreshPreparationResult {
            guard let scrollEngine else {
                return .failed(.engineUnavailable(.scroll))
            }
            // The scroll engine's settings carry the segment's mode, which the request's may not.
            (engine as? BrowserLayoutPageEngine)?.usesViewportScrolling = !scrollEngine.renderSettings.writingMode.isVertical

            switch request.intent {
            case .layout, .documentStyle:
                return .requiresVisibleCommit(
                    RefreshRevisionCoverage(
                        layout: revisions.layout,
                        appearance: nil,
                        content: nil
                    )
                )
            case .appearance:
                return .requiresVisibleCommit(
                    RefreshRevisionCoverage(
                        layout: nil,
                        appearance: revisions.appearance,
                        content: nil
                    )
                )
            case .chapterContent(let chapterIndex):
                // Chapter *supply* deliberately does not happen here. A refresh
                // transaction is latest-wins and cancels the preparation task of the
                // one before it, so loading a chapter from inside this closure let one
                // chapter's arrival cancel another's mid-load and strand it on its
                // placeholder forever. `ReaderView` drives `retryChapterIfNeeded` from
                // the chapter-ready event instead, and only asks for a refresh here
                // when the engine still has nothing for the visible chapter.
                if chapterIndex == request.position.spineIndex {
                    scrollEngine.invalidateChapterDocument(at: chapterIndex)
                    return .requiresVisibleCommit(
                        RefreshRevisionCoverage(
                            layout: nil,
                            appearance: nil,
                            content: revisions.content
                        )
                    )
                }
                return .completed(
                    RefreshRevisionCoverage(
                        layout: nil,
                        appearance: nil,
                        content: nil
                    )
                )
            case .modeActivation:
                let needsLayout = applied.scrollLayout < revisions.layout
                let needsAppearance =
                    applied.scrollAppearance < revisions.appearance
                let needsContent = applied.scrollContent < revisions.content
                guard needsLayout || needsAppearance || needsContent else {
                    return .completed(.none)
                }
                return .requiresVisibleCommit(
                    RefreshRevisionCoverage(
                        layout: needsLayout ? revisions.layout : nil,
                        appearance: needsAppearance
                            ? revisions.appearance
                            : nil,
                        content: needsContent ? revisions.content : nil
                    )
                )
            }
        }

        private func invalidatePagedLayout(
            _ engine: any PageRenderingProvider,
            newSize: CGSize,
            ensuringSpine spineIndex: Int
        ) async {
            if let coreTextEngine = engine as? CoreTextPageEngine {
                await coreTextEngine.invalidateLayout(
                    newSize: newSize,
                    ensuringSpine: spineIndex
                )
            } else if let browser = engine as? BrowserLayoutPageEngine {
                await browser.invalidateLayout(newSize: newSize, ensuringSpine: spineIndex)
            } else {
                await engine.invalidateLayout(newSize: newSize)
            }
        }

        private func hasPagedLayout(
            for position: CoreTextReadingPosition,
            engine: any PageRenderingProvider
        ) -> Bool {
            if engine is FixedLayoutPageEngine {
                return engine.pageIndex(for: position) != nil
            }
            // One question, one answer, whichever engine is installed. The
            // browser engine keeps its chapters outside the legacy `layouts`
            // dictionary and used to need a special case here that asked
            // whether an engine had merely been CHOSEN for the chapter — a
            // weaker claim than "it is laid out", and the reason a refresh
            // could commit onto a chapter that had nothing to show.
            return engine.chapterPagination(
                forSpine: position.spineIndex,
                charOffset: position.charOffset
            ) != nil
        }
    }

    private var nextRefreshTransactionID: UInt64 = 0
    private var currentRefreshTransactionID: UInt64 = 0
    private var refreshTransactions: [UInt64: RefreshTransactionContext] = [:]
    private var refreshPreparationTasks: [UInt64: Task<Void, Never>] = [:]
    private var latestLayoutRenderSettings: ReaderRenderSettings?
    private var latestAppearanceRenderSettings: ReaderRenderSettings?
    // Revision 1 is the initial loaded snapshot. Applied revisions start at 0
    // so a mode's first activation remains stale until its host acknowledges it.
    private var layoutRevision: UInt64 = 1
    private var appearanceRevision: UInt64 = 1
    private var contentRevision: UInt64 = 1
    private var pagedAppliedLayoutRevision: UInt64 = 0
    private var pagedAppliedAppearanceRevision: UInt64 = 0
    private var pagedAppliedContentRevision: UInt64 = 0
    private var scrollAppliedLayoutRevision: UInt64 = 0
    private var scrollAppliedAppearanceRevision: UInt64 = 0
    private var scrollAppliedContentRevision: UInt64 = 0

    var activeRefreshPreparationCount: Int {
        refreshPreparationTasks.count
    }
    private(set) var refreshPreparationCompletionCount: UInt64 = 0

    var isFixedLayout: Bool {
        layoutMode == .prePaginated
    }

    /// Resolves a publisher EPUB's writing modes before `load`, so the reader knows which way the book
    /// reads before anything is laid out or built for it. `load` and `savedPositionPictures` of the same
    /// session use them.
    @discardableResult
    func resolveWritingModes(for session: PublicationSession) async -> BookWritingModes {
        if let writingModes, writingModes.session === session { return writingModes.modes }
        let start = SourcePerfTrace.now
        let resource = EPUBBrowserLayoutResourceAdapter(session: session)
        let modes = await BookWritingModes.resolve(session: session, resource: resource)
        SourcePerfTrace.record("reader.open.writingModes", "rtl=\(modes.direction.isRTL)", since: start, thresholdMs: 0)
        writingModes = (session, modes, resource)
        bookDirection = modes.direction
        return modes
    }

    /// Scroll mode cannot show the book before it knows the segment of the chapter it opens on.
    var scrollSegmentIsPending: Bool { writingModes != nil && scrollSegmentMode == nil }

    enum ScrollSegmentEntry: Equatable {
        /// The chapter is in the segment on screen (or the book has none).
        case unchanged
        /// Its segment is the one on screen now. The reader's scroll settings change with it, and the
        /// refresh that follows lays the segment out at the reading position.
        case entered
        /// A later call decided the segment.
        case superseded
    }

    /// Makes the segment holding `spine` the one scroll mode shows: the one way the segment changes. The
    /// scroll engine lays out in its mode from here on, and so does the browser engine's continuous
    /// layout, which follows the scroll engine's settings.
    func enterScrollSegment(containing spine: Int) async -> ScrollSegmentEntry {
        guard let writingModes else { return .unchanged }
        scrollSegmentGeneration &+= 1
        let generation = scrollSegmentGeneration
        let mode = await writingModes.modes.writingMode(forSpine: spine)
        guard generation == scrollSegmentGeneration, self.writingModes?.session === writingModes.session else {
            return .superseded
        }
        guard mode != scrollSegmentMode else { return .unchanged }
        if let scrollEngine {
            var settings = scrollEngine.renderSettings
            settings.writingMode = mode
            scrollEngine.updateRenderSettings(settings)
        }
        (engine as? BrowserLayoutPageEngine)?.usesViewportScrolling = !mode.isVertical
        scrollSegmentMode = mode
        return .entered
    }

    /// Paged mode shows no segment; the next scroll session decides its own.
    func leaveScrollSegment() {
        scrollSegmentGeneration &+= 1
        scrollSegmentMode = nil
    }

    /// The writing mode of a chapter of the EPUB being read, once it is known; nil for a book in the
    /// user's 排版方向 and a chapter not resolved yet.
    func cachedWritingMode(forSpine spine: Int) -> ReaderWritingMode? {
        guard let writingModes, writingModes.session === publicationSession else { return nil }
        return writingModes.modes.cachedWritingMode(forSpine: spine)
    }

    func resourceURL(for href: String) -> URL? {
        publicationSession?.resourceURL(for: href)
    }

    /// Tracks the current global page index (kept in sync by ReaderView / CoreTextPageEngineView).
    var currentEpubPage: Int = 0

    /// Last non-zero page size reported by ReaderView via notifyViewportSize(). Zero until the
    /// reader's own view has been laid out: the screen is not a stand-in, because the reader is
    /// often not the screen's size (a Stage Manager or Split View window), and an engine started
    /// at the screen's size lays the book out for a window it is not in.
    private var lastViewportSize: CGSize = .zero
    /// bookId waiting for a valid viewport size before CoreTextPageEngine.start() can run.
    private var pendingStartBookId: String?

    private func logProgress(_ message: String) {
        let line = "[ProgressTrace][EPUBPageRenderer] \(message)"
        print(line)
        NSLog("%@", line)
    }

    private func elapsedMs(since start: TimeInterval) -> String {
        let value = (ProcessInfo.processInfo.systemUptime - start) * 1000
        return String(format: "%.1f", value)
    }

    // MARK: - Load

    /// EPUB path — creates the legacy delegate and a BrowserAuto adapter backed by YueduCoreText.
    /// If renderSize is zero (view not yet laid out), start is deferred until
    /// notifyViewportSize() is called with a valid size.
    func load(
        publicationSession session: PublicationSession,
        bookIdentifier: String,
        renderSize: CGSize,
        settings: ReaderRenderSettings,
        continuousScrolling: Bool = false
    ) {
        layoutMode = session.layoutMode
        pageProgressionDirection = session.pageProgressionDirection
        fixedLayoutSpread = session.fixedLayoutSpread
        fixedLayoutOrientation = session.fixedLayoutOrientation
        fixedLayoutViewport = session.fixedLayoutViewport
        mediaOverlaysByChapter = session.mediaOverlaysByChapter
        publicationSession = session
        // A session whose modes were not resolved (a caller that fixes the mode in `settings`) lays every
        // chapter out in `settings.writingMode`.
        let resolved = writingModes?.session === session ? writingModes : nil
        writingModes = resolved
        bookDirection = resolved?.modes.direction
        scrollSegmentMode = nil

        let effectiveSize = renderSize.width > 0 ? renderSize : lastViewportSize

        guard session.layoutMode != .prePaginated else {
            let fixedEngine = FixedLayoutPageEngine(session: session, renderSize: effectiveSize)
            self.engine = fixedEngine
            guard effectiveSize.width > 0 else {
                // Same deferral as the reflowable path below: `notifyViewportSize` starts it.
                isCoreTextReady = false
                pendingStartBookId = bookIdentifier
                logProgress("load deferred bookId=\(bookIdentifier) reason=invalidRenderSize fixedLayout size=\(renderSize)")
                return
            }
            isCoreTextReady = true
            Task {
                await fixedEngine.start(renderSize: effectiveSize, bookId: bookIdentifier)
            }
            return
        }

        let progressDir = StorageLocations.epubCharOffsets.appendingPathComponent(bookIdentifier)
        let store = CharOffsetStore(directoryURL: progressDir)

        self.onlineBuilder = nil
        let builder = EPUBAttributedStringBuilder(
            session: session,
            renderSize: effectiveSize
        )
        let chapterDocumentStore = ChapterDocumentStore(builder: builder)
        chapterDocumentStore.translationSource = translationSource
        self.chapterDocumentStore = chapterDocumentStore
        self.epubBuilder = builder
        self.contentBuilder = builder
        let newEngine = CoreTextPageEngine(
            attributedBuilder: builder,
            renderSettings: settings,
            chapterDocumentStore: chapterDocumentStore,
            offsetStore: store
        )
        self.scrollEngine = CoreTextScrollEngine(
            builder: builder,
            renderSettings: settings,
            chapterDocumentStore: chapterDocumentStore
        )

        newEngine.applyThemeChange(textColor: settings.textColor, backgroundColor: settings.backgroundColor)
        let browserEngine = BrowserLayoutPageEngine(
            resource: resolved?.resource ?? EPUBBrowserLayoutResourceAdapter(session: session),
            delegate: newEngine, settings: settings, mode: .browserAuto
        )
        browserEngine.writingModes = resolved?.modes
        scrollEngine?.writingModes = resolved?.modes
        browserEngine.onBrowserChapterPictures = onBrowserChapterPictures
        self.engine = browserEngine
        browserEngine.usesViewportScrolling = continuousScrolling && !settings.writingMode.isVertical
        self.scrollEngine?.browserAutoEngine = self.engine as? BrowserLayoutPageEngine
        isCoreTextReady = false

        if effectiveSize.width > 0 {
            let startUptime = ProcessInfo.processInfo.systemUptime
            logProgress("load start bookId=\(bookIdentifier) renderSize=\(effectiveSize)")
            Task {
                await self.engine?.start(renderSize: effectiveSize, bookId: bookIdentifier)
                self.isCoreTextReady = true
                self.logProgress(
                    "load ready bookId=\(bookIdentifier) totalPages=\(self.engine?.totalPages ?? 0) elapsedMs=\(self.elapsedMs(since: startUptime))"
                )
            }
        } else {
            pendingStartBookId = bookIdentifier
            logProgress("load deferred bookId=\(bookIdentifier) reason=invalidRenderSize size=\(renderSize)")
        }
    }

    /// `spine`'s picture characters as this book's browser engine would read the chapter, for a
    /// reading position saved before 0.11 that must move before the reader restores it. Asks an
    /// engine of its own, which lays out and publishes nothing; nil for a chapter the legacy
    /// engine renders.
    func savedPositionPictures(
        publicationSession session: PublicationSession, bookIdentifier: String, renderSize: CGSize,
        settings: ReaderRenderSettings, spine: Int
    ) async -> BrowserPictureOffsets? {
        guard session.layoutMode != .prePaginated, renderSize.width > 0, renderSize.height > 0 else { return nil }
        let builder = EPUBAttributedStringBuilder(session: session, renderSize: renderSize)
        // The same offset store `load` opens for this book; this engine never writes to it.
        let delegate = CoreTextPageEngine(
            attributedBuilder: builder, renderSettings: settings,
            chapterDocumentStore: ChapterDocumentStore(builder: builder),
            offsetStore: CharOffsetStore(directoryURL: StorageLocations.epubCharOffsets.appendingPathComponent(bookIdentifier))
        )
        let resolved = writingModes?.session === session ? writingModes : nil
        let engine = BrowserLayoutPageEngine(
            resource: resolved?.resource ?? EPUBBrowserLayoutResourceAdapter(session: session),
            delegate: delegate, settings: settings, mode: .browserAuto
        )
        engine.writingModes = resolved?.modes
        return await engine.pictureOffsets(forSpine: spine, renderSize: renderSize)
    }

    func loadTXT(
        text: String,
        title: String,
        bookIdentifier: String,
        renderSize: CGSize,
        settings: ReaderRenderSettings,
        preparedChapters: [UnifiedChapter]? = nil
    ) {
        let chapters = preparedChapters ?? TXTChapterParser.parseUnifiedChapters(text, bookTitle: title)
        let builder = NodeAttributedStringBuilder(chapters: chapters)
        loadTXT(
            attributedBuilder: builder,
            bookIdentifier: bookIdentifier,
            renderSize: renderSize,
            settings: settings
        )
    }

    func loadTXT(
        attributedBuilder: any AttributedStringBuilding,
        bookIdentifier: String,
        renderSize: CGSize,
        settings: ReaderRenderSettings
    ) {
        mediaOverlaysByChapter = [:]
        fixedLayoutViewport = nil
        fixedLayoutSpread = .auto
        fixedLayoutOrientation = .auto
        pageProgressionDirection = .default
        layoutMode = .reflowable
        publicationSession = nil
        writingModes = nil
        bookDirection = nil
        scrollSegmentMode = nil
        let progressDir = StorageLocations.epubCharOffsets.appendingPathComponent(bookIdentifier)
        let store = CharOffsetStore(directoryURL: progressDir)
        let chapterDocumentStore = ChapterDocumentStore(builder: attributedBuilder)
        chapterDocumentStore.translationSource = translationSource
        self.chapterDocumentStore = chapterDocumentStore
        let newEngine = CoreTextPageEngine(
            attributedBuilder: attributedBuilder,
            renderSettings: settings,
            chapterDocumentStore: chapterDocumentStore,
            offsetStore: store
        )
        newEngine.applyThemeChange(textColor: settings.textColor, backgroundColor: settings.backgroundColor)
        self.engine = newEngine
        self.epubBuilder = nil
        self.onlineBuilder = nil
        self.contentBuilder = attributedBuilder
        self.scrollEngine = CoreTextScrollEngine(
            builder: attributedBuilder,
            renderSettings: settings,
            chapterDocumentStore: chapterDocumentStore
        )
        isCoreTextReady = false

        let effectiveSize = renderSize.width > 0 ? renderSize : lastViewportSize

        if effectiveSize.width > 0 {
            // The scroll engine can build a chapter before the page engine's start tells the
            // builder its column, so the builder is told here too.
            (attributedBuilder as? RenderSizeAwareAttributedStringBuilding)?.updateRenderSize(effectiveSize)
            let startUptime = ProcessInfo.processInfo.systemUptime
            logProgress("loadTXT start bookId=\(bookIdentifier) renderSize=\(effectiveSize)")
            Task {
                await newEngine.start(renderSize: effectiveSize, bookId: bookIdentifier)
                guard self.engine === newEngine else { return }
                self.isCoreTextReady = true
                self.logProgress(
                    "loadTXT ready bookId=\(bookIdentifier) totalPages=\(newEngine.totalPages) elapsedMs=\(self.elapsedMs(since: startUptime))"
                )
            }
        } else {
            pendingStartBookId = bookIdentifier
            logProgress("loadTXT deferred bookId=\(bookIdentifier) reason=invalidRenderSize size=\(renderSize)")
        }
    }

    func loadWithProvider(
        contentProvider: any BookContentProvider,
        chapterSourceHrefs: [String?],
        bookIdentifier: String,
        renderSize: CGSize,
        settings: ReaderRenderSettings,
        customScheme: String = "reader-online",
        imageDecode: (@Sendable (Data, String) async -> Data?)? = nil,
        imageHeaders: [String: String] = [:],
        imageCacheDirectory: URL? = nil
    ) {
        writingModes = nil
        bookDirection = nil
        scrollSegmentMode = nil
        let progressDir = StorageLocations.epubCharOffsets.appendingPathComponent(bookIdentifier)
        let store = CharOffsetStore(directoryURL: progressDir)
        let resourceAdapter = UniversalBookResourceAdapter(
            contentProvider: contentProvider,
            chapterSourceHrefs: chapterSourceHrefs,
            customScheme: customScheme
        )
        let effectiveSizeForBuilder = renderSize.width > 0 ? renderSize : lastViewportSize
        let onlineBuilder = OnlineProviderAttributedStringBuilder(
            provider: contentProvider,
            renderSize: effectiveSizeForBuilder,
            resourceProvider: resourceAdapter,
            chapterSourceHrefs: chapterSourceHrefs,
            imageDecode: imageDecode,
            imageHeaders: imageHeaders,
            imageCacheDirectory: imageCacheDirectory
        )
        let chapterDocumentStore = ChapterDocumentStore(builder: onlineBuilder)
        chapterDocumentStore.translationSource = translationSource
        self.chapterDocumentStore = chapterDocumentStore
        let newEngine = CoreTextPageEngine(
            attributedBuilder: onlineBuilder,
            renderSettings: settings,
            chapterDocumentStore: chapterDocumentStore,
            offsetStore: store
        )
        newEngine.applyThemeChange(textColor: settings.textColor, backgroundColor: settings.backgroundColor)
        self.engine = newEngine
        self.onlineBuilder = onlineBuilder
        self.contentBuilder = onlineBuilder
        self.scrollEngine = CoreTextScrollEngine(
            builder: onlineBuilder,
            renderSettings: settings,
            chapterDocumentStore: chapterDocumentStore
        )
        isCoreTextReady = false

        let effectiveSize = renderSize.width > 0 ? renderSize : lastViewportSize

        if effectiveSize.width > 0 {
            let startUptime = ProcessInfo.processInfo.systemUptime
            logProgress("loadWithProvider start bookId=\(bookIdentifier) renderSize=\(effectiveSize)")
            Task {
                await newEngine.start(renderSize: effectiveSize, bookId: bookIdentifier)
                self.isCoreTextReady = true
                self.logProgress(
                    "loadWithProvider ready bookId=\(bookIdentifier) totalPages=\(newEngine.totalPages) elapsedMs=\(self.elapsedMs(since: startUptime))"
                )
            }
        } else {
            pendingStartBookId = bookIdentifier
            logProgress("loadWithProvider deferred bookId=\(bookIdentifier) reason=invalidRenderSize size=\(renderSize)")
        }
    }

    /// One chapter's text straight from the source — the epub archive, the mapped txt file,
    /// or the online chapter cache — with no layout and no network.
    ///
    /// See `AttributedStringBuilding.chapterPlainText(at:)` for why this cannot go through
    /// `engine.chapterText(forSpine:)`.
    func localChapterText(at index: Int, applyingReplaceRules: Bool = true) async -> AILocalChapterText {
        await contentBuilder?.localChapterText(at: index, applyingReplaceRules: applyingReplaceRules)
            ?? .init(text: nil, status: .unsupported)
    }

    /// Whether 替換規則 change what this book shows. See `AttributedStringBuilding.appliesReplaceRules`.
    var appliesReplaceRules: Bool { contentBuilder?.appliesReplaceRules ?? false }

    /// The chapter as laid out — the text reading positions and highlights count in — laying
    /// it out first if it is not. Nil when there is no engine or the chapter cannot be laid out.
    ///
    /// Locating something found in `localChapterText` (an AI citation, a search hit) on the
    /// page goes through here: the two texts can differ by a rendered title or whitespace.
    func laidOutChapterText(at index: Int) async -> String? {
        guard let engine else { return nil }
        let outcome = await engine.preloadChapter(at: index)
        guard outcome.isReady else { return nil }
        return engine.chapterText(forSpine: index)
    }

    func chapterSourceText(at index: Int) async -> String? {
        await contentBuilder?.chapterPlainText(at: index)
    }

    /// Called by ReaderView whenever its own window size changes, with the size one page is laid
    /// out in (half the window across a double-page spread). Stores the size and starts the engine
    /// if `load*` ran before the view had a size.
    func notifyViewportSize(_ size: CGSize) {
        guard size.width > 0, size.height > 0 else { return }
        lastViewportSize = size
        // Every builder that composes against the column learns it here, before the deferred
        // start builds anything (EPUB, online and TXT alike — one path).
        (contentBuilder as? RenderSizeAwareAttributedStringBuilding)?.updateRenderSize(size)
        guard let bookId = pendingStartBookId, let eng = engine else { return }
        pendingStartBookId = nil
        let startUptime = ProcessInfo.processInfo.systemUptime
        logProgress("notifyViewportSize start deferred bookId=\(bookId) size=\(size)")
        Task {
            await eng.start(renderSize: size, bookId: bookId)
            self.isCoreTextReady = true
            self.logProgress(
                "notifyViewportSize ready deferred bookId=\(bookId) totalPages=\(eng.totalPages) elapsedMs=\(self.elapsedMs(since: startUptime))"
            )
        }
    }

    // MARK: - Progress presentation

    /// Called at page-turn time so the renderer can expose the current page for UI.
    /// Position persistence is owned by ReaderNavigator/ReadingPositionStore.
    func updateCurrentPosition(globalPage: Int, engine eng: any PageRenderingProvider) {
        currentEpubPage = globalPage
        let (spine, offset) = eng.charOffset(forPage: globalPage)
        logProgress("updateCurrentPosition globalPage=\(globalPage) spine=\(spine) charOffset=\(offset)")
    }

    func resolveInternalLink(_ href: String, fromSpineIndex spineIndex: Int) async -> Int? {
        await engine?.resolveInternalLink(href, fromSpineIndex: spineIndex)
    }

    // MARK: - Layout / settings

    func setFontSize(_ size: CGFloat) {
        guard let eng = engine else { return }
        Task { await eng.invalidateLayout(newSize: eng.renderSize) }
    }

    func setTheme(_ theme: String) {
        let textColor: UIColor
        let bgColor: UIColor
        switch theme {
        case "dark", "night":
            textColor = .white
            bgColor = .black
        case "sepia":
            textColor = UIColor(red: 0.3, green: 0.2, blue: 0.1, alpha: 1)
            bgColor = UIColor(red: 0.97, green: 0.93, blue: 0.84, alpha: 1)
        case "green":
            textColor = UIColor(red: 47 / 255, green: 61 / 255, blue: 47 / 255, alpha: 1)
            bgColor = UIColor(red: 207 / 255, green: 232 / 255, blue: 204 / 255, alpha: 1)
        default:
            textColor = .label
            bgColor = .systemBackground
        }
        engine?.applyThemeChange(textColor: textColor, backgroundColor: bgColor)
    }

    func setPageMargins(horizontal: CGFloat, vertical: CGFloat) {
        guard let eng = engine else { return }
        Task { await eng.invalidateLayout(newSize: eng.renderSize) }
    }

    func invalidateCoreTextLayout() {
        guard let eng = engine else { return }
        Task { await eng.invalidateLayout(newSize: eng.renderSize) }
    }

    func updateRenderSettings(_ settings: ReaderRenderSettings) {
        engine?.updateRenderSettings(settings)
        // While a segment is shown, the scroll engine lays out its mode whatever a request carries: a
        // refresh submitted before the segment was entered (entering scroll mode submits one at once)
        // reaches here after it, with the book's mode.
        var scrollSettings = settings
        if let scrollSegmentMode { scrollSettings.writingMode = scrollSegmentMode }
        scrollEngine?.updateRenderSettings(scrollSettings)
    }

    // MARK: - Refresh transactions

    func refresh(
        _ request: ReaderRenderRefreshRequest
    ) async -> ReaderRenderRefreshResult {
        await withCheckedContinuation { continuation in
            beginRefreshTransaction(
                request: request,
                continuation: continuation
            )
        }
    }

    func finishVisibleRefresh(
        transactionID: UInt64,
        outcome: ReaderVisibleRefreshOutcome
    ) {
        guard pendingVisibleRefreshCommit?.transactionID == transactionID,
              let context = refreshTransactions.removeValue(forKey: transactionID)
        else { return }

        pendingVisibleRefreshCommit = nil
        switch outcome {
        case .applied:
            apply(
                context.coverage,
                to: context.request.mode
            )
            context.continuation?.resume(
                returning: .completed(transactionID: transactionID)
            )
        case .failed(let failure):
            context.continuation?.resume(
                returning: .failed(
                    transactionID: transactionID,
                    failure: failure
                )
            )
        }
    }

    private func beginRefreshTransaction(
        request: ReaderRenderRefreshRequest,
        continuation: CheckedContinuation<ReaderRenderRefreshResult, Never>
    ) {
        nextRefreshTransactionID &+= 1
        currentRefreshTransactionID = nextRefreshTransactionID
        let transactionID = currentRefreshTransactionID

        // A published visible commit is a command the host may not have consumed yet:
        // SwiftUI applies `pendingVisibleRefreshCommit` on its own update pass, so
        // clearing it here dropped the scroll reslice outright whenever a second
        // refresh arrived first. Changing an online chapter always does that —
        // `handleChapterStateChanges` prefetches the adjacent chapters on the same
        // `.ready` transition, and each of those completions submits its own refresh —
        // which left the chapter blank forever. Keep the commit outstanding instead;
        // a newer commit replaces it in `completeRefreshPreparation`, and only the
        // host's acknowledgement clears it.
        let outstandingCommitID = pendingVisibleRefreshCommit?.transactionID
        let supersededTransactions = refreshTransactions
        refreshTransactions.removeAll(keepingCapacity: true)
        let supersededPreparationTasks = refreshPreparationTasks
        refreshPreparationTasks.removeAll(keepingCapacity: true)
        supersededPreparationTasks.values.forEach { $0.cancel() }
        for (supersededID, context) in supersededTransactions {
            context.continuation?.resume(
                returning: .superseded(transactionID: supersededID)
            )
            // The caller is answered, but the host still owes this commit an
            // acknowledgement — keep the coverage so `finishVisibleRefresh` can
            // record which revisions the mode ended up applying.
            guard supersededID == outstandingCommitID else { continue }
            var retained = context
            retained.continuation = nil
            refreshTransactions[supersededID] = retained
        }
        engine?.cancelPendingWork(cause: .refreshTransaction)

        switch request.intent {
        case .documentStyle:
            // Both modes share this store. Styles outside ReaderRenderSettings must
            // rebuild documents, including cached neighbours, and mark the inactive
            // mode's layout stale even though the settings snapshot is unchanged.
            scrollEngine?.invalidateChapterDocuments()
            layoutRevision &+= 1
        case .layout:
            if latestLayoutRenderSettings != request.settings {
                latestLayoutRenderSettings = request.settings
                layoutRevision &+= 1
            }
        case .appearance:
            if latestAppearanceRenderSettings != request.settings {
                latestAppearanceRenderSettings = request.settings
                appearanceRevision &+= 1
            }
        case .chapterContent:
            contentRevision &+= 1
        case .modeActivation:
            break
        }
        updateRenderSettings(request.settings)

        let revisions = RefreshRevisionSnapshot(
            layout: layoutRevision,
            appearance: appearanceRevision,
            content: contentRevision
        )
        refreshTransactions[transactionID] = RefreshTransactionContext(
            request: request,
            revisions: revisions,
            continuation: continuation
        )
        let preparation = RefreshPreparation(
            request: request,
            revisions: revisions,
            applied: RefreshAppliedRevisionSnapshot(
                pagedLayout: pagedAppliedLayoutRevision,
                pagedAppearance: pagedAppliedAppearanceRevision,
                pagedContent: pagedAppliedContentRevision,
                scrollLayout: scrollAppliedLayoutRevision,
                scrollAppearance: scrollAppliedAppearanceRevision,
                scrollContent: scrollAppliedContentRevision
            ),
            engine: engine,
            scrollEngine: scrollEngine
        )
        refreshPreparationTasks[transactionID] = Task {
            @MainActor [weak self] in
            let result = await preparation.run()
            self?.completeRefreshPreparation(
                transactionID: transactionID,
                result: result
            )
        }
    }

    private func completeRefreshPreparation(
        transactionID: UInt64,
        result: RefreshPreparationResult
    ) {
        refreshPreparationCompletionCount &+= 1
        refreshPreparationTasks.removeValue(forKey: transactionID)
        guard transactionID == currentRefreshTransactionID,
              var currentContext = refreshTransactions[transactionID]
        else { return }

        switch result {
        case .requiresVisibleCommit(let coverage):
            currentContext.coverage = coverage
            // This commit replaces any still-outstanding one, so the transaction that
            // owned the previous commit is now unreachable — drop its retained context.
            if let previousCommitID = pendingVisibleRefreshCommit?.transactionID,
               previousCommitID != transactionID {
                refreshTransactions.removeValue(forKey: previousCommitID)
            }
            refreshTransactions[transactionID] = currentContext
            pendingVisibleRefreshCommit = ReaderVisibleRefreshCommit(
                transactionID: transactionID,
                mode: currentContext.request.mode,
                position: currentContext.request.position
            )
        case .completed(let coverage):
            refreshTransactions.removeValue(forKey: transactionID)
            apply(coverage, to: currentContext.request.mode)
            currentContext.continuation?.resume(
                returning: .completed(transactionID: transactionID)
            )
        case .failed(let failure):
            refreshTransactions.removeValue(forKey: transactionID)
            currentContext.continuation?.resume(
                returning: .failed(
                    transactionID: transactionID,
                    failure: failure
                )
            )
        }
    }

    private func apply(
        _ coverage: RefreshRevisionCoverage,
        to mode: ReaderDisplayMode
    ) {
        switch mode {
        case .paged:
            if let revision = coverage.layout {
                pagedAppliedLayoutRevision = max(
                    pagedAppliedLayoutRevision,
                    revision
                )
            }
            if let revision = coverage.appearance {
                pagedAppliedAppearanceRevision = max(
                    pagedAppliedAppearanceRevision,
                    revision
                )
            }
            if let revision = coverage.content {
                pagedAppliedContentRevision = max(
                    pagedAppliedContentRevision,
                    revision
                )
            }
        case .scroll:
            if let revision = coverage.layout {
                scrollAppliedLayoutRevision = max(
                    scrollAppliedLayoutRevision,
                    revision
                )
            }
            if let revision = coverage.appearance {
                scrollAppliedAppearanceRevision = max(
                    scrollAppliedAppearanceRevision,
                    revision
                )
            }
            if let revision = coverage.content {
                scrollAppliedContentRevision = max(
                    scrollAppliedContentRevision,
                    revision
                )
            }
        }
    }
}
