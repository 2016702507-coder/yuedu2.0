import Foundation
import SwiftUI
import UIKit

// MARK: - Scope

/// Which app page a page-background config applies to. `global` is the default
/// every tab falls back to; the tab cases mirror `RootTabItem` raw values so a
/// tab and its scope stay in sync by construction.
enum AppearancePageBackgroundScope: String, CaseIterable, Codable, Identifiable {
    case global
    case bookshelf
    case explore
    case rss
    case settings
    case search

    var id: String { rawValue }

    var titleKey: String {
        switch self {
        case .global: return "全局默認"
        case .bookshelf: return "書架"
        case .explore: return "探索"
        case .rss: return "RSS 訂閱"
        case .settings: return "設定"
        case .search: return "搜索"
        }
    }

    var localizedTitle: String { localized(titleKey) }
}

// MARK: - Config

/// Per-scope page background: a light and a dark gradient (primary → secondary)
/// plus an optional background image per appearance. Every field is optional so
/// old persisted JSON keeps decoding as the struct grows.
struct AppearancePageBackgroundConfig: Codable, Hashable {
    var lightPrimaryHex: UInt32?
    var lightSecondaryHex: UInt32?
    var darkPrimaryHex: UInt32?
    var darkSecondaryHex: UInt32?
    var lightImageFileName: String?
    var darkImageFileName: String?
    var lightImageOpacity: Double?
    var darkImageOpacity: Double?

    var isEmpty: Bool {
        lightPrimaryHex == nil && lightSecondaryHex == nil
            && darkPrimaryHex == nil && darkSecondaryHex == nil
            && normalizedImageFileName(lightImageFileName) == nil
            && normalizedImageFileName(darkImageFileName) == nil
    }

    /// Whether this config paints anything for the given appearance.
    func hasContent(for colorScheme: ColorScheme) -> Bool {
        slice(for: colorScheme) != nil
    }

    func imageFileName(for colorScheme: ColorScheme) -> String? {
        normalizedImageFileName(colorScheme == .dark ? darkImageFileName : lightImageFileName)
    }

    func imageOpacity(for colorScheme: ColorScheme) -> Double {
        let raw = colorScheme == .dark ? darkImageOpacity : lightImageOpacity
        return raw ?? 1.0
    }

    mutating func setImageOpacity(_ opacity: Double?, for colorScheme: ColorScheme) {
        if colorScheme == .dark {
            darkImageOpacity = opacity
        } else {
            lightImageOpacity = opacity
        }
    }

    mutating func setImageFileName(_ fileName: String?, for colorScheme: ColorScheme) {
        if colorScheme == .dark {
            darkImageFileName = fileName
        } else {
            lightImageFileName = fileName
        }
    }

    func primaryHex(for colorScheme: ColorScheme) -> UInt32? {
        colorScheme == .dark ? darkPrimaryHex : lightPrimaryHex
    }

    func secondaryHex(for colorScheme: ColorScheme) -> UInt32? {
        colorScheme == .dark ? darkSecondaryHex : lightSecondaryHex
    }

    mutating func setPrimaryHex(_ hex: UInt32?, for colorScheme: ColorScheme) {
        if colorScheme == .dark { darkPrimaryHex = hex } else { lightPrimaryHex = hex }
    }

    mutating func setSecondaryHex(_ hex: UInt32?, for colorScheme: ColorScheme) {
        if colorScheme == .dark { darkSecondaryHex = hex } else { lightSecondaryHex = hex }
    }

    /// How strongly a pack's light picture shows in dark mode when the pack has none of
    /// its own for dark: dim enough over the dark page for light text to read on it.
    static let reusedDarkImageOpacity = 0.4

    /// A pack with a light picture and no dark one keeps its picture in dark mode, dimmed,
    /// instead of going to a plain dark page (「主題包的深色主題無腦變黑」, 2026-09-29).
    /// The same file serves both: the reference check that reclaims files sees it in use
    /// while either appearance shows it.
    mutating func reuseLightImageInDarkIfMissing() {
        guard normalizedImageFileName(darkImageFileName) == nil,
              let light = normalizedImageFileName(lightImageFileName) else { return }
        darkImageFileName = light
        darkImageOpacity = Self.reusedDarkImageOpacity
    }

    /// All image files this config references.
    var imageFileNames: [String] {
        [lightImageFileName, darkImageFileName].compactMap(normalizedImageFileName)
    }

    /// The renderable layer for one appearance, or nil when nothing is set for
    /// that appearance (callers then fall back to the global scope / system look).
    func slice(for colorScheme: ColorScheme) -> AppearancePageBackgroundSlice? {
        let slice = AppearancePageBackgroundSlice(
            primaryHex: primaryHex(for: colorScheme),
            secondaryHex: secondaryHex(for: colorScheme),
            imageFileName: imageFileName(for: colorScheme),
            imageOpacity: imageOpacity(for: colorScheme)
        )
        return slice.isEmpty ? nil : slice
    }

    private func normalizedImageFileName(_ name: String?) -> String? {
        guard let name, !name.isEmpty else { return nil }
        return name
    }
}

// MARK: - Resolved slice

/// What actually gets drawn behind a page for one appearance: a gradient made
/// of the configured colors, with an optional image painted over it.
struct AppearancePageBackgroundSlice: Hashable {
    var primaryHex: UInt32?
    var secondaryHex: UInt32?
    var imageFileName: String?
    var imageOpacity: Double

    init(
        primaryHex: UInt32? = nil,
        secondaryHex: UInt32? = nil,
        imageFileName: String? = nil,
        imageOpacity: Double = 1.0
    ) {
        self.primaryHex = primaryHex
        self.secondaryHex = secondaryHex
        self.imageFileName = imageFileName
        self.imageOpacity = imageOpacity
    }

    var isEmpty: Bool {
        primaryHex == nil && secondaryHex == nil && imageFileName == nil
    }

    /// Gradient stops. A single configured color renders as a solid fill.
    var gradientColors: [Color]? {
        let hexes = [primaryHex, secondaryHex].compactMap { $0 }
        guard !hexes.isEmpty else { return nil }
        let colors = hexes.map { Color(uiColor: AppearanceThemePreset.hex($0)) }
        return colors.count == 1 ? [colors[0], colors[0]] : colors
    }

    var imageURL: URL? {
        guard let imageFileName else { return nil }
        return try? AppearancePageBackgroundImageStore.shared.fileURL(fileName: imageFileName)
    }
}

// MARK: - Image storage

enum AppearancePageBackgroundImageError: Error {
    case unsupportedImageFile
    case cannotReadImage

    var messageKey: String {
        switch self {
        case .unsupportedImageFile:
            return "只支援 WebP、JPG、JPEG 或 PNG 圖片。"
        case .cannotReadImage:
            return "無法讀取圖片。"
        }
    }
}

/// Copies imported page-background images into Application Support/PageBackgrounds
/// and hands back stable file names persisted in `GlobalSettings`. Large photos
/// are downsampled on import so full-screen wallpapers never carry a 4K decode
/// cost while scrolling.
final class AppearancePageBackgroundImageStore: Sendable {
    static let shared = AppearancePageBackgroundImageStore()

    /// Longest-side cap for imported images; covers iPad fullscreen at 2×.
    private static let maxPixelSize: CGFloat = 2200

    private var fileManager: FileManager { .default }
    private let allowedExtensions: Set<String> = ["webp", "jpg", "jpeg", "png"]
    private let imageCache = ConcurrentCache<UIImage>(countLimit: 12)

    private init() {}

    /// Import from a file URL (Files app / export payloads).
    func importImage(fileURL: URL) throws -> String {
        let sourceExtension = fileURL.pathExtension.lowercased()
        guard allowedExtensions.contains(sourceExtension) else {
            throw AppearancePageBackgroundImageError.unsupportedImageFile
        }
        guard let data = try? Data(contentsOf: fileURL) else {
            throw AppearancePageBackgroundImageError.cannotReadImage
        }
        return try store(data: data, fallbackExtension: sourceExtension)
    }

    /// Import from raw data (Photos picker). There is no file name to key the
    /// container off, so the normalizer sniffs it and re-encodes anything this
    /// store can't name — a photo-library pick is very often HEIC.
    func importImage(data: Data) throws -> String {
        try store(data: data, fallbackExtension: "")
    }

    func fileURL(fileName: String) throws -> URL {
        try imagesDirectoryURL().appendingPathComponent(fileName)
    }

    func image(fileName: String) -> UIImage? {
        if let cached = imageCache.object(forKey: fileName) {
            return cached
        }
        guard let url = try? fileURL(fileName: fileName),
              let image = UIImage(contentsOfFile: url.path) else {
            return nil
        }
        imageCache.setObject(image, forKey: fileName)
        return image
    }

    func delete(fileName: String) {
        imageCache.removeObject(forKey: fileName)
        guard let url = try? fileURL(fileName: fileName) else { return }
        try? fileManager.removeItem(at: url)
    }

    func fileData(fileName: String) -> Data? {
        guard let url = try? fileURL(fileName: fileName) else { return nil }
        return try? Data(contentsOf: url)
    }

    // MARK: Internals

    /// Validates, downsamples oversized images, and writes to disk. Container
    /// handling is shared with the other image stores (see
    /// `ImportedImageNormalizer`); only the downsample step is specific here.
    private func store(data: Data, fallbackExtension: String) throws -> String {
        guard let image = UIImage(data: data), image.size.width > 0, image.size.height > 0 else {
            throw AppearancePageBackgroundImageError.cannotReadImage
        }

        let pixelWidth = image.size.width * image.scale
        let pixelHeight = image.size.height * image.scale
        let needsDownsample = max(pixelWidth, pixelHeight) > Self.maxPixelSize

        let output: ImportedImageNormalizer.Output?
        if needsDownsample {
            output = ImportedImageNormalizer.encode(
                resized: downsample(image, maxPixelSize: Self.maxPixelSize),
                preservingPNG: ImportedImageNormalizer.isPNG(data)
            )
        } else {
            output = ImportedImageNormalizer.normalize(
                image: image,
                data: data,
                fallbackExtension: fallbackExtension,
                allowedExtensions: allowedExtensions
            )
        }
        guard let output else {
            throw AppearancePageBackgroundImageError.cannotReadImage
        }

        let directory = try imagesDirectoryURL()
        try fileManager.createDirectory(at: directory, withIntermediateDirectories: true)
        let fileName = "pagebg-\(UUID().uuidString).\(output.fileExtension)"
        try output.data.write(to: directory.appendingPathComponent(fileName))
        return fileName
    }

    private func downsample(_ image: UIImage, maxPixelSize: CGFloat) -> UIImage {
        let pixelWidth = image.size.width * image.scale
        let pixelHeight = image.size.height * image.scale
        let ratio = maxPixelSize / max(pixelWidth, pixelHeight)
        guard ratio < 1 else { return image }
        let targetSize = CGSize(width: pixelWidth * ratio, height: pixelHeight * ratio)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: targetSize, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: targetSize))
        }
    }

    private func imagesDirectoryURL() throws -> URL {
        let base = try fileManager.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        return base.appendingPathComponent("PageBackgrounds", isDirectory: true)
    }
}

// MARK: - Theme export file

/// Single-file JSON theme package: the theme's five surface colors plus every
/// scope's page background with images embedded as base64, so a theme survives
/// AirDrop / iCloud Drive to another device intact.
struct AppearanceThemeExportFile: Codable {
    struct ImagePayload: Codable {
        var fileExtension: String
        var base64: String
    }

    struct PageBackgroundPayload: Codable {
        var lightPrimaryHex: UInt32?
        var lightSecondaryHex: UInt32?
        var darkPrimaryHex: UInt32?
        var darkSecondaryHex: UInt32?
        var lightImage: ImagePayload?
        var darkImage: ImagePayload?
        var lightImageOpacity: Double?
        var darkImageOpacity: Double?
    }

    static let formatIdentifier = "yuedu-appearance-theme"

    var format: String
    var version: Int
    var name: String
    var backgroundHex: UInt32
    var textHex: UInt32
    var barHex: UInt32
    var accentHex: UInt32
    var dialogueHex: UInt32
    var pageBackgrounds: [String: PageBackgroundPayload]?
    // Hand-authored dark palette, all-or-nothing. Absent (older files, and any
    // theme using the derived dark version) means the importer derives it.
    var darkBackgroundHex: UInt32?
    var darkTextHex: UInt32?
    var darkBarHex: UInt32?
    var darkAccentHex: UInt32?
    var darkDialogueHex: UInt32?
    /// UI text colours, three levels per appearance. Optional so every file
    /// written before they existed still decodes.
    var textPrimaryHex: UInt32?
    var textSecondaryHex: UInt32?
    var textTertiaryHex: UInt32?
    var darkTextPrimaryHex: UInt32?
    var darkTextSecondaryHex: UInt32?
    var darkTextTertiaryHex: UInt32?
    /// The theme's non-colour half. Card artwork travels as a file name; the
    /// bytes ride in `AppearanceCustomizationBundle`, same as every other image.
    var extras: AppearanceThemeExtras?

    /// The dark colors to store on import, or nil when the file doesn't carry a
    /// complete set.
    var darkColors: AppearanceCustomThemeDarkColors? {
        guard let darkBackgroundHex,
              let darkTextHex,
              let darkBarHex,
              let darkAccentHex,
              let darkDialogueHex else {
            return nil
        }
        return AppearanceCustomThemeDarkColors(
            backgroundHex: darkBackgroundHex,
            textHex: darkTextHex,
            barHex: darkBarHex,
            accentHex: darkAccentHex,
            dialogueHex: darkDialogueHex
        )
    }
}

extension AppearanceThemeExportFile {
    /// Builds the shareable file for one saved theme, reading the background
    /// images off disk and embedding them as base64.
    ///
    /// Pure on purpose — it touches only the theme value and the image store, no
    /// `GlobalSettings` — so `ShareLink` can defer this (megabytes, once images
    /// are involved) into its transfer closure instead of running it every time
    /// a menu row lays out.
    init(customTheme theme: AppearanceCustomTheme) {
        var payloads: [String: PageBackgroundPayload] = [:]
        for (key, config) in theme.extras?.pageBackgrounds ?? [:] {
            payloads[key] = PageBackgroundPayload(
                lightPrimaryHex: config.lightPrimaryHex,
                lightSecondaryHex: config.lightSecondaryHex,
                darkPrimaryHex: config.darkPrimaryHex,
                darkSecondaryHex: config.darkSecondaryHex,
                lightImage: Self.imagePayload(config.lightImageFileName),
                darkImage: Self.imagePayload(config.darkImageFileName),
                lightImageOpacity: config.lightImageOpacity,
                darkImageOpacity: config.darkImageOpacity
            )
        }
        // Only a hand-authored dark palette travels; a derived one is left out
        // so the importing install derives it with its own rules.
        let dark = theme.dark
        self.init(
            format: Self.formatIdentifier,
            version: 1,
            name: theme.name,
            backgroundHex: theme.backgroundHex,
            textHex: theme.textHex,
            barHex: theme.barHex,
            accentHex: theme.accentHex,
            dialogueHex: theme.dialogueHex,
            pageBackgrounds: payloads.isEmpty ? nil : payloads,
            darkBackgroundHex: dark?.backgroundHex,
            darkTextHex: dark?.textHex,
            darkBarHex: dark?.barHex,
            darkAccentHex: dark?.accentHex,
            darkDialogueHex: dark?.dialogueHex,
            textPrimaryHex: theme.textPrimaryHex,
            textSecondaryHex: theme.textSecondaryHex,
            textTertiaryHex: theme.textTertiaryHex,
            darkTextPrimaryHex: theme.darkTextPrimaryHex,
            darkTextSecondaryHex: theme.darkTextSecondaryHex,
            darkTextTertiaryHex: theme.darkTextTertiaryHex,
            // Page backgrounds travel in `pageBackgrounds` above, with their bytes.
            // The copy in `extras` is a list of file names on *this* device's disk, so
            // shipping it would hand the importer references that resolve to nothing.
            extras: Self.exportedExtras(theme.extras)
        )
    }

    private static func exportedExtras(_ extras: AppearanceThemeExtras?) -> AppearanceThemeExtras? {
        guard var extras, extras.pageBackgrounds != nil || extras.reading != nil else { return extras }
        extras.pageBackgrounds = nil
        // The reading setup names this device's background file, custom bubble entry
        // and chapter-title artwork — none of which exist on the importing device — so
        // it stays behind rather than arriving as references to nothing.
        extras.reading = nil
        return extras.isEmpty ? nil : extras
    }

    private static func imagePayload(_ fileName: String?) -> ImagePayload? {
        guard let fileName, !fileName.isEmpty,
              let data = AppearancePageBackgroundImageStore.shared.fileData(fileName: fileName) else {
            return nil
        }
        return ImagePayload(
            fileExtension: (fileName as NSString).pathExtension,
            base64: data.base64EncodedString()
        )
    }
}

/// Several themes in one file — what a shared theme pack arrives as. Kept as
/// its own envelope (rather than always exporting an array) so a single-theme
/// file stays readable on its own and older builds keep opening the files they
/// already know. The app's own "export everything" writes the richer
/// `AppearanceCustomizationBundle`, which this importer also accepts.
struct AppearanceThemeCollectionFile: Codable {
    static let formatIdentifier = "yuedu-appearance-theme-collection"

    var format: String
    var version: Int
    var themes: [AppearanceThemeExportFile]

    init(themes: [AppearanceThemeExportFile]) {
        self.format = Self.formatIdentifier
        self.version = 1
        self.themes = themes
    }
}

/// Decodes any shape the app exports or a user might hand it: one theme, a
/// collection envelope, or a bare array of themes. One entry point so the
/// importer can't grow a second, differently-behaved parse route.
enum AppearanceThemeFileDecoder {
    static func themes(in data: Data) -> [AppearanceThemeExportFile] {
        let decoder = JSONDecoder()
        if let single = try? decoder.decode(AppearanceThemeExportFile.self, from: data),
           single.format == AppearanceThemeExportFile.formatIdentifier {
            return [single]
        }
        if let collection = try? decoder.decode(AppearanceThemeCollectionFile.self, from: data),
           collection.format == AppearanceThemeCollectionFile.formatIdentifier {
            return collection.themes.filter { $0.format == AppearanceThemeExportFile.formatIdentifier }
        }
        if let array = try? decoder.decode([AppearanceThemeExportFile].self, from: data) {
            return array.filter { $0.format == AppearanceThemeExportFile.formatIdentifier }
        }
        return []
    }
}

enum AppearanceThemeImportError: Error {
    case invalidFile

    var messageKey: String {
        switch self {
        case .invalidFile:
            return "不支援的主題檔案。"
        }
    }
}

// MARK: - Background layer view

/// The layer painted behind a page: configured gradient with the optional
/// background image on top. Renders nothing when the slice is empty.
struct AppearancePageBackgroundLayerView: View {
    /// Optional so callers can keep this decorative layer installed while the
    /// configuration is loading or becomes unavailable. That keeps the parent
    /// view's structure stable when entitlements/theme state changes.
    let slice: AppearancePageBackgroundSlice?

    var body: some View {
        ZStack {
            if let slice {
                if let colors = slice.gradientColors {
                    LinearGradient(
                        colors: colors,
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                }
                if let fileName = slice.imageFileName,
                   let image = AppearancePageBackgroundImageStore.shared.image(fileName: fileName) {
                    GeometryReader { proxy in
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFill()
                            .frame(width: proxy.size.width, height: proxy.size.height)
                            .clipped()
                            .opacity(slice.imageOpacity)
                    }
                }
            }
        }
        .accessibilityHidden(true)
        // This view is always decorative and is frequently installed as a
        // full-screen background. Keep its image/GeometryReader subtree out of
        // hit testing so unusually tall images cannot intercept foreground
        // controls such as sliders and menus.
        .allowsHitTesting(false)
    }
}

#Preview("Gradient slice") {
    AppearancePageBackgroundLayerView(
        slice: AppearancePageBackgroundSlice(
            primaryHex: 0xEAF2FC,
            secondaryHex: 0xD5E8D8,
            imageFileName: nil
        )
    )
    .ignoresSafeArea()
}
