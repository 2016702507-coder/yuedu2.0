import Foundation
import UIKit
import YueduCoreTextTypography

struct HTMLCSSApplyContext {
    let parentStyle: HTMLAttributedStringBuilder.ResolvedStyle
    let rootFontSize: CGFloat
    let resolveLength: (_ raw: String, _ currentFontSize: CGFloat, _ rootFontSize: CGFloat, _ relativeBase: CGFloat) -> CGFloat?
    let parseColor: (String) -> UIColor?
    let cssFontWeight: (_ value: String, _ current: Int) -> Int
    let cssAlignment: (String) -> NSTextAlignment
    let cssDisplayIsBlock: (String) -> Bool
    let resolveLineHeight: (_ raw: String, _ fontSize: CGFloat, _ rootFontSize: CGFloat) -> CGFloat?
    let extractURL: (String) -> String?
    let parseEmbeddedColor: (String) -> UIColor?
}

protocol HTMLCSSPropertyApplier: Sendable {
    var key: String { get }
    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    )
}

final class HTMLCSSPropertyApplierRegistry: Sendable {
    private let appliers: [String: any HTMLCSSPropertyApplier]

    init(appliers: [any HTMLCSSPropertyApplier]) {
        self.appliers = Dictionary(uniqueKeysWithValues: appliers.map { ($0.key, $0) })
    }

    func apply(
        declarations: [String: String],
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) -> Set<String> {
        var handled = Set<String>()
        for (key, value) in declarations {
            guard let applier = appliers[key] else { continue }
            applier.apply(value: value, style: &style, context: context)
            handled.insert(key)
        }
        return handled
    }

    static let defaultRegistry = HTMLCSSPropertyApplierRegistry(appliers: [
        FontSizeApplier(),
        FontFamilyApplier(),
        FontWeightApplier(),
        FontStyleApplier(),
        TextAlignApplier(),
        DisplayApplier(),
        FloatApplier(),
        ColorApplier(),
        LineHeightApplier(),
        BackgroundImageApplier(),
        BackgroundColorApplier(),
        LetterSpacingApplier(),
        DirectionApplier(),
        WritingModeApplier(),
        WebkitWritingModeApplier(),
        EPUBWritingModeApplier(),
        TextCombineUprightApplier(key: "text-combine-upright", legacy: false),
        TextCombineUprightApplier(key: "-epub-text-combine-horizontal", legacy: false),
        TextCombineUprightApplier(key: "-ms-text-combine-horizontal", legacy: false),
        TextCombineUprightApplier(key: "-webkit-text-combine", legacy: true),
        TextCombineUprightApplier(key: "-epub-text-combine", legacy: true),
    ])
}

enum HTMLWritingDirectionResolver {
    private static let rtlLanguageCodes: Set<String> = [
        "ar", "arc", "ckb", "dv", "fa", "ha", "he", "iw", "khw", "ks", "ku",
        "nqo", "prs", "ps", "sd", "syr", "ug", "ur", "yi"
    ]

    static func defaultDirection(forLanguage language: String?) -> NSWritingDirection {
        guard let language else { return .natural }
        let primaryCode = language
            .split { $0 == "-" || $0 == "_" }
            .first
            .map { String($0).lowercased() }
        guard let primaryCode else { return .natural }
        return rtlLanguageCodes.contains(primaryCode) ? .rightToLeft : .natural
    }

    static func resolve(
        _ raw: String,
        autoText: String? = nil,
        inherited: NSWritingDirection = .natural
    ) -> NSWritingDirection? {
        switch raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
        case "rtl":
            return .rightToLeft
        case "ltr":
            return .leftToRight
        case "auto":
            return autoText.flatMap(firstStrongDirection(in:)) ?? (inherited == .natural ? nil : inherited)
        case "inherit":
            return inherited
        case "initial", "unset":
            return .natural
        default:
            return nil
        }
    }

    private static func firstStrongDirection(in text: String) -> NSWritingDirection? {
        for scalar in text.unicodeScalars {
            if isStrongRTL(scalar) {
                return .rightToLeft
            }
            if isStrongLTR(scalar) {
                return .leftToRight
            }
        }
        return nil
    }

    private static func isStrongRTL(_ scalar: Unicode.Scalar) -> Bool {
        switch scalar.value {
        case 0x0590...0x08FF, 0xFB1D...0xFDFF, 0xFE70...0xFEFF,
             0x10800...0x10FFF, 0x1E800...0x1EDFF, 0x1EE00...0x1EEFF:
            return true
        default:
            return false
        }
    }

    private static func isStrongLTR(_ scalar: Unicode.Scalar) -> Bool {
        switch scalar.value {
        case 0x0041...0x005A, 0x0061...0x007A, 0x00C0...0x02AF,
             0x0370...0x052F, 0x1E00...0x1EFF:
            return true
        default:
            return false
        }
    }
}

private struct FontSizeApplier: HTMLCSSPropertyApplier {
    let key = "font-size"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        style.fontSize = context.resolveLength(
            value,
            context.parentStyle.fontSize,
            context.rootFontSize,
            context.parentStyle.fontSize
        ) ?? style.fontSize
    }
}

private struct FontFamilyApplier: HTMLCSSPropertyApplier {
    let key = "font-family"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        style.fontFamilies = value
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines.union(CharacterSet(charactersIn: "\"'"))) }
    }
}

private struct FontWeightApplier: HTMLCSSPropertyApplier {
    let key = "font-weight"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        style.fontWeight = context.cssFontWeight(value, style.fontWeight)
    }
}

private struct FontStyleApplier: HTMLCSSPropertyApplier {
    let key = "font-style"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        style.isItalic = value.lowercased().contains("italic")
    }
}

private struct TextAlignApplier: HTMLCSSPropertyApplier {
    let key = "text-align"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        style.textAlign = context.cssAlignment(value)
    }
}

private struct DisplayApplier: HTMLCSSPropertyApplier {
    let key = "display"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        // `display: none` removes the element (and its subtree) from rendering. Track it on the
        // style so the node builder can skip it; a later cascade rule (e.g. `display: block`)
        // correctly un-hides because each declaration re-evaluates this.
        style.isHidden = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "none"
        style.isBlock = context.cssDisplayIsBlock(value)
    }
}

private struct FloatApplier: HTMLCSSPropertyApplier {
    let key = "float"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        // Record the float side. The builder emits a zero-width float marker for the element and the
        // paginator carves a notch out of the page so the surrounding text wraps beside it (magazine
        // style). `float` is not inherited, so children reset to nil below.
        switch value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
        case "left":
            style.floatSide = .left
        case "right":
            style.floatSide = .right
        case "none":
            style.floatSide = nil
        default:
            break
        }
    }
}

private struct ColorApplier: HTMLCSSPropertyApplier {
    let key = "color"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        if let color = context.parseColor(value) {
            style.textColor = color
            style.hasCSSColor = true
        }
    }
}

private struct LineHeightApplier: HTMLCSSPropertyApplier {
    let key = "line-height"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        guard let resolved = context.resolveLineHeight(value, style.fontSize, context.rootFontSize) else { return }
        style.lineHeight = resolved
        style.lineHeightExplicit = true
    }
}

private struct BackgroundImageApplier: HTMLCSSPropertyApplier {
    let key = "background-image"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        style.backgroundImage = context.extractURL(value)
    }
}

private struct BackgroundColorApplier: HTMLCSSPropertyApplier {
    let key = "background-color"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        if let color = context.parseColor(value) {
            style.backgroundFillColor = color
        }
    }
}

private struct LetterSpacingApplier: HTMLCSSPropertyApplier {
    let key = "letter-spacing"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if trimmed == "normal" {
            style.letterSpacing = nil
            return
        }
        if let resolved = context.resolveLength(trimmed, style.fontSize, context.rootFontSize, style.fontSize) {
            style.letterSpacing = resolved
        }
    }
}

private struct DirectionApplier: HTMLCSSPropertyApplier {
    let key = "direction"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        if let direction = HTMLWritingDirectionResolver.resolve(
            value,
            inherited: context.parentStyle.baseWritingDirection
        ) {
            style.baseWritingDirection = direction
        }
    }
}

/// `text-combine-upright` and its prefixed forms, parsed by the rules BrowserAuto uses.
/// The older `-webkit-text-combine` / `-epub-text-combine` take `horizontal` for `all`.
private struct TextCombineUprightApplier: HTMLCSSPropertyApplier {
    let key: String
    let legacy: Bool

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        let v = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        switch v {
        case "inherit", "unset": style.textCombineUpright = context.parentStyle.textCombineUpright
        case "initial": style.textCombineUpright = .none
        default:
            let parsed = legacy ? TextCombineUpright.parseLegacy(v) : TextCombineUpright.parse(v)
            // An unknown value is invalid CSS: the declaration is dropped.
            if parsed.isSupported { style.textCombineUpright = parsed }
        }
    }
}

private struct WritingModeApplier: HTMLCSSPropertyApplier {
    let key = "writing-mode"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        let v = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if v.contains("vertical-rl") || v.contains("vertical-lr") {
            style.isVerticalWritingMode = true
        }
    }
}

private struct WebkitWritingModeApplier: HTMLCSSPropertyApplier {
    let key = "-webkit-writing-mode"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        let v = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if v.contains("vertical-rl") || v.contains("vertical-lr") {
            style.isVerticalWritingMode = true
        }
    }
}

private struct EPUBWritingModeApplier: HTMLCSSPropertyApplier {
    let key = "-epub-writing-mode"

    func apply(
        value: String,
        style: inout HTMLAttributedStringBuilder.ResolvedStyle,
        context: HTMLCSSApplyContext
    ) {
        let v = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if v.contains("vertical-rl") || v.contains("vertical-lr") {
            style.isVerticalWritingMode = true
        }
    }
}
