import YueduCoreText
import CoreText
import UIKit
import YueduCoreTextTypography

/// Extracts image attachment rects (UIKit coordinates: origin top-left, y downward) from a chunk's CTFrame.
/// chunkSize is the chunk's path size (width × height); the coordinate system matches the cell's drawView bounds.
/// Mirrors CoreTextPaginator.extractImages but operates on a single chunk frame.
enum CoreTextChunkAttachmentExtractor {

    static func extract(
        frame: CTFrame,
        chunkSize: CGSize,
        attributedString: NSAttributedString,
        rangeInChapter: CFRange,
        writingMode: ReaderWritingMode = .horizontal
    ) -> [CoreTextPaginator.RenderedAttachment] {
        let lines = CTFrameGetLines(frame) as! [CTLine]
        var origins = [CGPoint](repeating: .zero, count: lines.count)
        CTFrameGetLineOrigins(frame, CFRangeMake(0, lines.count), &origins)
        let delegateKey = NSAttributedString.Key(kCTRunDelegateAttributeName as String)
        let isVertical = writingMode.isVertical

        var result: [CoreTextPaginator.RenderedAttachment] = []

        for (lineIdx, line) in lines.enumerated() {
            let lineOrigin = origins[lineIdx]
            let runs = CTLineGetGlyphRuns(line) as! [CTRun]
            for run in runs {
                let attrs = CTRunGetAttributes(run) as! [NSAttributedString.Key: Any]
                guard let delegate = attrs[delegateKey] else { continue }
                guard attrs[HTMLAttributedStringBuilder.spacerRunAttribute] == nil else { continue }
                let ctDelegate = delegate as! CTRunDelegate
                let ptr = CTRunDelegateGetRefCon(ctDelegate)
                let info = Unmanaged<ImageRunInfo>.fromOpaque(ptr).takeUnretainedValue()
                guard let img = info.image else { continue }

                let runLocation = CTRunGetStringRange(run).location
                let paragraphStyle = attributedString.attribute(
                    .paragraphStyle,
                    at: max(0, min(attributedString.length - 1, runLocation)),
                    effectiveRange: nil
                ) as? NSParagraphStyle

                var lineAscent: CGFloat = 0
                var lineDescent: CGFloat = 0
                _ = CTLineGetTypographicBounds(line, &lineAscent, &lineDescent, nil)

                let rect: CGRect
                switch info.displayMode {
                case .inline:
                    if isVertical {
                        let textAdvance = GlyphBoundary.offset(line, at: runLocation)
                        let lineTypographicCenterX = lineOrigin.x + (lineAscent - lineDescent) / 2
                        let uiY = chunkSize.height - lineOrigin.y + textAdvance
                        rect = CGRect(
                            x: lineTypographicCenterX - (info.drawWidth / 2),
                            y: uiY,
                            width: info.drawWidth,
                            height: info.drawHeight
                        )
                    } else {
                        let baselineY = lineOrigin.y
                        let lineHeight = lineAscent + lineDescent
                        let lineBottom = baselineY - lineDescent
                        let centeredBottom = lineBottom + max(0, (lineHeight - info.drawHeight) / 2)
                        let uiY: CGFloat
                        if info.source == "mathml:" {
                            uiY = chunkSize.height - (baselineY - info.descent) - info.drawHeight
                        } else if info.isTextSized {
                            let bottom = CoreTextPaginator.textSizedImageBottom(
                                of: run, in: line, baselineY: baselineY, drawHeight: info.drawHeight
                            )
                            uiY = chunkSize.height - bottom - info.drawHeight
                        } else {
                            uiY = chunkSize.height - centeredBottom - info.drawHeight
                        }
                        // A standalone image (alone on its line, e.g. <figure><img/><figcaption/></figure>)
                        // reads as a figure and is centered like a block image; flushing it left leaves a
                        // lopsided right-hand gap. Inline images that flow with text keep their flow
                        // position. Matches CoreTextPaginator.extractImages (paged mode).
                        if CoreTextPaginator.isStandaloneImageRun(CTRunGetStringRange(run), line: line, attrStr: attributedString), !info.isTextSized {
                            let leftInset = min(paragraphStyle?.headIndent ?? 0, paragraphStyle?.firstLineHeadIndent ?? 0)
                            let rightInset = (paragraphStyle?.tailIndent ?? 0) < 0 ? -(paragraphStyle?.tailIndent ?? 0) : 0
                            let boxWidth = max(1, chunkSize.width - leftInset - rightInset)
                            let occupiedWidth = min(boxWidth, info.width)
                            let alignedX: CGFloat
                            switch paragraphStyle?.alignment ?? .natural {
                            case .left:  alignedX = leftInset
                            case .right: alignedX = leftInset + max(0, boxWidth - occupiedWidth)
                            default:     alignedX = leftInset + max(0, (boxWidth - occupiedWidth) / 2)
                            }
                            rect = CGRect(
                                x: alignedX + info.paddingLeft,
                                y: uiY,
                                width: info.drawWidth,
                                height: info.drawHeight
                            )
                        } else {
                            // `lineOrigin.x` already carries the paragraph's flush (see
                            // CoreTextPaginator.extractImages); adding a pen offset on top of it
                            // double-counted the alignment and misplaced inline images on centered
                            // or right-aligned lines — the chapter title's 章名段评 bubble.
                            // Measured on the line as painted (see CoreTextPaginator.extractImages).
                            let painted = CoreTextHorizontalLineDrawer.paintedLine(
                                line, originX: lineOrigin.x, contentWidth: chunkSize.width, attrStr: attributedString
                            )
                            rect = CGRect(
                                x: painted.offset(at: runLocation) + info.paddingLeft,
                                y: uiY,
                                width: info.drawWidth,
                                height: info.drawHeight
                            )
                        }
                    }
                case .block:
                    if isVertical {
                        let textAdvance = GlyphBoundary.offset(line, at: runLocation)
                        let lineTypographicCenterX = lineOrigin.x + (lineAscent - lineDescent) / 2
                        let uiY = chunkSize.height - lineOrigin.y + textAdvance
                        rect = CGRect(
                            x: lineTypographicCenterX - (info.drawWidth / 2),
                            y: uiY,
                            width: info.drawWidth,
                            height: info.drawHeight
                        )
                    } else {
                        let leftInset = min(paragraphStyle?.headIndent ?? 0, paragraphStyle?.firstLineHeadIndent ?? 0)
                        let rightInset = (paragraphStyle?.tailIndent ?? 0) < 0 ? -(paragraphStyle?.tailIndent ?? 0) : 0
                        let boxWidth = max(1, chunkSize.width - leftInset - rightInset)
                        let occupiedWidth = min(boxWidth, info.width)
                        let alignedX: CGFloat
                        switch paragraphStyle?.alignment ?? .left {
                        case .center: alignedX = leftInset + max(0, (boxWidth - occupiedWidth) / 2)
                        case .right:  alignedX = leftInset + max(0, boxWidth - occupiedWidth)
                        default:      alignedX = leftInset
                        }
                        let baselineY = lineOrigin.y
                        let lineHeight = lineAscent + lineDescent
                        let lineBottom = baselineY - lineDescent
                        let centeredBottom = lineBottom + max(0, (lineHeight - info.drawHeight) / 2)
                        let uiY = chunkSize.height - centeredBottom - info.drawHeight
                        rect = CGRect(
                            x: alignedX + info.paddingLeft,
                            y: uiY,
                            width: info.drawWidth,
                            height: info.drawHeight
                        )
                    }
                }

                let linkHref = (attrs[HTMLAttributedStringBuilder.internalLinkAttribute] as? String).flatMap { $0.isEmpty ? nil : $0 }
                let mediaAttachment = attrs[HTMLAttributedStringBuilder.mediaAttachmentAttribute] as? EPUBMediaAttachment

                result.append(CoreTextPaginator.RenderedAttachment(
                    rect: rect,
                    image: img,
                    opacity: info.opacity,
                    sourceHref: info.source.isEmpty ? nil : info.source,
                    alt: info.alt,
                    linkHref: linkHref,
                    mediaAttachment: mediaAttachment,
                    webEmbed: attrs[HTMLAttributedStringBuilder.webEmbedAttribute] as? ReaderWebEmbed,
                    originalSize: img.size,
                    linkRegions: info.linkRegions,
                    allowsPreview: info.allowsPreview
                ))
            }
        }

        return result
    }
}
