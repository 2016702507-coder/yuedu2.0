import YueduCoreText
import CoreText
import Foundation
import YueduCoreTextTypography

// MARK: - Annotation Renderer

/// Computes highlight/underline rects from annotations and CTFrame layout.
/// Stateless: takes annotations + layout → produces rects grouped by style/color.
/// Both scroll mode and page mode use this single renderer.
struct CoreTextAnnotationRenderer {

    struct Layer {
        let rects: [CGRect]
        let style: AnnotationStyle
        let color: AnnotationColor
    }

    /// Computes annotation rects for a given page/chunk character range.
    /// - Parameters:
    ///   - annotations: All text annotations for the current book
    ///   - spineIndex: Current chapter spine index
    ///   - pageCharRange: Character range of this page/chunk (NSRange)
    ///   - lines: CTFrame lines for this page/chunk
    ///   - lineOrigins: CTFrame line origins for this page/chunk
    ///   - painted: The same lines as the drawer paints them; horizontal rects measure these
    ///   - contentOffset: Content area origin in the CoreText coordinate system (contentPathRect.minX, contentPathRect.minY)
    ///   - layoutHeight: Total layout height, used to flip from CoreText to UIKit coordinates
    ///   - writingMode: Horizontal or vertical
    /// - Returns: Layers grouped by (style, color), ready for drawing in UIKit coordinates (no scale applied)
    static func render(
        annotations: [CoreTextTextAnnotation],
        spineIndex: Int,
        pageCharRange: NSRange,
        lines: [CTLine],
        lineOrigins: [CGPoint],
        painted: CoreTextHorizontalLineDrawer.PaintedLines,
        contentOffset: CGPoint = .zero,
        layoutHeight: CGFloat,
        writingMode: ReaderWritingMode
    ) -> [Layer] {
        guard !annotations.isEmpty, !lines.isEmpty, pageCharRange.length > 0 else { return [] }

        // Group annotations by (style, color) so rects are layered correctly
        var layers: [LayerKey: [CGRect]] = [:]
        let relevantAnnotations = annotations.filter { $0.spineIndex == spineIndex }

        for annotation in relevantAnnotations {
            let intersection = NSIntersectionRange(pageCharRange, annotation.range)
            guard intersection.length > 0 else { continue }

            let key = LayerKey(style: annotation.style, color: annotation.color)
            let rects: [CGRect]

            if writingMode.isVertical {
                rects = verticalRects(
                    range: intersection,
                    lines: lines,
                    lineOrigins: lineOrigins,
                    contentOffset: contentOffset,
                    layoutHeight: layoutHeight
                )
            } else {
                rects = horizontalRects(
                    range: intersection,
                    lines: lines,
                    lineOrigins: lineOrigins,
                    painted: painted,
                    contentOffset: contentOffset,
                    layoutHeight: layoutHeight
                )
            }

            if !rects.isEmpty {
                layers[key, default: []].append(contentsOf: rects)
            }
        }

        return layers.map { key, rects in
            Layer(rects: rects, style: key.style, color: key.color)
        }
    }

    // MARK: - Note markers

    /// 一個「有筆記」標註在本頁／本 chunk 上的圓圈標記。
    struct NoteMarker: Equatable {
        let annotationID: UUID
        /// 圓圈本體的 rect（已在 CoreText → UIKit 翻轉後的版面座標，未套用縮放）。
        let badgeRect: CGRect
    }

    /// 計算本頁／本 chunk 要畫的筆記圓圈。
    ///
    /// 只有「標註起點落在這一段字元範圍內」才畫，跨頁的標註因此不會在每一頁都冒一個圓圈。
    static func noteMarkers(
        annotations: [CoreTextTextAnnotation],
        spineIndex: Int,
        pageCharRange: NSRange,
        lines: [CTLine],
        lineOrigins: [CGPoint],
        painted: CoreTextHorizontalLineDrawer.PaintedLines,
        contentOffset: CGPoint = .zero,
        layoutHeight: CGFloat,
        writingMode: ReaderWritingMode
    ) -> [NoteMarker] {
        guard !annotations.isEmpty, !lines.isEmpty, pageCharRange.length > 0 else { return [] }

        let pageStart = pageCharRange.location
        let pageEnd = pageCharRange.location + pageCharRange.length

        return annotations.compactMap { annotation -> NoteMarker? in
            guard annotation.spineIndex == spineIndex,
                  let note = annotation.note,
                  !note.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  annotation.startOffset >= pageStart,
                  annotation.startOffset < pageEnd
            else { return nil }

            // 只取標註的第一個字，拿到它所在行的 rect 當錨點。
            let headRange = NSRange(location: annotation.startOffset, length: 1)
            let rects = self.rects(
                forRange: headRange,
                lines: lines,
                lineOrigins: lineOrigins,
                painted: painted,
                contentOffset: contentOffset,
                layoutHeight: layoutHeight,
                writingMode: writingMode
            )
            guard let anchor = rects.first else { return nil }

            return NoteMarker(
                annotationID: annotation.id,
                badgeRect: NoteMarkerGeometry.badgeRect(
                    anchoredTo: anchor,
                    isVertical: writingMode.isVertical
                )
            )
        }
    }

    // MARK: - Raw rects (for selection / playback — no style/color grouping)

    /// Computes rects for a single character range. Used by selection highlighting and TTS playback.
    static func rects(
        forRange range: NSRange,
        lines: [CTLine],
        lineOrigins: [CGPoint],
        painted: CoreTextHorizontalLineDrawer.PaintedLines,
        contentOffset: CGPoint = .zero,
        layoutHeight: CGFloat,
        writingMode: ReaderWritingMode
    ) -> [CGRect] {
        guard !lines.isEmpty, range.length > 0 else { return [] }
        if writingMode.isVertical {
            return verticalRects(range: range, lines: lines, lineOrigins: lineOrigins, contentOffset: contentOffset, layoutHeight: layoutHeight)
        }
        return horizontalRects(range: range, lines: lines, lineOrigins: lineOrigins, painted: painted,
                               contentOffset: contentOffset, layoutHeight: layoutHeight)
    }

    // MARK: - Horizontal rects

    /// Measured on the lines as painted (`CoreTextHorizontalLineDrawer.PaintedLine`), so a rect
    /// covers the glyphs where they are drawn; heights come from the frame's lines.
    private static func horizontalRects(
        range: NSRange,
        lines: [CTLine],
        lineOrigins: [CGPoint],
        painted: CoreTextHorizontalLineDrawer.PaintedLines,
        contentOffset: CGPoint,
        layoutHeight: CGFloat
    ) -> [CGRect] {
        var rects: [CGRect] = []
        for idx in lines.indices {
            let line = lines[idx]
            let lineRange = CTLineGetStringRange(line)
            guard lineRange.length > 0 else { continue }
            let lineNS = NSRange(location: lineRange.location, length: lineRange.length)
            let inter = NSIntersectionRange(lineNS, range)
            guard inter.length > 0 else { continue }

            let startOffset = painted[idx].offset(at: inter.location)
            let endOffset = painted[idx].offset(at: inter.location + inter.length)

            var ascent: CGFloat = 0, descent: CGFloat = 0
            _ = CTLineGetTypographicBounds(line, &ascent, &descent, nil)

            let origin = lineOrigins[idx]
            let baselineY = contentOffset.y + origin.y
            let lineTop = baselineY + ascent
            let lineHeight = max(1, ascent + descent)

            let uiY = layoutHeight - lineTop
            rects.append(CGRect(
                x: contentOffset.x + min(startOffset, endOffset),
                y: uiY,
                width: max(1, abs(endOffset - startOffset)),
                height: lineHeight
            ))
        }
        return rects
    }

    // MARK: - Vertical rects

    private static func verticalRects(
        range: NSRange,
        lines: [CTLine],
        lineOrigins: [CGPoint],
        contentOffset: CGPoint,
        layoutHeight: CGFloat
    ) -> [CGRect] {
        var rects: [CGRect] = []
        for idx in lines.indices {
            let line = lines[idx]
            let lineRange = CTLineGetStringRange(line)
            guard lineRange.length > 0 else { continue }
            let lineNS = NSRange(location: lineRange.location, length: lineRange.length)
            let inter = NSIntersectionRange(lineNS, range)
            guard inter.length > 0 else { continue }

            let startOffset = CGFloat(GlyphBoundary.offset(line, at: inter.location))
            let endOffset = CGFloat(GlyphBoundary.offset(line, at: inter.location + inter.length))

            var ascent: CGFloat = 0, descent: CGFloat = 0
            _ = CTLineGetTypographicBounds(line, &ascent, &descent, nil)

            let origin = lineOrigins[idx]
            let baselineX = contentOffset.x + origin.x
            let x1 = baselineX - descent
            let x2 = baselineX + ascent
            let lineTopY = layoutHeight - (contentOffset.y + origin.y)

            let vrect = CGRect(
                x: min(x1, x2),
                y: lineTopY + min(startOffset, endOffset),
                width: max(1, abs(x2 - x1)),
                height: max(1, abs(endOffset - startOffset))
            )
            #if DEBUG
            // [Bug3 直排標註幾何診斷] 對段落頂端選一小段直排文字後查看這些數值。
            AppLogger.render("[VRECT] line=\(idx) range=\(inter.location)..<\(inter.location + inter.length) origin=(\(origin.x),\(origin.y)) ascent=\(ascent) descent=\(descent) layoutH=\(layoutHeight) lineTopY=\(lineTopY) startOff=\(startOffset) endOff=\(endOffset) rect=\(vrect)")
            #endif
            rects.append(vrect)
        }
        return rects
    }
}
