import YueduCoreText
import CoreText
import UIKit

enum UserReaderFontResolver {
    /// Reader policy applied before EPUB measurement, not an author CSS mutation.
    /// Nil/unavailable selections leave the publication resolver in control.
    static func epubOverride(postScriptName: String?, size: CGFloat, weight: Int, italic: Bool) -> UIFont? {
        guard let postScriptName, let base = UIFont(name: postScriptName, size: size) else { return nil }
        var font = weight >= 600 ? boldVersion(of: base, size: size) : base
        if italic && !font.fontDescriptor.symbolicTraits.contains(.traitItalic) {
            var traits = font.fontDescriptor.symbolicTraits
            traits.insert(.traitItalic)
            if let descriptor = font.fontDescriptor.withSymbolicTraits(traits) {
                font = preservingFamily(font, resolved: UIFont(descriptor: descriptor, size: size))
            }
            if !font.fontDescriptor.symbolicTraits.contains(.traitItalic) {
                font = HTMLAttributedStringBuilder.synthesizedObliqueFont(from: font)
            }
        }
        return font
    }

    /// A negative stroke width fills the glyph and expands its outline. CoreText
    /// interprets the value as a percentage of the point size, so this scales
    /// with the reader font without changing line metrics.
    private static let syntheticBoldStrokeWidth = -2.5 as NSNumber

    /// Read from `GlobalSettings.snapshot`, so chapter building can call it off main. A view
    /// that must redraw when the font changes reads `GlobalSettings.selectedReaderFontPostScript`
    /// through `postScriptName(_:)` instead.
    static var selectedPostScriptName: String? {
        postScriptName(GlobalSettings.snapshot.selectedReaderFontPostScript)
    }

    /// The stored selection as a font name: an empty one means the system font.
    static func postScriptName(_ selection: String?) -> String? {
        guard let selection, !selection.isEmpty else { return nil }
        return selection
    }

    static func bodyFont(size: CGFloat, isBold: Bool = false) -> UIFont {
        let baseFont = selectedFont(size: size) ?? UIFont.systemFont(ofSize: size)
        if bodyBoldRequested(isBold: isBold) {
            return boldVersion(of: baseFont, size: size)
        }
        return baseFont
    }

    static func bodyBoldRequested(isBold: Bool) -> Bool {
        // The render snapshot is authoritative. ReaderConfig persists to global
        // settings later, so OR-ing that older value makes bold impossible to turn off.
        isBold
    }

    /// Returns the only extra attributed-string attributes required to render a
    /// requested bold face. The stroke is deliberately limited to fonts that
    /// have neither a native bold trait nor a variable-weight axis; regular-only
    /// custom fonts otherwise keep returning their unchanged Regular face from
    /// `UIFontDescriptor`, which is why the old "synthetic" bold was invisible.
    /// This compatibility path can be removed once CoreText exposes a real
    /// emboldening transform for static fonts.
    static func syntheticBoldAttributes(for font: UIFont, isBoldRequested: Bool) -> [NSAttributedString.Key: Any] { FontTraits.syntheticBoldAttributes(for: font, isBoldRequested: isBoldRequested) }

    /// Font for the in-content chapter title.
    /// - Parameters:
    ///   - weight: explicit title weight (no longer always bold).
    ///   - postScriptName: per-segment font override; `nil` follows the reader
    ///     font (or system font when none is selected).
    static func titleFont(size: CGFloat, weight: ChapterTitleWeight, postScriptName: String?) -> UIFont {
        let resolvedName = postScriptName ?? selectedPostScriptName
        let baseFont: UIFont
        if let resolvedName, let named = UIFont(name: resolvedName, size: size) {
            baseFont = named
        } else {
            baseFont = UIFont.systemFont(ofSize: size, weight: weight.uiFontWeight)
        }
        return weightedFont(baseFont, size: size, weight: weight.uiFontWeight)
    }

    private static func selectedFont(size: CGFloat) -> UIFont? {
        guard let postScriptName = selectedPostScriptName else { return nil }
        return UIFont(name: postScriptName, size: size)
    }

    /// Coerce `font` to `weight`. Uses the weight trait so system and most named
    /// fonts pick their matching face; for bold-ish weights also requests the
    /// bold symbolic trait so families that only expose bold via `traitBold`
    /// (not a weight axis) still resolve, and synthesises otherwise.
    private static func weightedFont(_ font: UIFont, size: CGFloat, weight: UIFont.Weight) -> UIFont {
        var descriptor = font.fontDescriptor.addingAttributes([
            .traits: [UIFontDescriptor.TraitKey.weight: weight]
        ])
        if weight.rawValue >= UIFont.Weight.semibold.rawValue,
           let boldDescriptor = descriptor.withSymbolicTraits(.traitBold) {
            descriptor = boldDescriptor
        }
        return preservingFamily(font, resolved: UIFont(descriptor: descriptor, size: size))
    }

    static func boldVersion(of font: UIFont, size: CGFloat) -> UIFont { FontTraits.boldVersion(of: font, size: size) }

    /// Descriptor matching is allowed to leave the requested family: asking a
    /// Regular-only imported font for a Bold/weighted face returns a *system*
    /// face instead. That silently discarded the user's chosen font — the title
    /// simply kept looking like the system font no matter what was picked, since
    /// the chapter title's default weight is `.bold`. Keep the family the user
    /// selected; the missing weight is covered by `syntheticBoldAttributes`,
    /// which is exactly how the body text already handles Regular-only fonts.
    private static func preservingFamily(_ requested: UIFont, resolved: UIFont) -> UIFont {
        resolved.familyName == requested.familyName ? resolved : requested
    }

    private static func supportsVariableWeight(_ font: UIFont) -> Bool {
        guard let axes = CTFontCopyVariationAxes(font as CTFont) as? [[CFString: Any]] else {
            return false
        }
        return axes.contains { axis in
            guard let identifier = axis[kCTFontVariationAxisIdentifierKey] as? NSNumber else {
                return false
            }
            // OpenType `wght` is encoded as the four-character tag 0x77676874.
            return identifier.uint32Value == 0x7767_6874
        }
    }
}
