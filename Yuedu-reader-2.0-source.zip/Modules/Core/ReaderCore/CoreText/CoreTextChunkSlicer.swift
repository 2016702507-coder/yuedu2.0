import YueduCoreText
import CoreText
import Foundation
import UIKit
import YueduCoreTextTypography

/// Slices a chapter's NSAttributedString into multiple chunks of approximately heightCap height each.
/// Pure function, safe to run on background threads.
enum CoreTextChunkSlicer {
    /// Default max height per chunk: ~3 screen heights, balancing slicing cost and memory
    static let defaultHeightCap: CGFloat = 2000

    /// When the natural fitRange would split a paragraph, look backward up to this many UTF-16 code units
    /// for the nearest paragraph boundary. Chunks that would become too short are left unsplit.
    static let paragraphBoundaryLookback: CGFloat = 400

    /// Slicing result
    struct Output {
        let chunks: [CoreTextChunk]
        let framesetter: CTFramesetter
        let attributedString: NSAttributedString
        /// Cost breakdown of the call that produced this output. Reported, not acted on —
        /// see `CoreTextSliceMetrics`.
        let metrics: CoreTextSliceMetrics
    }

    /// `slice` on the global concurrent executor, for the scroll engine's chapter load.
    /// The chunks are created here and handed to the caller (`sending`), which owns them
    /// from then on. The string stays shared read-only with the caller (`LayoutShared`).
    @concurrent
    static func sliceConcurrently(
        attributedString: LayoutShared<NSAttributedString>,
        chapterIndex: Int,
        contentWidth: CGFloat,
        writingMode: ReaderWritingMode,
        pageBackgroundColor: UIColor?,
        pageBackgroundImage: UIImage?,
        minimumBackdropExtent: CGFloat
    ) async -> sending Output {
        slice(
            attributedString: attributedString.wrappedValue,
            chapterIndex: chapterIndex,
            contentWidth: contentWidth,
            writingMode: writingMode,
            pageBackgroundColor: pageBackgroundColor,
            pageBackgroundImage: pageBackgroundImage,
            minimumBackdropExtent: minimumBackdropExtent
        )
    }

    /// - Parameter minimumBackdropExtent: along-scroll size of one viewport. A chapter that
    ///   carries a publication-authored page backdrop image and is shorter than this gets its
    ///   last chunk padded up to it — see `padForBackdrop`. Zero disables the padding.
    static func slice(
        attributedString attrStr: NSAttributedString,
        chapterIndex: Int,
        contentWidth: CGFloat,
        heightCap: CGFloat = defaultHeightCap,
        writingMode: ReaderWritingMode = .horizontal,
        pageBackgroundColor: UIColor? = nil,
        pageBackgroundImage: UIImage? = nil,
        minimumBackdropExtent: CGFloat = 0
    ) -> Output {
        let sliceStart = CoreTextSliceMetrics.now
        var metrics = CoreTextSliceMetrics()
        metrics.characterCount = attrStr.length

        let framesetterStart = CoreTextSliceMetrics.now
        let framesetter = CoreTextFramesetterFactory.make(for: attrStr)
        metrics.recordFramesetter(since: framesetterStart)

        let totalLen = attrStr.length
        guard contentWidth > 0, totalLen > 0 else {
            metrics.totalSeconds = CoreTextSliceMetrics.now - sliceStart
            return Output(
                chunks: [],
                framesetter: framesetter,
                attributedString: attrStr,
                metrics: metrics
            )
        }

        if writingMode.isVertical {
            return sliceVertical(
                attributedString: attrStr,
                framesetter: framesetter,
                chapterIndex: chapterIndex,
                contentHeight: contentWidth,
                widthCap: heightCap,
                writingMode: writingMode,
                pageBackgroundColor: pageBackgroundColor,
                pageBackgroundImage: pageBackgroundImage,
                minimumBackdropExtent: minimumBackdropExtent,
                metrics: metrics,
                sliceStart: sliceStart
            )
        }

        let nsString = attrStr.string as NSString
        var chunks: [CoreTextChunk] = []
        var offset: CFIndex = 0

        while offset < totalLen {
            let constraints = CGSize(width: contentWidth, height: heightCap)
            var fitRange = CFRange(location: 0, length: 0)
            var suggested = metrics.measuringSuggestFrameSize {
                CTFramesetterSuggestFrameSizeWithConstraints(
                    framesetter,
                    CFRange(location: offset, length: 0),
                    nil,
                    constraints,
                    &fitRange
                )
            }

            // Single element exceeds heightCap (e.g. cover image, large illustration) → re-fetch without height limit
            if fitRange.length == 0 {
                var fr2 = CFRange(location: 0, length: 0)
                suggested = metrics.measuringSuggestFrameSize {
                    CTFramesetterSuggestFrameSizeWithConstraints(
                        framesetter,
                        CFRange(location: offset, length: 0),
                        nil,
                        CGSize(width: contentWidth, height: .greatestFiniteMagnitude),
                        &fr2
                    )
                }
                fitRange = fr2
            }

            // Guard: CoreText occasionally returns length 0; force advance at least 1 character to avoid infinite loop
            let consumeLen = max(fitRange.length, 1)
            var actualRange = CFRange(location: offset, length: min(consumeLen, totalLen - offset))

            // ── Paragraph-boundary adjustment ──
            // When the natural fitRange would split a paragraph, walk backward to the nearest \n
            // so each chunk starts at a paragraph boundary, preserving paragraphSpacingBefore and firstLineHeadIndent.
            if actualRange.length > 0, actualRange.location + actualRange.length < totalLen {
                let chunkEnd = actualRange.location + actualRange.length
                let lookbackStart = max(actualRange.location, chunkEnd - Int(paragraphBoundaryLookback))
                var paragraphBoundary: Int?
                var searchPos = chunkEnd - 1
                while searchPos >= lookbackStart {
                    let char = nsString.character(at: searchPos)
                    if char == 0x000A { // \n paragraph separator
                        paragraphBoundary = searchPos + 1 // include the \n in the current chunk
                        break
                    }
                    searchPos -= 1
                }
                if let boundary = paragraphBoundary, boundary > actualRange.location {
                    let adjustedLen = boundary - actualRange.location
                    actualRange.length = adjustedLen
                    // Recompute height for the trimmed range
                    var frAdj = CFRange(location: 0, length: 0)
                    suggested = metrics.measuringSuggestFrameSize {
                        CTFramesetterSuggestFrameSizeWithConstraints(
                            framesetter,
                            actualRange,
                            nil,
                            CGSize(width: contentWidth, height: .greatestFiniteMagnitude),
                            &frAdj
                        )
                    }
                }
            }

            var actualHeight = ceil(max(suggested.height, 1))

            // Ensure chunk height accommodates block images (drawHeight) within the range
            actualHeight = max(actualHeight, blockImageHeight(in: attrStr, range: actualRange))
            actualHeight = max(actualHeight, floatImageHeight(in: attrStr, range: actualRange))

            var frameBuild = makeHorizontalFrame(
                framesetter: framesetter,
                attrStr: attrStr,
                range: actualRange,
                chunkSize: CGSize(width: contentWidth, height: actualHeight),
                writingMode: writingMode,
                metrics: &metrics
            )

            if let splitLocation = frameBuild.splitBeforeFloatLocation,
               splitLocation > actualRange.location {
                actualRange.length = splitLocation - actualRange.location
                var frAdj = CFRange(location: 0, length: 0)
                suggested = metrics.measuringSuggestFrameSize {
                    CTFramesetterSuggestFrameSizeWithConstraints(
                        framesetter,
                        actualRange,
                        nil,
                        CGSize(width: contentWidth, height: .greatestFiniteMagnitude),
                        &frAdj
                    )
                }
                actualHeight = ceil(max(suggested.height, 1))
                actualHeight = max(actualHeight, blockImageHeight(in: attrStr, range: actualRange))
                frameBuild = makeHorizontalFrame(
                    framesetter: framesetter,
                    attrStr: attrStr,
                    range: actualRange,
                    chunkSize: CGSize(width: contentWidth, height: actualHeight),
                    writingMode: writingMode,
                    metrics: &metrics
                )
            }

            var visible = CTFrameGetVisibleStringRange(frameBuild.frame)
            if visible.length < actualRange.length,
               visible.length == 0 || visible.location == actualRange.location {
                // `SuggestFrameSize` sums each line's ascent + descent, but a frame only keeps
                // a line whose baseline lies inside its path. A paragraph pinned to one line
                // height (`min == max`, as a block image is) can come back with a negative
                // descent — baseline below the line box — so the suggested height ends just
                // above the baseline and the frame drops that line. When it was the chunk's
                // only line the chunk laid out nothing and its image vanished. Size the chunk
                // from where the range's lines actually end instead.
                let laidOut = laidOutHeight(
                    framesetter: framesetter,
                    range: actualRange,
                    width: contentWidth,
                    metrics: &metrics
                )
                if laidOut > actualHeight {
                    actualHeight = laidOut
                    frameBuild = makeHorizontalFrame(
                        framesetter: framesetter,
                        attrStr: attrStr,
                        range: actualRange,
                        chunkSize: CGSize(width: contentWidth, height: actualHeight),
                        writingMode: writingMode,
                        metrics: &metrics
                    )
                    visible = CTFrameGetVisibleStringRange(frameBuild.frame)
                }
            }
            if visible.location == actualRange.location,
               visible.length > 0,
               visible.length < actualRange.length {
                actualRange.length = visible.length
                frameBuild = makeHorizontalFrame(
                    framesetter: framesetter,
                    attrStr: attrStr,
                    range: actualRange,
                    chunkSize: CGSize(width: contentWidth, height: actualHeight),
                    writingMode: writingMode,
                    metrics: &metrics
                )
            }

            // The 段距 between this chunk's last paragraph and the next chunk's first lives
            // in neither frame: Core Text puts nothing under a frame's last line and drops
            // `paragraphSpacingBefore` on its first. Chunks stack edge to edge, so the
            // break would read as an ordinary line step. A frame lays its lines out from
            // the top, so the extra height lands under the last line. Measure from where
            // the text ends, not from the rounded-up height, or the seam carries that
            // rounding on top of the 段距.
            let seamGap = paragraphGap(after: actualRange, in: attrStr)
            if seamGap > 0 {
                actualHeight = max(actualHeight, textBottom(of: frameBuild.frame, height: actualHeight) + seamGap)
                frameBuild = makeHorizontalFrame(
                    framesetter: framesetter,
                    attrStr: attrStr,
                    range: actualRange,
                    chunkSize: CGSize(width: contentWidth, height: actualHeight),
                    writingMode: writingMode,
                    metrics: &metrics
                )
            }

            let chunk = makeHorizontalChunk(
                frameBuild: frameBuild,
                framesetter: framesetter,
                attrStr: attrStr,
                chapterIndex: chapterIndex,
                range: actualRange,
                size: CGSize(width: contentWidth, height: actualHeight),
                writingMode: writingMode,
                pageBackgroundColor: pageBackgroundColor,
                pageBackgroundImage: pageBackgroundImage,
                metrics: &metrics
            )
            chunks.append(chunk)

            offset = actualRange.location + actualRange.length
        }

        padForBackdrop(
            chunks: &chunks,
            minimumBackdropExtent: minimumBackdropExtent,
            contentWidth: contentWidth,
            framesetter: framesetter,
            attrStr: attrStr,
            chapterIndex: chapterIndex,
            writingMode: writingMode,
            pageBackgroundColor: pageBackgroundColor,
            pageBackgroundImage: pageBackgroundImage,
            metrics: &metrics
        )

        metrics.chunkCount = chunks.count
        metrics.totalSeconds = CoreTextSliceMetrics.now - sliceStart
        return Output(
            chunks: chunks,
            framesetter: framesetter,
            attributedString: attrStr,
            metrics: metrics
        )
    }

    /// The publication-authored page backdrop is painted into the chunk's own box
    /// (`CoreTextChunkBackdropView`), so a chapter shorter than one screen cropped the
    /// artwork down to the height of its text: 《红楼梦》's 回目扉页 — a title plus two
    /// footnotes over a full-bleed `background-image` on `<body>` — showed only the top
    /// third of the painting, while paged mode paints that same image across a whole page
    /// (`CoreTextPageView.drawContent`). Give the chapter's last chunk the missing extent so
    /// the artwork gets one viewport in both modes. Scoped to chapters that actually carry a
    /// backdrop image; a chapter with only an authored fill colour keeps its natural height.
    /// Delete this once scroll mode has a page box of its own.
    private static func padForBackdrop(
        chunks: inout [CoreTextChunk],
        minimumBackdropExtent: CGFloat,
        contentWidth: CGFloat,
        framesetter: CTFramesetter,
        attrStr: NSAttributedString,
        chapterIndex: Int,
        writingMode: ReaderWritingMode,
        pageBackgroundColor: UIColor?,
        pageBackgroundImage: UIImage?,
        metrics: inout CoreTextSliceMetrics
    ) {
        guard pageBackgroundImage != nil,
              minimumBackdropExtent > 0,
              let last = chunks.last
        else { return }
        let total = chunks.reduce(CGFloat(0)) { $0 + $1.height }
        guard total < minimumBackdropExtent else { return }

        // Height only — the character range is untouched, so progress, TTS and selection
        // math see exactly the same chapter they did before.
        let paddedSize = CGSize(
            width: contentWidth,
            height: last.height + (minimumBackdropExtent - total)
        )
        // Two statements, not one nested expression: both helpers take `metrics` inout, and
        // nesting them would be overlapping exclusive access to the same variable.
        let paddedBuild = makeHorizontalFrame(
            framesetter: framesetter,
            attrStr: attrStr,
            range: last.charRange,
            chunkSize: paddedSize,
            writingMode: writingMode,
            metrics: &metrics
        )
        chunks[chunks.count - 1] = makeHorizontalChunk(
            frameBuild: paddedBuild,
            framesetter: framesetter,
            attrStr: attrStr,
            chapterIndex: chapterIndex,
            range: last.charRange,
            size: paddedSize,
            writingMode: writingMode,
            pageBackgroundColor: pageBackgroundColor,
            pageBackgroundImage: pageBackgroundImage,
            metrics: &metrics
        )
    }

    private static func makeHorizontalChunk(
        frameBuild: HorizontalFrameBuild,
        framesetter: CTFramesetter,
        attrStr: NSAttributedString,
        chapterIndex: Int,
        range: CFRange,
        size: CGSize,
        writingMode: ReaderWritingMode,
        pageBackgroundColor: UIColor?,
        pageBackgroundImage: UIImage?,
        metrics: inout CoreTextSliceMetrics
    ) -> CoreTextChunk {
        // Extract block decorations during slicing so they survive frame eviction
        let decorations = metrics.measuringExtract {
            extractBlockRenderables(
                frame: frameBuild.frame,
                chunkSize: size,
                attributedString: attrStr,
                charRange: range,
                writingMode: writingMode
            )
        }

        // `CoreTextChunk.init` eagerly runs `CoreTextChunkAttachmentExtractor.extract`
        // whenever it is handed a frame, so the init itself is a measured layout cost.
        return metrics.measuringChunkInit {
            CoreTextChunk(
                chapterIndex: chapterIndex,
                charRange: range,
                size: size,
                framesetter: framesetter,
                attributedString: attrStr,
                frame: frameBuild.frame,
                writingMode: writingMode,
                floatNotch: frameBuild.floatNotch,
                floatAttachments: frameBuild.floatAttachments,
                blockRenderables: decorations,
                pageBackgroundColor: pageBackgroundColor,
                pageBackgroundImage: pageBackgroundImage
            )
        }
    }

    private static func sliceVertical(
        attributedString attrStr: NSAttributedString,
        framesetter: CTFramesetter,
        chapterIndex: Int,
        contentHeight: CGFloat,
        widthCap: CGFloat,
        writingMode: ReaderWritingMode,
        pageBackgroundColor: UIColor?,
        pageBackgroundImage: UIImage?,
        minimumBackdropExtent: CGFloat,
        metrics: CoreTextSliceMetrics,
        sliceStart: TimeInterval
    ) -> Output {
        var metrics = metrics
        let totalLen = attrStr.length
        var chunks: [CoreTextChunk] = []
        var offset: CFIndex = 0
        let chunkWidth = max(1, widthCap)
        let chunkHeight = max(1, contentHeight)

        while offset < totalLen {
            let path = CGPath(
                rect: CGRect(x: 0, y: 0, width: chunkWidth, height: chunkHeight),
                transform: nil
            )
            let searchRange = CFRange(location: offset, length: totalLen - offset)
            let probeFrame = metrics.measuringCreateFrame {
                CoreTextPaginator.makeFrame(
                    framesetter: framesetter,
                    range: searchRange,
                    path: path,
                    writingMode: writingMode
                )
            }
            let visible = CTFrameGetVisibleStringRange(probeFrame)
            let consumeLen = max(visible.length, 1)
            let actualRange = CFRange(location: offset, length: min(consumeLen, totalLen - offset))
            let frame = metrics.measuringCreateFrame {
                CoreTextPaginator.makeFrame(
                    framesetter: framesetter,
                    range: actualRange,
                    path: path,
                    writingMode: writingMode
                )
            }
            var finalFrame = frame
            var finalChunkWidth = chunkWidth
            if actualRange.location + actualRange.length < totalLen,
               let fittedWidth = verticalSeamWidth(
                   framesetter: framesetter,
                   frame: frame,
                   width: chunkWidth,
                   columnHeight: chunkHeight,
                   nextLocation: actualRange.location + actualRange.length,
                   writingMode: writingMode,
                   metrics: &metrics
               ) {
                // Chunks stack edge to edge, so a chunk has to end exactly where the next
                // chunk's first column needs it to. Left at `widthCap`, the strip too narrow
                // for another column widened every seam, and when a paragraph ended the
                // chunk its 段距 lived in neither frame. Columns are laid out from the right
                // edge, so changing the path's width leaves every one of them where it was.
                let fittedPath = CGPath(
                    rect: CGRect(x: 0, y: 0, width: fittedWidth, height: chunkHeight),
                    transform: nil
                )
                finalFrame = metrics.measuringCreateFrame {
                    CoreTextPaginator.makeFrame(
                        framesetter: framesetter,
                        range: actualRange,
                        path: fittedPath,
                        writingMode: writingMode
                    )
                }
                finalChunkWidth = fittedWidth
            } else {
                // Same backdrop rule as `padForBackdrop`, applied where vertical-rl decides
                // the chapter's final column-block width: the scroll axis here is width, so
                // compacting a short chapter to its used width cropped a full-bleed backdrop
                // exactly the way the horizontal path did. A chapter that needed more than
                // one chunk is already `widthCap` wide — far past one viewport — so the floor
                // only applies while this is still the chapter's only chunk.
                let backdropFloor = (pageBackgroundImage != nil && chunks.isEmpty)
                    ? max(0, minimumBackdropExtent)
                    : 0
                let usedWidth = min(
                    chunkWidth,
                    max(1, max(verticalUsedWidth(of: frame) + 2, backdropFloor))
                )
                if usedWidth < chunkWidth {
                    let compactPath = CGPath(
                        rect: CGRect(x: 0, y: 0, width: usedWidth, height: chunkHeight),
                        transform: nil
                    )
                    let compactFrame = metrics.measuringCreateFrame {
                        CoreTextPaginator.makeFrame(
                            framesetter: framesetter,
                            range: actualRange,
                            path: compactPath,
                            writingMode: writingMode
                        )
                    }
                    let compactVisible = CTFrameGetVisibleStringRange(compactFrame)
                    if compactVisible.location == actualRange.location,
                       compactVisible.length >= actualRange.length {
                        finalFrame = compactFrame
                        finalChunkWidth = usedWidth
                    }
                }
            }

            let chunkSize = CGSize(width: finalChunkWidth, height: chunkHeight)
            let annotations = metrics.measuringExtract {
                extractInlineAnnotations(
                    frame: finalFrame,
                    chunkSize: chunkSize,
                    attributedString: attrStr
                )
            }
            let titleRenderables = metrics.measuringExtract {
                extractBlockRenderables(
                    frame: finalFrame,
                    chunkSize: chunkSize,
                    attributedString: attrStr,
                    charRange: actualRange,
                    writingMode: writingMode
                )
            }
            let chunk = metrics.measuringChunkInit {
                CoreTextChunk(
                    chapterIndex: chapterIndex,
                    charRange: actualRange,
                    size: chunkSize,
                    framesetter: framesetter,
                    attributedString: attrStr,
                    frame: finalFrame,
                    writingMode: writingMode,
                    blockRenderables: titleRenderables,
                    inlineAnnotations: annotations,
                    combinedUprightCells: CoreTextChunk.combinedUprightCells(in: finalFrame, chunkSize: chunkSize),
                    pageBackgroundColor: pageBackgroundColor,
                    pageBackgroundImage: pageBackgroundImage
                )
            }
            chunks.append(chunk)
            offset = actualRange.location + actualRange.length
        }

        metrics.chunkCount = chunks.count
        metrics.totalSeconds = CoreTextSliceMetrics.now - sliceStart
        return Output(
            chunks: chunks,
            framesetter: framesetter,
            attributedString: attrStr,
            metrics: metrics
        )
    }

    /// Width a vertical chunk ending at `nextLocation` needs so that, stacked against the
    /// chunk that starts there, the next column lands at the pitch Core Text gives it inside
    /// one frame — the line step, or the paragraph step when a paragraph ends the chunk
    /// (Core Text drops `paragraphSpacingBefore` on a frame's first column, so the next
    /// chunk cannot carry it). Both distances are measured from small frames rather than
    /// derived from font metrics: Core Text's vertical line pitch is not ascent + descent.
    /// Nil only when the chunk lays out no column, or the next column is too wide for any
    /// chunk; the chunk then keeps the cap width, as every vertical chunk used to.
    private static func verticalSeamWidth(
        framesetter: CTFramesetter,
        frame: CTFrame,
        width: CGFloat,
        columnHeight: CGFloat,
        nextLocation: CFIndex,
        writingMode: ReaderWritingMode,
        metrics: inout CoreTextSliceMetrics
    ) -> CGFloat? {
        let lines = CTFrameGetLines(frame) as! [CTLine]
        guard let lastLine = lines.last else { return nil }
        var lastOrigin = CGPoint.zero
        CTFrameGetLineOrigins(frame, CFRange(location: lines.count - 1, length: 1), &lastOrigin)
        let lastStart = CTLineGetStringRange(lastLine).location

        // Enough text for the next column: the suggestion ignores a first-line indent, so
        // it can only overshoot the column's real length, and only the first column of each
        // probe is read.
        let typesetter = CTFramesetterGetTypesetter(framesetter)
        let nextLength = CTTypesetterSuggestLineBreak(typesetter, nextLocation, Double(columnHeight))
        guard nextLength > 0 else { return nil }

        func columnsFromRight(_ range: CFRange, probeWidth: CGFloat) -> [CGFloat] {
            let probe = metrics.measuringCreateFrame {
                CoreTextPaginator.makeFrame(
                    framesetter: framesetter,
                    range: range,
                    path: CGPath(rect: CGRect(x: 0, y: 0, width: probeWidth, height: columnHeight), transform: nil),
                    writingMode: writingMode
                )
            }
            let count = CFArrayGetCount(CTFrameGetLines(probe))
            var origins = [CGPoint](repeating: .zero, count: count)
            CTFrameGetLineOrigins(probe, CFRange(location: 0, length: count), &origins)
            return origins.map { probeWidth - $0.x }
        }
        // The chunk's last column followed by the next, as one frame lays them out. Each
        // fits in `width` on its own; twice that holds both.
        let pair = columnsFromRight(
            CFRange(location: lastStart, length: nextLocation + nextLength - lastStart),
            probeWidth: width * 2
        )
        // The next column where the next chunk's frame will put it.
        let opening = columnsFromRight(CFRange(location: nextLocation, length: nextLength), probeWidth: width)
        guard pair.count >= 2, let nextOffset = opening.first else { return nil }

        return (width - lastOrigin.x) + (pair[1] - pair[0]) - nextOffset
    }

    private static func verticalUsedWidth(of frame: CTFrame) -> CGFloat {
        let lines = CTFrameGetLines(frame) as! [CTLine]
        guard !lines.isEmpty else { return 1 }

        var origins = [CGPoint](repeating: .zero, count: lines.count)
        CTFrameGetLineOrigins(frame, CFRangeMake(0, lines.count), &origins)

        var minX = CGFloat.greatestFiniteMagnitude
        var maxX = -CGFloat.greatestFiniteMagnitude
        for (index, line) in lines.enumerated() {
            var ascent: CGFloat = 0
            var descent: CGFloat = 0
            _ = CTLineGetTypographicBounds(line, &ascent, &descent, nil)
            let originX = origins[index].x
            minX = min(minX, originX - descent)
            maxX = max(maxX, originX + ascent)
        }

        guard minX.isFinite, maxX.isFinite, maxX > minX else { return 1 }
        return ceil(maxX - minX)
    }

    private struct HorizontalFrameBuild {
        let frame: CTFrame
        let floatNotch: CGRect?
        let floatAttachments: [CoreTextPaginator.RenderedAttachment]
        let splitBeforeFloatLocation: Int?
    }

    private static func makeHorizontalFrame(
        framesetter: CTFramesetter,
        attrStr: NSAttributedString,
        range: CFRange,
        chunkSize: CGSize,
        writingMode: ReaderWritingMode,
        metrics: inout CoreTextSliceMetrics
    ) -> HorizontalFrameBuild {
        let contentRect = CGRect(origin: .zero, size: chunkSize)
        let rectangularPath = CGPath(rect: contentRect, transform: nil)
        guard !writingMode.isVertical,
              let marker = CoreTextPaginator.floatMarkers(in: attrStr).first(where: { marker in
                  marker.offset >= range.location
                      && marker.offset < range.location + range.length
                      && marker.placeholder.image != nil
              })
        else {
            let frame = metrics.measuringCreateFrame {
                CoreTextPaginator.makeFrame(
                    framesetter: framesetter,
                    range: range,
                    path: rectangularPath,
                    writingMode: writingMode
                )
            }
            return HorizontalFrameBuild(
                frame: frame,
                floatNotch: nil,
                floatAttachments: [],
                splitBeforeFloatLocation: nil
            )
        }

        let probe = metrics.measuringCreateFrame {
            CoreTextPaginator.makeFrame(
                framesetter: framesetter,
                range: range,
                path: rectangularPath,
                writingMode: writingMode
            )
        }
        guard let lineTop = CoreTextPaginator.lineTopY(in: probe, offset: marker.offset, contentPathRect: contentRect),
              let image = marker.placeholder.image else {
            return HorizontalFrameBuild(
                frame: probe,
                floatNotch: nil,
                floatAttachments: [],
                splitBeforeFloatLocation: nil
            )
        }

        let p = marker.placeholder
        let notchWidth = p.drawWidth + p.marginLeft + p.marginRight
        let notchHeight = min(contentRect.height, p.drawHeight + p.marginTop + p.marginBottom)
        let notchBottom = lineTop - notchHeight
        if notchBottom < contentRect.minY, marker.offset > range.location {
            return HorizontalFrameBuild(
                frame: probe,
                floatNotch: nil,
                floatAttachments: [],
                splitBeforeFloatLocation: marker.offset
            )
        }

        let clampedBottom = max(contentRect.minY, notchBottom)
        let uiTop = chunkSize.height - lineTop + p.marginTop
        let notch: CGRect
        let attachmentRect: CGRect
        switch p.side {
        case .left:
            notch = CGRect(x: contentRect.minX, y: clampedBottom, width: notchWidth, height: lineTop - clampedBottom)
            attachmentRect = CGRect(x: contentRect.minX + p.marginLeft, y: uiTop, width: p.drawWidth, height: p.drawHeight)
        case .right:
            notch = CGRect(x: contentRect.maxX - notchWidth, y: clampedBottom, width: notchWidth, height: lineTop - clampedBottom)
            attachmentRect = CGRect(x: contentRect.maxX - p.marginRight - p.drawWidth, y: uiTop, width: p.drawWidth, height: p.drawHeight)
        }

        let path = CoreTextPaginator.framePath(contentPathRect: contentRect, floatNotch: notch)
        let frame = metrics.measuringCreateFrame {
            CoreTextPaginator.makeFrame(
                framesetter: framesetter,
                range: range,
                path: path,
                writingMode: writingMode
            )
        }
        let attachment = CoreTextPaginator.RenderedAttachment(
            rect: attachmentRect,
            image: image,
            opacity: 1,
            sourceHref: p.source.isEmpty ? nil : p.source,
            alt: p.alt,
            originalSize: image.size
        )
        return HorizontalFrameBuild(
            frame: frame,
            floatNotch: notch,
            floatAttachments: [attachment],
            splitBeforeFloatLocation: nil
        )
    }

    /// The space Core Text puts between two paragraphs in one frame — the first one's
    /// `paragraphSpacing` plus the second one's `paragraphSpacingBefore` — when `range`
    /// ends at a paragraph break with more text after it. Zero at the chapter's end, or
    /// when the range stops inside a paragraph.
    private static func paragraphGap(after range: CFRange, in attrStr: NSAttributedString) -> CGFloat {
        let end = range.location + range.length
        guard end > 0, end < attrStr.length,
              (attrStr.string as NSString).character(at: end - 1) == 0x000A
        else { return 0 }
        let ending = attrStr.attribute(.paragraphStyle, at: end - 1, effectiveRange: nil) as? NSParagraphStyle
        let opening = attrStr.attribute(.paragraphStyle, at: end, effectiveRange: nil) as? NSParagraphStyle
        return max(0, ending?.paragraphSpacing ?? 0) + max(0, opening?.paragraphSpacingBefore ?? 0)
    }

    /// How far below the top of a `height`-tall frame its deepest line ends.
    private static func textBottom(of frame: CTFrame, height: CGFloat) -> CGFloat {
        let lines = CTFrameGetLines(frame) as! [CTLine]
        guard !lines.isEmpty else { return 0 }
        var origins = [CGPoint](repeating: .zero, count: lines.count)
        CTFrameGetLineOrigins(frame, CFRange(location: 0, length: lines.count), &origins)
        var bottom: CGFloat = 0
        for (index, line) in lines.enumerated() {
            var descent: CGFloat = 0
            _ = CTLineGetTypographicBounds(line, nil, &descent, nil)
            bottom = max(bottom, height - origins[index].y + max(0, descent))
        }
        return bottom
    }

    /// Height a rectangular frame needs to keep every line of `range`: the deepest line's
    /// baseline (measured from the top of an unbounded frame) plus whatever descent it has
    /// below that baseline. A negative descent adds nothing — the baseline itself must fit.
    private static func laidOutHeight(
        framesetter: CTFramesetter,
        range: CFRange,
        width: CGFloat,
        metrics: inout CoreTextSliceMetrics
    ) -> CGFloat {
        // Far taller than any one chunk (the height cap is 2000pt; the tallest block image is
        // bounded by the viewport), yet small enough that a baseline measured from it keeps
        // sub-point precision if Core Text stores line positions in single precision.
        let probeHeight: CGFloat = 1_000_000
        let frame = metrics.measuringCreateFrame {
            CTFramesetterCreateFrame(
                framesetter,
                range,
                CGPath(rect: CGRect(x: 0, y: 0, width: width, height: probeHeight), transform: nil),
                nil
            )
        }
        let lines = CTFrameGetLines(frame) as! [CTLine]
        guard !lines.isEmpty else { return 0 }
        var origins = [CGPoint](repeating: .zero, count: lines.count)
        CTFrameGetLineOrigins(frame, CFRange(location: 0, length: lines.count), &origins)
        var bottom: CGFloat = 0
        for (index, line) in lines.enumerated() {
            var descent: CGFloat = 0
            _ = CTLineGetTypographicBounds(line, nil, &descent, nil)
            bottom = max(bottom, probeHeight - origins[index].y + max(0, descent))
        }
        return ceil(bottom)
    }

    /// Scans the specified range for block images with CTRunDelegate and returns the maximum drawHeight.
    /// Ensures the chunk path height is large enough to contain the entire image (CoreText measurement may be slightly smaller than drawHeight).
    private static func blockImageHeight(in attrStr: NSAttributedString, range: CFRange) -> CGFloat {
        let nsRange = NSRange(location: range.location, length: range.length)
        guard nsRange.location >= 0,
              nsRange.location + nsRange.length <= attrStr.length else { return 0 }
        let delegateKey = NSAttributedString.Key(kCTRunDelegateAttributeName as String)
        var maxHeight: CGFloat = 0
        attrStr.enumerateAttribute(delegateKey, in: nsRange, options: []) { value, effectiveRange, _ in
            guard let v = value else { return }
            guard attrStr.attribute(HTMLAttributedStringBuilder.spacerRunAttribute, at: effectiveRange.location, effectiveRange: nil) == nil else { return }
            let ctDelegate = v as! CTRunDelegate
            let ptr = CTRunDelegateGetRefCon(ctDelegate)
            let info = Unmanaged<ImageRunInfo>.fromOpaque(ptr).takeUnretainedValue()
            if info.displayMode == .block {
                maxHeight = max(maxHeight, info.drawHeight)
            }
        }
        return maxHeight
    }

    private static func floatImageHeight(in attrStr: NSAttributedString, range: CFRange) -> CGFloat {
        CoreTextPaginator.floatMarkers(in: attrStr)
            .filter { marker in
                marker.offset >= range.location && marker.offset < range.location + range.length
            }
            .map { marker in
                marker.placeholder.drawHeight
                    + marker.placeholder.marginTop
                    + marker.placeholder.marginBottom
            }
            .max() ?? 0
    }

    // MARK: - Block renderable extraction

    /// Uses the same authored decoration layers and geometry as paged mode.
    static func extractBlockRenderables(
        frame: CTFrame,
        chunkSize: CGSize,
        attributedString: NSAttributedString,
        charRange: CFRange,
        writingMode: ReaderWritingMode = .horizontal
    ) -> [CoreTextPaginator.RenderedBlockRenderable] {
        let count = (CTFrameGetLines(frame) as! [CTLine]).count
        var origins = [CGPoint](repeating: .zero, count: count)
        CTFrameGetLineOrigins(frame, CFRange(location: 0, length: count), &origins)
        return CoreTextPaginator.extractFrameBlockRenderables(
            frame: frame, range: charRange, lineOrigins: origins,
            contentPathRect: CGRect(origin: .zero, size: chunkSize),
            renderSize: chunkSize, attributedString: attributedString,
            writingMode: writingMode,
            // Preserve the existing vertical-scroll title-only contract; vertical
            // authored decoration support is a separate layout concern.
            includeHTMLDecorations: !writingMode.isVertical
        )
    }

    // MARK: - Inline annotation extraction

    /// Extracts inline text annotations (span.small notes in vertical writing mode) from a chunk's CTFrame.
    /// Mirrors CoreTextPaginator.extractInlineAnnotations but operates on a single chunk frame.
    static func extractInlineAnnotations(
        frame: CTFrame,
        chunkSize: CGSize,
        attributedString: NSAttributedString
    ) -> [CoreTextPaginator.RenderedInlineAnnotation] {
        let lines = CTFrameGetLines(frame) as! [CTLine]
        guard !lines.isEmpty else { return [] }

        var origins = [CGPoint](repeating: .zero, count: lines.count)
        CTFrameGetLineOrigins(frame, CFRangeMake(0, lines.count), &origins)
        let delegateKey = NSAttributedString.Key(kCTRunDelegateAttributeName as String)

        var result: [CoreTextPaginator.RenderedInlineAnnotation] = []

        for (lineIdx, line) in lines.enumerated() {
            let lineOrigin = origins[lineIdx]
            let runs = CTLineGetGlyphRuns(line) as! [CTRun]
            for run in runs {
                let attrs = CTRunGetAttributes(run) as! [NSAttributedString.Key: Any]
                guard attrs[HTMLAttributedStringBuilder.inlineAnnotationRunAttribute] != nil,
                      let delegate = attrs[delegateKey]
                else { continue }

                let ctDelegate = delegate as! CTRunDelegate
                let ptr = CTRunDelegateGetRefCon(ctDelegate)
                let info = Unmanaged<ImageRunInfo>.fromOpaque(ptr).takeUnretainedValue()
                guard let annotation = info as? InlineAnnotationRunInfo else { continue }

                let runLocation = CTRunGetStringRange(run).location
                let textAdvance = GlyphBoundary.offset(line, at: runLocation)
                var lineAscent: CGFloat = 0
                var lineDescent: CGFloat = 0
                _ = CTLineGetTypographicBounds(line, &lineAscent, &lineDescent, nil)
                let typographicCenterX = lineOrigin.x + (lineAscent - lineDescent) / 2

                let uiRect = CGRect(
                    x: typographicCenterX - (annotation.drawWidth / 2),
                    y: chunkSize.height - lineOrigin.y + textAdvance,
                    width: annotation.drawWidth,
                    height: annotation.drawHeight
                )

                result.append(CoreTextPaginator.RenderedInlineAnnotation(
                    uiRect: uiRect,
                    attributedString: annotation.attributedString
                ))
            }
        }

        return result
    }
}
