import YueduCoreText
import AVFoundation
import Combine
import MediaPlayer
import UIKit

enum TTSPlaybackState {
    case stopped
    case playing
    case paused
}

enum TTSPlaybackRouting {
    static func shouldUseHTTP(text: String, httpTemplate: String, useSystemVoice: Bool) -> Bool {
        if DirectChapterAudioResolver.request(from: text) != nil {
            return true
        }
        if useSystemVoice {
            return false
        }
        return !httpTemplate.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}

extension Notification.Name {
    static let ttsFloatingPlayerOpenPanel = Notification.Name("ttsFloatingPlayerOpenPanel")
}

/// Which kind of audio is currently feeding the global mini-player.
enum NowPlayingSource {
    case none
    case tts        // reader-scoped TTS narration (lives only while a reader is open)
    case audiobook  // app-global audiobook playback (persists across all pages)
}

/// Shared hub that backs the `NowPlayingMiniPlayer` mini-player and routes its
/// controls to whichever audio engine is active — TTS narration inside the reader,
/// or the long-lived `AudiobookPlayer` that keeps playing across every page.
///
/// Two visibility surfaces:
/// - `isVisible`: the in-reader TTS mini-player (`.reader` placement), allowed while a
///   reader is on screen.
/// - `showsGlobalBar`: the app-wide audiobook mini-player (`.global` placement),
///   shown on any page while an audiobook is loaded. The same placement shows narration
///   whose reader closed mid-narration (`holdsNarrationPastReader`): without it, closing
///   the book left the narration playing with no control for it on the shelf.
///
/// A reader on screen draws the audiobook in its own `.reader` placement, so the `.global`
/// one steps aside while one is (`readerHostsPlayer`). 書架 pushes the reader inside its tab,
/// under the app root's `.global` overlay: without that, both drew — two capsules.
@MainActor
final class NowPlayingHub: ObservableObject {
    static let shared = NowPlayingHub()

    @Published private(set) var source: NowPlayingSource = .none
    @Published private(set) var isVisible = false
    @Published private(set) var showsGlobalBar = false
    @Published private(set) var title = ""
    @Published private(set) var playbackState: TTSPlaybackState = .stopped
    @Published private(set) var currentSegmentIndex = 0
    @Published private(set) var totalSegments = 0
    @Published private(set) var audiobookBookId: UUID?
    @Published private(set) var coverImage: UIImage?
    /// Book title, used to render the title-card placeholder disc when there is no cover art.
    @Published private(set) var coverTitle: String = ""
    /// What the global bar's artwork opened, which the app root presents full screen over every
    /// tab. A reader's bar presents what it opens over that reader instead (`openFromArtwork()`).
    @Published var appRootDestination: ArtworkDestination?

    /// What the mini-player's artwork opens, full screen.
    enum ArtworkDestination: Hashable, Identifiable {
        /// The book a closed reader is still narrating: its reader takes the narration over.
        case narratedBook(UUID)
        /// The audiobook's player.
        case audiobookPlayer(UUID)

        var id: Self { self }
    }

    private weak var coordinator: TTSCoordinator?
    private weak var audiobook: AudiobookPlayer?
    private var audiobookCancellable: AnyCancellable?
    /// The readers on screen, each hosting a `.reader` mini-player. A set, not a flag: the
    /// next reader can appear before the one it replaces disappears.
    private var readerOverlayOwners: Set<UUID> = []
    private var allowsReaderOverlay: Bool { !readerOverlayOwners.isEmpty }
    /// A reader on screen hosts the mini-player, so the app root's `.global` one stays hidden.
    @Published private(set) var readerHostsPlayer = false

    /// Whether a mini-player placement draws. Exactly one surface shows audio at a time: the
    /// reader's while a reader is on screen, the app root's everywhere else.
    ///
    /// The root shows narration only once its reader has closed for good, not whenever no
    /// reader hosts the player: a reader merely covered by a page it pushed stops hosting
    /// while it is still alive, and tapping the root's bar reopens the book — a second reader
    /// over the one still narrating.
    static func showsMiniPlayer(
        inReader: Bool,
        readerTTSVisible: Bool,
        audiobookLoaded: Bool,
        narrationOutlivesReader: Bool,
        readerHostsPlayer: Bool
    ) -> Bool {
        if inReader { return readerTTSVisible || audiobookLoaded }
        return (audiobookLoaded || narrationOutlivesReader) && !readerHostsPlayer
    }

    var progressText: String {
        guard totalSegments > 0 else { return "" }
        return "\(currentSegmentIndex + 1)/\(totalSegments)"
    }

    // MARK: - TTS source (reader-scoped)

    func attach(_ coordinator: TTSCoordinator) {
        // TTS narration takes over the audio session from any playing audiobook.
        if source == .audiobook {
            audiobook?.stop()
            clearAudiobook()
        }
        self.coordinator = coordinator
        source = .tts
        update(from: coordinator)
    }

    func update(from coordinator: TTSCoordinator) {
        guard self.coordinator === coordinator, source == .tts else { return }
        // Called once per spoken sentence. `@Published` notifies on every assignment, equal
        // or not, so assigning all seven fields was seven publishes a sentence where one
        // (`currentSegmentIndex`) changed.
        if title != coordinator.floatingTitle { title = coordinator.floatingTitle }
        if coverImage !== coordinator.floatingCoverImage { coverImage = coordinator.floatingCoverImage }
        if coverTitle != coordinator.floatingCoverTitle { coverTitle = coordinator.floatingCoverTitle }
        if playbackState != coordinator.playbackState { playbackState = coordinator.playbackState }
        if currentSegmentIndex != coordinator.currentSegmentIndex { currentSegmentIndex = coordinator.currentSegmentIndex }
        if totalSegments != coordinator.totalSegments { totalSegments = coordinator.totalSegments }
        let visible = allowsReaderOverlay && coordinator.playbackState != .stopped
        if isVisible != visible { isVisible = visible }
    }

    func detach(_ coordinator: TTSCoordinator) {
        guard self.coordinator === coordinator else { return }
        self.coordinator = nil
        guard source == .tts else { return }
        source = .none
        resetPlaybackFields()
        isVisible = false
    }

    /// Detach a TTS coordinator that stopped and was freed before its detach could run. The
    /// hub's reference is weak, so it is already nil; a live coordinator is left alone.
    func detachDeallocatedCoordinator() {
        guard source == .tts, coordinator == nil else { return }
        source = .none
        resetPlaybackFields()
        isVisible = false
    }

    /// A reader appearing (`true`) or disappearing (`false`); `owner` identifies the reader.
    func setReaderOverlayVisible(_ visible: Bool, owner: UUID) {
        if visible {
            readerOverlayOwners.insert(owner)
        } else {
            readerOverlayOwners.remove(owner)
        }
        if readerHostsPlayer != allowsReaderOverlay { readerHostsPlayer = allowsReaderOverlay }
        if source == .tts, let coordinator {
            update(from: coordinator)
        } else {
            isVisible = false
        }
    }

    /// Whether the mini-player's controls drive `coordinator` — so a reader opens its own
    /// narration panel, not one over another book's narration still playing.
    func isNarrating(with coordinator: TTSCoordinator) -> Bool {
        source == .tts && self.coordinator === coordinator
    }

    // MARK: - Narration that outlives its reader

    /// The narrator of a reader that closed mid-narration, kept so listening goes on while
    /// the user reads something else.
    ///
    /// Narration has no text supply of its own: the next chapter comes from the reader's
    /// layout engine and chapter fetching, through callbacks that capture the reader. Holding
    /// the narrator holds that whole reader, deliberately, and for one reader at most — until
    /// narration stops, ends, or another book starts narrating. Every other closed reader is
    /// freed. This can go once narration supplies its own chapter text.
    private var heldNarration: TTSCoordinator? {
        didSet { publishHoldsNarrationPastReaderAfterTeardown() }
    }
    private var heldNarrationCancellable: AnyCancellable?
    /// A closed reader's narration is still going: the global bar shows it.
    ///
    /// Trails `heldNarration` by one main-actor turn. The hold is taken in
    /// `ReaderTeardownProbe.dismantleUIView`, while SwiftUI is tearing down the closed reader's
    /// view graph, whose mini-player observes this hub: publishing to it there traps on a Swift
    /// exclusivity check inside SwiftUI (`GraphHost.asyncTransaction`, seen on iOS 26.5 closing
    /// a book mid-narration). The next turn reaches every observer after the teardown returned:
    /// this moves the publish out of SwiftUI's call stack, it waits for nothing. It can publish
    /// directly again once the hold is no longer taken inside `dismantleUIView`.
    @Published private(set) var holdsNarrationPastReader = false

    private func publishHoldsNarrationPastReaderAfterTeardown() {
        Task { @MainActor [weak self] in
            guard let self else { return }
            let holds = self.heldNarration != nil
            if self.holdsNarrationPastReader != holds { self.holdsNarrationPastReader = holds }
        }
    }

    /// A reader leaving the view hierarchy for good hands over its narrator: kept while it is
    /// narrating (playing or paused), cut loose from the reader otherwise.
    func holdNarrationPastReader(_ coordinator: TTSCoordinator) {
        guard coordinator.playbackState != .stopped else {
            coordinator.clearReaderCallbacks()
            return
        }
        if let held = heldNarration, held !== coordinator {
            // Starting narration stops the narrator it replaces, so this one is already
            // stopped; stopping it again is a no-op.
            held.stop(reason: "replaced by another held narration")
            releaseHeldNarration()
        }
        heldNarration = coordinator
        heldNarrationCancellable = coordinator.$playbackState.sink { [weak self, weak coordinator] state in
            guard state == .stopped else { return }
            // `@Published` emits before the value is stored; release once it has settled.
            Task { @MainActor in
                guard let self, let coordinator, self.heldNarration === coordinator else { return }
                self.releaseHeldNarration()
            }
        }
    }

    private func releaseHeldNarration() {
        heldNarrationCancellable = nil
        heldNarration?.clearReaderCallbacks()
        heldNarration = nil
    }

    /// The narrator a reader opening on `bookID` takes over: the one a closed reader of the
    /// book left narrating. Taking it over means the narration goes on under the new reader —
    /// its panel, chapter controls and page-following — instead of that reader starting an
    /// idle narrator of its own beside it.
    ///
    /// Only looks. The reader asks while SwiftUI makes its state, inside a view update, where
    /// changing what the mini-players observe is not allowed; it claims the narrator with
    /// `takeOverHeldNarration(_:)` once it appears.
    func narrationToTakeOver(forBook bookID: UUID) -> TTSCoordinator? {
        guard let held = heldNarration,
              held.narrationBookID == bookID,
              held.playbackState != .stopped
        else { return nil }
        return held
    }

    /// A reader that took the held narrator over has appeared: the narration is its own now.
    /// The closed reader's callbacks are not cleared — the new reader replaces them next, and
    /// until then a chapter that ends still gets its next one.
    @discardableResult
    func takeOverHeldNarration(_ coordinator: TTSCoordinator) -> Bool {
        guard heldNarration === coordinator else { return false }
        heldNarrationCancellable = nil
        heldNarration = nil
        return true
    }

    /// The mini-player is showing narration whose reader has closed. No reader on screen drives
    /// it, so there is no playback panel to open for it: its artwork reopens the book instead —
    /// on the shelf, and in another book's reader. What the artwork does and what VoiceOver's
    /// hint says both follow this.
    var artworkReopensNarratedBook: Bool { source == .tts && holdsNarrationPastReader }

    /// The mini-player's artwork: what it opens, for the mini-player's host to present over
    /// itself. Narration whose reader has closed reopens its book, whose reader takes the narration
    /// over (`ReaderView.init`); an audiobook opens its player. The reader narrating opens its own
    /// 語音朗讀 panel instead, and this returns `nil`.
    func openFromArtwork() -> ArtworkDestination? {
        switch source {
        case .tts:
            guard artworkReopensNarratedBook else {
                NotificationCenter.default.post(name: .ttsFloatingPlayerOpenPanel, object: nil)
                return nil
            }
            guard let bookID = heldNarration?.narrationBookID else {
                ttsLog("[TTS][Hub] artwork tapped with no held narration to reopen")
                return nil
            }
            return .narratedBook(bookID)
        case .audiobook:
            guard let audiobookBookId else {
                ttsLog("[TTS][Hub] artwork tapped with no audiobook loaded")
                return nil
            }
            return .audiobookPlayer(audiobookBookId)
        case .none:
            return nil
        }
    }

    /// Stop TTS narration only (used when an audiobook takes over the audio session).
    func stopTTSIfActive() {
        if source == .tts { coordinator?.stop(reason: "audiobook takeover") }
    }

    /// A video takes the audio session: the audiobook pauses where it is, so its bar can
    /// resume it afterwards, and narration stops.
    func yieldToVideo() {
        if source == .audiobook, audiobook?.isPlaying == true { audiobook?.pause() }
        if source == .tts { coordinator?.stop(reason: "video takeover") }
    }

    // MARK: - Audiobook source (app-global)

    /// Bind the hub to the live audiobook session so the global mini-player can mirror
    /// and control it from any page. Idempotent — safe to call on every `start`.
    func attachAudiobook(_ player: AudiobookPlayer) {
        audiobook = player
        source = .audiobook
        isVisible = false
        audiobookCancellable = player.objectWillChange.sink { [weak self, weak player] _ in
            guard let self, let player else { return }
            // objectWillChange fires before the value settles; defer the read.
            Task { @MainActor in self.refreshFromAudiobook(player) }
        }
        refreshFromAudiobook(player)
    }

    private func refreshFromAudiobook(_ player: AudiobookPlayer) {
        guard source == .audiobook, audiobook === player else { return }
        guard player.bookId != nil else { clearAudiobook(); return }
        // `currentTime` ticks every second; only publish fields that actually changed
        // so the mini-player doesn't re-render needlessly.
        if audiobookBookId != player.bookId { audiobookBookId = player.bookId }
        if coverImage !== player.coverImage { coverImage = player.coverImage }
        if coverTitle != player.bookTitle { coverTitle = player.bookTitle }
        let newTitle = player.currentChapterTitle.isEmpty ? player.bookTitle : player.currentChapterTitle
        if title != newTitle { title = newTitle }
        let newState: TTSPlaybackState = player.isPlaying ? .playing : .paused
        if playbackState != newState { playbackState = newState }
        if !showsGlobalBar { showsGlobalBar = true }
    }

    private func clearAudiobook() {
        audiobookCancellable = nil
        audiobook = nil
        audiobookBookId = nil
        coverImage = nil
        coverTitle = ""
        if source == .audiobook { source = .none }
        showsGlobalBar = false
        if case .audiobookPlayer = appRootDestination { appRootDestination = nil }
        resetPlaybackFields()
    }

    private func resetPlaybackFields() {
        title = ""
        coverImage = nil
        coverTitle = ""
        playbackState = .stopped
        currentSegmentIndex = 0
        totalSegments = 0
    }

    // MARK: - Unified controls (routed by source)

    func togglePlayback() {
        switch source {
        case .tts: coordinator?.toggle()
        case .audiobook: audiobook?.togglePlayPause()
        case .none: break
        }
    }

    func skipBackward() {
        switch source {
        case .tts: coordinator?.skipBackward()
        case .audiobook: audiobook?.skipBackward()
        case .none: break
        }
    }

    func skipForward() {
        switch source {
        case .tts: coordinator?.skipForward()
        case .audiobook: audiobook?.skipForward()
        case .none: break
        }
    }

    func stop() {
        switch source {
        case .tts: coordinator?.stop(reason: "floating player stop")
        case .audiobook: audiobook?.stop()  // clears bookId → refresh detaches the bar
        case .none: break
        }
    }

#if DEBUG
    func configurePreview(
        title: String,
        playbackState: TTSPlaybackState,
        currentSegmentIndex: Int,
        totalSegments: Int,
        holdsNarrationPastReader: Bool = false
    ) {
        source = .tts
        self.title = title
        self.playbackState = playbackState
        self.currentSegmentIndex = currentSegmentIndex
        self.totalSegments = totalSegments
        isVisible = playbackState != .stopped
        self.holdsNarrationPastReader = holdsNarrationPastReader
    }
#endif
}

// MARK: - TTS Coordinator
//
// Unified external interface: ReaderView and TTSPanelView depend only on TTSCoordinator.
// The underlying layer uses only the HTTP TTS audio player.
// Manages: sleep timer, MPNowPlayingInfo, AVAudioSession.
//
// Main-actor isolated: every entry is on main. Views and `NowPlayingHub` call it from main;
// both engines deliver their callbacks on main (download completions, the chunk player's
// delegate and the AVSpeechSynthesizer delegate all hop there first); the audio-session
// notifications are received on main. Lock-screen commands are the one entry iOS does not
// promise — `performRemoteCommand` hops those explicitly.
@MainActor
final class TTSCoordinator: ObservableObject {

    // MARK: - Published State (bound to TTSPanelView)
    /// Also a Crashlytics key: the field's "no instrumented span" stalls repeat every few
    /// seconds with the reader open, into the background, and nothing said whether a
    /// narration was playing (MainThreadStall, 3.0.0 (140)).
    @Published var isPlaying = false {
        didSet { CrashContext.setKey("tts_playing", isPlaying) }
    }
    @Published private(set) var playbackState: TTSPlaybackState = .stopped
    @Published private(set) var currentSegmentIndex = 0
    @Published private(set) var totalSegments = 0
    @Published private(set) var currentSegmentText = ""
    /// Where the spoken segment sits in the narration unit the engine was handed.
    /// The reader turns this into a chapter position; nothing here knows how the unit
    /// was sliced out of the chapter.
    @Published private(set) var currentSegmentNarrationRange: NSRange?
    /// A queued segment is published before its audio arrives. Preview loading UI must
    /// follow the player's real start callback, not the text/highlight callback.
    @Published private(set) var hasAudiblePlaybackStarted = false
    @Published private(set) var errorMessage: String?
    @Published var speechRate: Float = 0.5
    @Published var sleepMinutes: Int = 0
    var showsGlobalFloatingPlayer = false

    // MARK: - Where the narration is (set by ReaderView)
    //
    // Kept on the narrator, not in the reader that started it: narration outlives that reader,
    // and a reader opened on the same book takes the narrator over
    // (`NowPlayingHub.narrationToTakeOver(forBook:)`), so it has to find these on the narrator.

    /// The book being read aloud.
    var narrationBookID: UUID?
    /// Chapter being narrated.
    @Published var narrationChapterIndex: Int?
    /// Maps the narration handed to the engine back to `narrationChapterIndex`'s laid-out text.
    @Published var narrationOffsets: TTSNarrationOffsetMap?
    /// Chapter the narration is blocked on at a chapter boundary, while the engine holds the
    /// audio session open.
    @Published var pendingNarrationChapterIndex: Int?

    // MARK: - Callbacks (set by ReaderView)
    /// Asked for the next chapter when the current one finishes. Returning `.waiting` keeps
    /// the session alive until `supplyPendingNarration` delivers the text.
    var onNextNarrationUnit: (() -> TTSNextUnitOutcome)? {
        didSet { rewireCallbacks() }
    }
    var onStop: (() -> Void)? {
        didSet { rewireCallbacks() }
    }
    var onWillResume: (() -> Void)?
    var onNextTrackRequested: (() -> Bool)?
    var onPreviousTrackRequested: (() -> Bool)?

    /// Drops every callback the reader installed. Each captures the reader view, which holds
    /// this coordinator: left in place they keep both alive after the reader is gone.
    func clearReaderCallbacks() {
        onNextNarrationUnit = nil
        onStop = nil
        onWillResume = nil
        onNextTrackRequested = nil
        onPreviousTrackRequested = nil
    }
    // MARK: - Engine
    private let httpEngine = HTTPTTSEngine()
    private let systemEngine = SystemTTSEngine()
    /// Engine bound for the current playback session; resolved at `speak` time so toggling the
    /// system-voice setting never redirects pause/stop to the wrong engine mid-session.
    private lazy var activeEngine: TTSPlayable = httpEngine
    private var currentEngine: TTSPlayable { activeEngine }

    /// 多角色朗讀 cast for the open book, set by the reader (which is the only thing
    /// that knows which book it is). Pushed onto both engines rather than the active
    /// one, so a mid-session engine switch cannot leave the cast behind.
    var roleVoices: [String: String] = [:] {
        didSet {
            guard roleVoices != oldValue else { return }
            httpEngine.roleVoices = roleVoices
            systemEngine.roleVoices = roleVoices
        }
    }

    /// alias → canonical character name, from the book's AI character cards. Pushed to both
    /// engines for the same reason as the cast above.
    var roleAliases: [String: String] = [:] {
        didSet {
            guard roleAliases != oldValue else { return }
            httpEngine.roleAliases = roleAliases
            systemEngine.roleAliases = roleAliases
        }
    }
    private static weak var activeSystemMediaCoordinator: TTSCoordinator?

    /// Use the HTTP audio player for direct chapter audio and configured HTTP TTS sources.
    /// Fall back to the on-device voice only for plain text without a network TTS template.
    private func resolveEngine(for text: String) -> TTSPlayable {
        let template = GlobalSettings.shared.httpTtsUrlTemplate.trimmingCharacters(in: .whitespacesAndNewlines)
        return TTSPlaybackRouting.shouldUseHTTP(
            text: text,
            httpTemplate: template,
            useSystemVoice: GlobalSettings.shared.ttsUseSystemVoice
        ) ? httpEngine : systemEngine
    }

    private var sleepTimer: Timer?
    private var audioSessionActive = false
    private var nowPlayingBookTitle = ""
    private var nowPlayingAuthor = ""
    private var nowPlayingChapterTitle = ""
    private var nowPlayingArtwork: MPMediaItemArtwork?
    /// Raw cover image (book cover, or generated title-card for cover-less books) kept so
    /// the floating mini-player can spin it like a record. Mirrors `nowPlayingArtwork`.
    private(set) var floatingCoverImage: UIImage?
    private var nowPlayingElapsed: TimeInterval = 0
    private var nowPlayingDuration: TimeInterval = 1
    private var nowPlayingStartedAt: Date?
    private var audioInterruptionCancellable: AnyCancellable?
    private var routeChangeCancellable: AnyCancellable?
    private var mediaServicesResetCancellable: AnyCancellable?
    private var shouldResumeAfterInterruption = false
    private var isStoppingFromCoordinator = false

    var floatingTitle: String {
        displayNowPlayingTitle
    }

    /// Book title, used to render the title-card placeholder disc when there's no cover.
    var floatingCoverTitle: String {
        nowPlayingBookTitle
    }

    private static let speechRateDefaultsKey = "yd_tts_speech_rate"
    /// UI speech-rate scale: `0.5` is 100%, so the bounds read as 20%–500%. Legado's
    /// `speakSpeed` (`滑桿 + 5`, 10 == 1.0×) is derived from this in
    /// `CustomHTTPProvider.legadoSpeakSpeed`, whose 0…50 range already covers 5×.
    static let minSpeechRate: Float = 0.1
    static let maxSpeechRate: Float = 2.5

    /// The rate playback last used. Read by 系統語音音色's 試聽 so a preview sounds
    /// like real narration without starting a coordinator (which would route to
    /// whichever TTS source is active, not to the system voice being auditioned).
    static var persistedSpeechRate: Float {
        guard UserDefaults.standard.object(forKey: speechRateDefaultsKey) != nil else { return 0.5 }
        let stored = UserDefaults.standard.float(forKey: speechRateDefaultsKey)
        return max(minSpeechRate, min(stored, maxSpeechRate))
    }

    init() {
        if UserDefaults.standard.object(forKey: Self.speechRateDefaultsKey) != nil {
            let stored = UserDefaults.standard.float(forKey: Self.speechRateDefaultsKey)
            speechRate = max(Self.minSpeechRate, min(stored, Self.maxSpeechRate))
        }
        rewireCallbacks()
        setupAudioSessionNotifications()
        ttsLog("[TTS][Coordinator] init")
    }

    // MARK: - External Controls

    func speak(
        text: String,
        title: String = "",
        bookTitle: String = "",
        author: String = "",
        artwork: UIImage? = nil,
        pronunciationHints: [TTSPronunciationHint] = []
    ) {
        guard !text.isEmpty else {
            ttsLog("[TTS][Coordinator] speak ignored empty text")
            return
        }
        errorMessage = nil
        activeEngine = resolveEngine(for: text)
        ttsLog("[TTS][Coordinator] speak requested engine=\(currentEngine === systemEngine ? "system" : "http") textCount=\(text.count) title=\(title) rate=\(speechRate)")
        guard activateAudioSession() else {
            ttsLog("[TTS][Coordinator] speak aborted audio session activation failed")
            return
        }
        ttsLog("[TTS][Coordinator] configure engine audio session ownership")
        currentEngine.configureAudioSessionOwnership(true)
        configureNowPlayingMetadata(
            bookTitle: bookTitle,
            author: author,
            chapterTitle: title,
            artwork: artwork
        )
        prepareNowPlayingForText(text)
        currentSegmentIndex = 0
        totalSegments = 0
        currentSegmentText = ""
        currentSegmentNarrationRange = nil
        hasAudiblePlaybackStarted = false
        currentEngine.speak(
            text: text,
            title: title,
            rate: speechRate,
            pronunciationHints: pronunciationHints
        )
        ttsLog("[TTS][Coordinator] engine speak returned enginePlaying=\(currentEngine.isPlaying)")
        guard currentEngine.isPlaying else {
            ttsLog("[TTS][Coordinator] engine not playing after speak; stopping")
            stop()
            return
        }
        isPlaying = true
        playbackState = .playing
        updateScreenAwakePreference()
        updateNowPlaying()
        publishFloatingPlayerState()
        if sleepMinutes > 0 { startSleepTimer() }
    }

    func pause() {
        ttsLog("[TTS][Coordinator] pause requested coordinatorPlaying=\(isPlaying) enginePlaying=\(currentEngine.isPlaying)")
        guard hasActivePlaybackSession else {
            ttsLog("[TTS][Coordinator] pause ignored no active playback session")
            return
        }
        currentEngine.pause()
        freezeNowPlayingElapsed()
        isPlaying = currentEngine.isPlaying
        playbackState = .paused
        updateScreenAwakePreference()
        updateNowPlaying()
        publishFloatingPlayerState()
        ttsLog("[TTS][Coordinator] pause done coordinatorPlaying=\(isPlaying) enginePlaying=\(currentEngine.isPlaying)")
    }

    func resume() {
        ttsLog("[TTS][Coordinator] resume requested coordinatorPlaying=\(isPlaying) enginePlaying=\(currentEngine.isPlaying)")
        guard hasActivePlaybackSession else {
            ttsLog("[TTS][Coordinator] resume ignored no active playback session")
            return
        }
        onWillResume?()
        guard activateAudioSession() else { return }
        currentEngine.configureAudioSessionOwnership(true)
        errorMessage = nil
        currentEngine.resume()
        isPlaying = currentEngine.isPlaying
        playbackState = isPlaying ? .playing : .paused
        updateScreenAwakePreference()
        if nowPlayingStartedAt == nil {
            nowPlayingStartedAt = Date()
        }
        updateNowPlaying()
        publishFloatingPlayerState()
        ttsLog("[TTS][Coordinator] resume done coordinatorPlaying=\(isPlaying) enginePlaying=\(currentEngine.isPlaying)")
    }

    func toggle() {
        playbackState == .playing ? pause() : resume()
    }

    func dismissError() {
        errorMessage = nil
    }

    /// Holds the screen on while this coordinator is the one narrating and the user wants
    /// that; re-run whenever any of the three changes, the preference included.
    func updateScreenAwakePreference() {
        let holdsScreen = Self.activeSystemMediaCoordinator === self
            && isPlaying
            && GlobalSettings.shared.ttsKeepsScreenAwake
        ScreenAwakeController.shared.setHeld(holdsScreen, .narration, by: self)
    }

    func stop(reason: String = "direct") {
        ttsLog("[TTS][Coordinator] stop requested reason=\(reason) coordinatorPlaying=\(isPlaying) enginePlaying=\(currentEngine.isPlaying)")
        // Whether the app asked for the stop at all is the first question any "it just stopped"
        // report has to answer, and the engines' own anomalies cannot answer it. Only log a stop
        // that actually ended something, so pressing 停止 on an idle player stays quiet.
        if isPlaying || currentEngine.isPlaying {
            AppLogger.info(
                "[TTS] 朗讀停止",
                context: ["reason": reason, "engine": currentEngine.isPlaying],
                level: .notice
            )
        }
        isStoppingFromCoordinator = true
        currentEngine.stop()
        isStoppingFromCoordinator = false
        finishStopped(reason: reason)
    }

    func skipForward() {
        ttsLog("[TTS][Coordinator] skipForward requested state=\(playbackState)")
        guard hasActivePlaybackSession else { return }
        if onNextTrackRequested?() == true {
            resetNowPlayingClockForCurrentAudio()
            updateNowPlaying()
            publishFloatingPlayerState()
            return
        }
        currentEngine.skipForward()
        isPlaying = currentEngine.isPlaying
        playbackState = isPlaying ? .playing : .paused
        resetNowPlayingClockForCurrentAudio()
        updateNowPlaying()
        publishFloatingPlayerState()
    }

    func skipBackward() {
        ttsLog("[TTS][Coordinator] skipBackward requested state=\(playbackState)")
        guard hasActivePlaybackSession else { return }
        if onPreviousTrackRequested?() == true {
            resetNowPlayingClockForCurrentAudio()
            updateNowPlaying()
            publishFloatingPlayerState()
            return
        }
        currentEngine.skipBackward()
        isPlaying = currentEngine.isPlaying
        playbackState = isPlaying ? .playing : .paused
        resetNowPlayingClockForCurrentAudio()
        updateNowPlaying()
        publishFloatingPlayerState()
    }

    func seekToProgress(_ progress: Double) {
        ttsLog("[TTS][Coordinator] seekToProgress requested progress=\(progress) totalSegments=\(totalSegments)")
        guard hasActivePlaybackSession, totalSegments > 0 else { return }
        let clamped = min(max(progress, 0), 1)
        let segment = Int(round(clamped * Double(max(totalSegments - 1, 0))))
        currentEngine.seekToSegment(segment)
        isPlaying = currentEngine.isPlaying
        playbackState = isPlaying ? .playing : .paused
        syncNowPlayingElapsed(toSegment: segment, total: totalSegments, restartClock: isPlaying)
        updateNowPlaying()
        publishFloatingPlayerState()
    }

    /// True between the engine reporting `.waiting` and the host supplying the next chapter.
    var isWaitingForNextChapter: Bool { currentEngine.isWaitingForNextUnit }

    /// Chapter line shown on the lock screen / mini-player while the next chapter is being
    /// prepared. Set by the reader so this Core type stays free of the app's string catalog.
    var nextChapterLoadingStatusTitle = ""

    /// Reflect the chapter-boundary wait on every system surface. Playback state stays
    /// `.playing` — the audio session, lock-screen controls and mini-player all keep their
    /// live appearance — while the chapter line reports that loading is in progress.
    private func enterChapterWaitPresentation() {
        ttsLog("[TTS][Coordinator] waiting for next chapter")
        if !nextChapterLoadingStatusTitle.isEmpty {
            nowPlayingChapterTitle = nextChapterLoadingStatusTitle
        }
        // The elapsed clock has nothing to count during the wait; freeze it so the lock
        // screen doesn't run past the (now meaningless) duration of the finished chapter.
        freezeNowPlayingElapsed()
        currentSegmentText = ""
        currentSegmentNarrationRange = nil
        updateNowPlaying()
        publishFloatingPlayerState()
    }

    /// Deliver the chapter the engine has been waiting for and resume narration.
    func supplyPendingNarration(_ unit: TTSNarrationUnit, chapterTitle: String) {
        guard currentEngine.isWaitingForNextUnit else {
            ttsLog("[TTS][Coordinator] supplyPendingNarration ignored engine not waiting")
            return
        }
        ttsLog("[TTS][Coordinator] supplying pending chapter title=\(chapterTitle) textCount=\(unit.text.count)")
        nowPlayingChapterTitle = chapterTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        prepareNowPlayingForText(unit.text)
        currentSegmentIndex = 0
        totalSegments = 0
        currentSegmentText = ""
        currentSegmentNarrationRange = nil
        currentEngine.supplyPendingUnit(unit)
        isPlaying = currentEngine.isPlaying
        playbackState = isPlaying ? .playing : .paused
        updateNowPlaying()
        publishFloatingPlayerState()
    }

    /// Give up on a wait that cannot succeed (the fetch failed outright).
    ///
    /// Deliberately goes through the engine's own stop path rather than `stop(reason:)`: that
    /// one sets `isStoppingFromCoordinator`, which suppresses the `onStop` hand-off and would
    /// leave the reader's TTS bookkeeping (`ttsChapterIndex`, the playback anchor) stale. This
    /// route ends the session exactly like a natural end-of-book.
    func abortWaitingForNextChapter(reason: String) {
        guard currentEngine.isWaitingForNextUnit else { return }
        ttsLog("[TTS][Coordinator] aborting chapter wait reason=\(reason)")
        currentEngine.stop()
    }

    func updateNowPlayingTitle(_ title: String) {
        updateNowPlayingChapter(title: title)
    }

    func updateNowPlayingChapter(title: String, text: String? = nil) {
        nowPlayingChapterTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if nowPlayingBookTitle.isEmpty {
            nowPlayingBookTitle = nowPlayingChapterTitle
        }
        if let text {
            prepareNowPlayingForText(text)
            currentSegmentIndex = 0
            totalSegments = 0
            currentSegmentText = ""
            currentSegmentNarrationRange = nil
        }
        updateNowPlaying()
        publishFloatingPlayerState()
    }

    private func finishStopped(reason: String) {
        hasAudiblePlaybackStarted = false
        let ownsSystemMedia = Self.activeSystemMediaCoordinator === self
        isPlaying = false
        playbackState = .stopped
        // Only this coordinator's own hold: 自動閱讀 or an open reader may still want the
        // screen on.
        ScreenAwakeController.shared.setHeld(false, .narration, by: self)
        cancelSleepTimer()
        if ownsSystemMedia {
            MPNowPlayingInfoCenter.default().playbackState = .stopped
            MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        } else {
            ttsLog("[TTS][Coordinator] stop skipped clearing system media because coordinator is not active owner")
        }
        nowPlayingBookTitle = ""
        nowPlayingAuthor = ""
        nowPlayingChapterTitle = ""
        nowPlayingArtwork = nil
        floatingCoverImage = nil
        nowPlayingElapsed = 0
        nowPlayingDuration = 1
        nowPlayingStartedAt = nil
        currentSegmentIndex = 0
        totalSegments = 0
        currentSegmentText = ""
        currentSegmentNarrationRange = nil
        // Weak, because `deinit` stops too and must not hand `self` to a task. By the time the
        // task runs this coordinator may be gone — a narration held past its reader is let go
        // on `.stopped`, or this was `deinit` — and the hub still has to drop it.
        Task { @MainActor [weak self] in
            if let self {
                NowPlayingHub.shared.detach(self)
            } else {
                NowPlayingHub.shared.detachDeallocatedCoordinator()
            }
        }
        if ownsSystemMedia {
            setRemoteCommandsEnabled(false)
            deactivateAudioSession()
            if Self.activeSystemMediaCoordinator === self {
                Self.activeSystemMediaCoordinator = nil
            }
        }
        ttsLog("[TTS][Coordinator] stop done reason=\(reason)")
    }

    func refreshNowPlayingForSystemSurfaces() {
        ttsLog("[TTS][Coordinator] refreshNowPlayingForSystemSurfaces audioSessionActive=\(audioSessionActive) coordinatorPlaying=\(isPlaying)")
        guard audioSessionActive else { return }
        setupRemoteCommands()
        updateNowPlaying()
    }

    func updateRate(_ rate: Float) {
        speechRate = max(Self.minSpeechRate, min(rate, Self.maxSpeechRate))
        UserDefaults.standard.set(speechRate, forKey: Self.speechRateDefaultsKey)
    }

    /// Push the current rate into any in-flight playback. Kept separate from `updateRate`
    /// so the slider can call it once on gesture end — re-synthesizing HTTP TTS audio on
    /// every mid-drag tick would hammer rate-limited sources.
    func applyRateToActivePlayback() {
        httpEngine.updateRate(speechRate)
        systemEngine.updateRate(speechRate)
    }

    func setSleepTimer(minutes: Int) {
        sleepMinutes = minutes
        if isPlaying && minutes > 0 { startSleepTimer() } else { cancelSleepTimer() }
    }

    private func rewireCallbacks() {
        wireCallbacks(to: httpEngine)
        wireCallbacks(to: systemEngine)
    }

    private func wireCallbacks(to engine: TTSPlayable) {
        engine.onPageFinished = { [weak self] in
            guard let self, self.isPlaying else { return .finished }
            let outcome = SourcePerfTrace.span("tts.nextUnit", thresholdMs: 5) {
                self.onNextNarrationUnit?() ?? .finished
            }
            if case .waiting = outcome {
                // Runs before the engine flips its own waiting flag, so this must not test
                // `isWaitingForNextUnit` — the outcome we just received IS the signal.
                self.enterChapterWaitPresentation()
            }
            return outcome
        }
        engine.onStop = { [weak self] in
            guard let self else { return }
            guard !self.isStoppingFromCoordinator else { return }
            self.finishStopped(reason: "engine finished")
            self.onStop?()
        }
        engine.onError = { [weak self] error in
            guard let self else { return }
            if case .chunkUnavailable = error as? TTSPlaybackError {
                // The engine retains the failed segment for resume. Keep the panel
                // and lock-screen controls in sync with that paused session.
                self.pause()
            }
            self.errorMessage = String(format: localized("朗讀失敗：%@"), error.localizedDescription)
        }
        engine.onPlaybackStarted = { [weak self] duration in
            DispatchQueue.main.async {
                SourcePerfTrace.span("tts.playbackStarted", thresholdMs: 5) {
                    self?.handleEnginePlaybackStarted(duration: duration)
                }
            }
        }
        // Every spoken segment lands here on the main thread, a few seconds apart and on
        // into the background: timed, so a stall during one names it.
        engine.onSegmentChanged = { [weak self] segment in
            DispatchQueue.main.async {
                guard let self else { return }
                SourcePerfTrace.span("tts.segment", "index=\(segment.index)/\(segment.total)", thresholdMs: 5) {
                    self.currentSegmentIndex = segment.index
                    self.totalSegments = segment.total
                    self.currentSegmentText = segment.text
                    self.currentSegmentNarrationRange = segment.narrationRange
                    self.syncNowPlayingElapsedToCurrentSegment(restartClock: self.isPlaying)
                    self.updateNowPlaying()
                    self.publishFloatingPlayerState()
                }
            }
        }
    }

    private func publishFloatingPlayerState() {
        guard showsGlobalFloatingPlayer else { return }
        Task { @MainActor [weak self] in
            guard let self else { return }
            if self.playbackState == .stopped {
                NowPlayingHub.shared.detach(self)
            } else {
                NowPlayingHub.shared.attach(self)
            }
        }
    }

    // MARK: - Audio Session

    @discardableResult
    private func activateAudioSession() -> Bool {
        guard !audioSessionActive else {
            ttsLog("[TTS][Coordinator] audio session already active")
            claimSystemMediaSession()
            setupRemoteCommands()
            setRemoteCommandsEnabled(true)
            return true
        }
        ttsLog("[TTS][Coordinator] activating audio session")
        claimSystemMediaSession()
        setupRemoteCommands()
        setRemoteCommandsEnabled(true)
        let s = AVAudioSession.sharedInstance()
        do {
            try s.setCategory(
                .playback,
                mode: .spokenAudio,
                policy: .longFormAudio,
                options: []
            )
            try s.setActive(true)
            audioSessionActive = true
            UIApplication.shared.beginReceivingRemoteControlEvents()
            ttsLog("[TTS][Coordinator] audio session active category=\(s.category.rawValue) mode=\(s.mode.rawValue) secondarySilenced=\(s.secondaryAudioShouldBeSilencedHint)")
            return true
        } catch {
            audioSessionActive = false
            errorMessage = String(format: localized("朗讀失敗：%@"), error.localizedDescription)
            ttsLog("[TTS] Failed to activate audio session: \(error.localizedDescription)")
            return false
        }
    }

    private func deactivateAudioSession() {
        guard audioSessionActive else {
            ttsLog("[TTS][Coordinator] deactivate skipped audio session inactive")
            return
        }
        ttsLog("[TTS][Coordinator] deactivating audio session")
        UIApplication.shared.endReceivingRemoteControlEvents()
        try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        audioSessionActive = false
    }

    private func claimSystemMediaSession() {
        if let activeCoordinator = Self.activeSystemMediaCoordinator,
           activeCoordinator !== self {
            ttsLog("[TTS][Coordinator] replacing active system media coordinator old=\(ObjectIdentifier(activeCoordinator)) new=\(ObjectIdentifier(self))")
            activeCoordinator.stop(reason: "replaced by another TTS coordinator")
        }
        Self.activeSystemMediaCoordinator = self
    }

    // MARK: - Lock Screen Controls

    private func setupRemoteCommands() {
        ttsLog("[TTS][Coordinator] configuring remote commands owner=\(ObjectIdentifier(self))")

        let c = MPRemoteCommandCenter.shared()
        c.playCommand.isEnabled  = true
        c.pauseCommand.isEnabled = true
        c.togglePlayPauseCommand.isEnabled = true
        c.stopCommand.isEnabled  = false
        c.nextTrackCommand.isEnabled = true
        c.previousTrackCommand.isEnabled = true
        c.changePlaybackPositionCommand.isEnabled = true

        c.playCommand.removeTarget(nil)
        c.pauseCommand.removeTarget(nil)
        c.togglePlayPauseCommand.removeTarget(nil)
        c.stopCommand.removeTarget(nil)
        c.nextTrackCommand.removeTarget(nil)
        c.previousTrackCommand.removeTarget(nil)
        c.changePlaybackPositionCommand.removeTarget(nil)

        c.playCommand.addTarget { @Sendable [weak self] _ in
            ttsLog("[TTS][Remote] playCommand")
            return self?.performRemoteCommand(requiresActiveSession: true) { $0.resume() } ?? .commandFailed
        }
        c.pauseCommand.addTarget { @Sendable [weak self] _ in
            ttsLog("[TTS][Remote] pauseCommand")
            return self?.performRemoteCommand(requiresActiveSession: true) { $0.pause() } ?? .commandFailed
        }
        c.togglePlayPauseCommand.addTarget { @Sendable [weak self] _ in
            ttsLog("[TTS][Remote] togglePlayPauseCommand")
            return self?.performRemoteCommand(requiresActiveSession: true) { $0.toggle() } ?? .commandFailed
        }
        c.nextTrackCommand.addTarget { @Sendable [weak self] _ in
            ttsLog("[TTS][Remote] nextTrackCommand")
            return self?.performRemoteCommand(requiresActiveSession: true) { $0.skipForward() } ?? .commandFailed
        }
        c.previousTrackCommand.addTarget { @Sendable [weak self] _ in
            ttsLog("[TTS][Remote] previousTrackCommand")
            return self?.performRemoteCommand(requiresActiveSession: true) { $0.skipBackward() } ?? .commandFailed
        }
        c.changePlaybackPositionCommand.addTarget { @Sendable [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent else {
                return .commandFailed
            }
            let positionTime = event.positionTime
            ttsLog("[TTS][Remote] changePlaybackPositionCommand position=\(positionTime)")
            return self?.performRemoteCommand(requiresActiveSession: true) {
                $0.seekToNowPlayingPosition(positionTime)
            } ?? .commandFailed
        }
    }

    private func setupAudioSessionNotifications() {
        let center = NotificationCenter.default
        let session = AVAudioSession.sharedInstance()

        audioInterruptionCancellable = center.publisher(
            for: AVAudioSession.interruptionNotification,
            object: session
        )
        .receive(on: DispatchQueue.main)
        .sink { [weak self] notification in
            self?.handleAudioInterruption(notification)
        }

        routeChangeCancellable = center.publisher(
            for: AVAudioSession.routeChangeNotification,
            object: session
        )
        .receive(on: DispatchQueue.main)
        .sink { [weak self] notification in
            self?.handleRouteChange(notification)
        }

        mediaServicesResetCancellable = center.publisher(
            for: AVAudioSession.mediaServicesWereResetNotification,
            object: session
        )
        .receive(on: DispatchQueue.main)
        .sink { [weak self] _ in
            self?.handleMediaServicesReset()
        }
    }

    private func handleAudioInterruption(_ notification: Notification) {
        guard let typeValue = notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: typeValue) else {
            return
        }

        switch type {
        case .began:
            shouldResumeAfterInterruption = isPlaying
            ttsLog("[TTS][Coordinator] audio interruption began shouldResume=\(shouldResumeAfterInterruption)")
            // A call, Siri, or another app taking the session. This is the innocent explanation
            // for "it went quiet", and its absence rules the explanation out.
            if isPlaying {
                AppLogger.info("[TTS] 音訊被其他 App 中斷", level: .notice)
            }
            if isPlaying {
                pause()
            }
        case .ended:
            let optionsValue = notification.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            let options = AVAudioSession.InterruptionOptions(rawValue: optionsValue)
            ttsLog("[TTS][Coordinator] audio interruption ended shouldResume=\(shouldResumeAfterInterruption) options=\(options.rawValue)")
            guard shouldResumeAfterInterruption else { return }
            shouldResumeAfterInterruption = false
            guard options.contains(.shouldResume) else {
                // iOS says the interruption is over but declines to hand playback back. Nothing
                // resumes and nothing is wrong — except that it looks exactly like a crash.
                AppLogger.info("[TTS] 中斷結束但系統不允許自動續播", level: .notice)
                return
            }
            guard activateAudioSession() else {
                AppLogger.error("[TTS] 中斷結束後無法重新啟用音訊工作階段", level: .warning)
                return
            }
            resume()
        @unknown default:
            ttsLog("[TTS][Coordinator] audio interruption unknown type=\(type.rawValue)")
        }
    }

    private func handleRouteChange(_ notification: Notification) {
        guard let reasonValue = notification.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
              let reason = AVAudioSession.RouteChangeReason(rawValue: reasonValue) else {
            return
        }

        ttsLog("[TTS][Coordinator] audio route changed reason=\(reason.rawValue)")
        if reason == .oldDeviceUnavailable, isPlaying {
            pause()
        }
    }

    /// Media services can be restarted by iOS while the app is locked, after an audio route
    /// fault, or after a system audio daemon crash. Re-activate the shared session first, then
    /// let the selected engine restore its current source position from memory.
    private func handleMediaServicesReset() {
        guard Self.activeSystemMediaCoordinator === self, hasActivePlaybackSession else {
            return
        }
        ttsLog("[TTS][Coordinator] media services reset; rebuilding audio session")
        audioSessionActive = false
        guard activateAudioSession() else { return }
        currentEngine.configureAudioSessionOwnership(true)
        currentEngine.recoverAfterAudioSessionReset()
        isPlaying = currentEngine.isPlaying
        playbackState = isPlaying ? .playing : .paused
        updateScreenAwakePreference()
        updateNowPlaying()
        publishFloatingPlayerState()
    }

    private func setRemoteCommandsEnabled(_ enabled: Bool) {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.isEnabled = enabled
        c.pauseCommand.isEnabled = enabled
        c.togglePlayPauseCommand.isEnabled = enabled
        c.stopCommand.isEnabled = false
        c.nextTrackCommand.isEnabled = enabled
        c.previousTrackCommand.isEnabled = enabled
        c.changePlaybackPositionCommand.isEnabled = enabled
        ttsLog("[TTS][Coordinator] remote commands enabled=\(enabled)")
    }

    private var hasActivePlaybackSession: Bool {
        audioSessionActive || isPlaying || nowPlayingStartedAt != nil
    }

    /// MPRemoteCommandCenter does not say which thread runs a command handler, so the handlers
    /// are nonisolated and come to main here, synchronously, because the handler has to return
    /// the command's status. The session check happens on main too, with the state it reads.
    nonisolated private func performRemoteCommand(
        requiresActiveSession: Bool = false,
        _ action: @escaping @MainActor @Sendable (TTSCoordinator) -> Void
    ) -> MPRemoteCommandHandlerStatus {
        let perform: @MainActor () -> MPRemoteCommandHandlerStatus = {
            if requiresActiveSession && !self.hasActivePlaybackSession {
                ttsLog("[TTS][Remote] ignored no active playback session")
                return .noActionableNowPlayingItem
            }
            action(self)
            return .success
        }
        if Thread.isMainThread {
            return MainActor.assumeIsolated(perform)
        }
        return DispatchQueue.main.sync {
            MainActor.assumeIsolated(perform)
        }
    }

    private func seekToNowPlayingPosition(_ positionTime: TimeInterval) {
        let duration = max(nowPlayingDuration, 1)
        seekToProgress(positionTime / duration)
    }

    private var displayNowPlayingTitle: String {
        if !nowPlayingBookTitle.isEmpty { return nowPlayingBookTitle }
        if !nowPlayingChapterTitle.isEmpty { return nowPlayingChapterTitle }
        return "Reading Aloud"
    }

    private var displayNowPlayingArtist: String {
        nowPlayingAuthor.isEmpty ? "TTS Narration" : nowPlayingAuthor
    }

    private func configureNowPlayingMetadata(
        bookTitle: String,
        author: String,
        chapterTitle: String,
        artwork: UIImage?
    ) {
        let trimmedBookTitle = bookTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedChapterTitle = chapterTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        nowPlayingBookTitle = trimmedBookTitle.isEmpty ? trimmedChapterTitle : trimmedBookTitle
        nowPlayingAuthor = author.trimmingCharacters(in: .whitespacesAndNewlines)
        nowPlayingChapterTitle = trimmedChapterTitle
        nowPlayingArtwork = Self.makeNowPlayingArtwork(from: artwork)
        floatingCoverImage = artwork
    }

    private func prepareNowPlayingForText(_ text: String) {
        nowPlayingElapsed = 0
        nowPlayingDuration = estimatedDuration(for: text)
        nowPlayingStartedAt = nil
    }

    private func syncNowPlayingElapsedToCurrentSegment(restartClock: Bool) {
        syncNowPlayingElapsed(toSegment: currentSegmentIndex, total: totalSegments, restartClock: restartClock)
    }

    private func syncNowPlayingElapsed(toSegment index: Int, total: Int, restartClock: Bool) {
        guard total > 0 else {
            nowPlayingStartedAt = restartClock ? Date() : nil
            return
        }
        let clampedIndex = min(max(index, 0), max(total - 1, 0))
        let progress = Double(clampedIndex) / Double(max(total, 1))
        nowPlayingElapsed = min(max(nowPlayingDuration * progress, 0), max(nowPlayingDuration, 1))
        nowPlayingStartedAt = restartClock ? Date() : nil
    }

    private static func makeNowPlayingArtwork(from image: UIImage?) -> MPMediaItemArtwork? {
        guard let image else { return nil }
        // MediaPlayer asks for the image on its own queue: a main-actor closure would trap there
        // under Swift 6.
        return MPMediaItemArtwork(boundsSize: image.size) { @Sendable _ in image }
    }

    private func updateNowPlaying() {
        guard Self.activeSystemMediaCoordinator === self else {
            ttsLog("[TTS][NowPlaying] update skipped because coordinator is not active owner")
            return
        }
        var info = [String: Any]()
        info[MPMediaItemPropertyTitle] = displayNowPlayingTitle
        info[MPMediaItemPropertyArtist] = displayNowPlayingArtist
        if !nowPlayingChapterTitle.isEmpty {
            info[MPMediaItemPropertyAlbumTitle] = nowPlayingChapterTitle
        }
        if let nowPlayingArtwork {
            info[MPMediaItemPropertyArtwork] = nowPlayingArtwork
        }
        info[MPNowPlayingInfoPropertyMediaType] = MPNowPlayingInfoMediaType.audio.rawValue
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = currentNowPlayingElapsed()
        info[MPMediaItemPropertyPlaybackDuration] = max(nowPlayingDuration, 1)
        info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1.0 : 0.0
        info[MPNowPlayingInfoPropertyDefaultPlaybackRate] = 1.0
        // Carries the artwork to the system on every segment; timed apart from the segment
        // around it.
        SourcePerfTrace.span("tts.nowPlaying", thresholdMs: 5) {
            MPNowPlayingInfoCenter.default().nowPlayingInfo = info
            MPNowPlayingInfoCenter.default().playbackState = isPlaying ? .playing : .paused
        }
        ttsLog("[TTS][NowPlaying] update title=\(displayNowPlayingTitle) artist=\(displayNowPlayingArtist) chapter=\(nowPlayingChapterTitle) elapsed=\(info[MPNowPlayingInfoPropertyElapsedPlaybackTime] ?? "?") duration=\(info[MPMediaItemPropertyPlaybackDuration] ?? "?") rate=\(info[MPNowPlayingInfoPropertyPlaybackRate] ?? "?") state=\(isPlaying ? "playing" : "paused")")
    }

    private func handleEnginePlaybackStarted(duration _: TimeInterval) {
        guard Self.activeSystemMediaCoordinator === self else {
            ttsLog("[TTS][NowPlaying] playback started ignored because coordinator is not active owner")
            return
        }
        hasAudiblePlaybackStarted = true
        nowPlayingStartedAt = isPlaying ? Date() : nil
        updateNowPlaying()
        publishFloatingPlayerState()
    }

    private func resetNowPlayingClockForCurrentAudio() {
        syncNowPlayingElapsedToCurrentSegment(restartClock: isPlaying)
    }

    private func currentNowPlayingElapsed() -> TimeInterval {
        guard isPlaying, let startedAt = nowPlayingStartedAt else {
            return nowPlayingElapsed
        }
        return min(max(nowPlayingElapsed + Date().timeIntervalSince(startedAt), 0), max(nowPlayingDuration, 1))
    }

    private func freezeNowPlayingElapsed() {
        nowPlayingElapsed = currentNowPlayingElapsed()
        nowPlayingStartedAt = nil
    }

    private func estimatedDuration(for text: String) -> TimeInterval {
        let characterCount = max(text.count, 1)
        let baseCharactersPerSecond: Double = 5.5
        let rateFactor = max(Double(speechRate) / 0.5, 0.5)
        return max(Double(characterCount) / (baseCharactersPerSecond * rateFactor), 1)
    }

    // MARK: - Sleep Timer

    private func startSleepTimer() {
        cancelSleepTimer()
        guard sleepMinutes > 0 else { return }
        sleepTimer = Timer.scheduledTimer(
            withTimeInterval: TimeInterval(sleepMinutes * 60),
            repeats: false
        ) { [weak self] _ in DispatchQueue.main.async { [weak self] in self?.stop(reason: "sleep timer") } }
    }

    private func cancelSleepTimer() {
        sleepTimer?.invalidate()
        sleepTimer = nil
    }

    /// Stopping touches UIKit and the now-playing center, so it runs on main. Every owner
    /// releases its last reference there anyway (`@StateObject` in `ReaderView` and
    /// `TTSSettingsView`, `NowPlayingHub` holds it weakly), so this runs inline; a release
    /// anywhere else is moved to main rather than racing. Swift 6.4 back-deploys this for
    /// the main actor (`swift_task_deinitOnExecutorMainActorBackDeploy`), so iOS 17 has it.
    isolated deinit { stop(reason: "coordinator deinit") }
}
