import Foundation
import os

/// Persistent, domain-keyed cookie store for Legado book source JS bridge.
///
/// Cookies set by `cookie.set(url, value)` are written to both
/// `HTTPCookieStorage` (for native HTTP requests) and a JSON file on disk
/// (so they survive app restarts).  On first access the persisted cookies
/// are replayed into `HTTPCookieStorage`.
///
/// Usage:
/// ```swift
/// let value = CookieStore.shared.get(url: "https://example.com")
/// CookieStore.shared.set(url: "https://example.com", cookie: "session=abc")
/// CookieStore.shared.remove(url: "https://example.com")
/// ```
final class CookieStore: Sendable {

    static let shared = CookieStore()

    // MARK: - Storage

    /// Domain → raw cookie string (persistent snapshot).
    private let store: OSAllocatedUnfairLock<[String: String]>
    private let fileURL: URL

    // MARK: - Init

    private init() {
        let dir = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask).first!
        fileURL = dir.appendingPathComponent("legado_cookies.json")
        store = OSAllocatedUnfairLock(initialState: Self.load(from: fileURL))
        replayIntoHTTPCookieStorage()
    }

    // MARK: - Public API

    /// Returns a `name=value; name2=value2` cookie string for the given URL.
    /// Queries `HTTPCookieStorage` first (picks up cookies set by HTTP responses),
    /// then falls back to the persistent store if the session storage is empty.
    func get(url: String) -> String {
        // HTTPCookieStorage (session / system managed)
        if let cookieURL = URL(string: url), let rawHost = cookieURL.host {
            let host = rawHost.lowercased()
            var collected: [String: String] = [:]
            // 1) Standard match for this exact URL (host-only + parent-domain cookies).
            for c in HTTPCookieStorage.shared.cookies(for: cookieURL) ?? [] {
                collected[c.name] = c.value
            }
            // 2) Also include cookies set on a SIBLING subdomain of the same site. Legado sources
            //    routinely read a token via one host while the site set it on another subdomain —
            //    e.g. 起点 reads `cookie.getKey("https://qidian.com","_csrfToken")` but the cookie is
            //    a host-only `m.qidian.com` one. Standard `cookies(for:)` won't return that across
            //    siblings, so `getKey("qidian.com")` came back empty → discover URL param unresolved
            //    → 起点 rejected the request. Match on a label boundary so `a.com` ≠ `evil-a.com`.
            for c in HTTPCookieStorage.shared.cookies ?? [] where collected[c.name] == nil {
                let d = (c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain)
                    .lowercased()
                if d == host || d.hasSuffix("." + host) || host.hasSuffix("." + d) {
                    collected[c.name] = c.value
                }
            }
            if !collected.isEmpty {
                return collected.map { "\($0.key)=\($0.value)" }.joined(separator: "; ")
            }
        }
        // Persistent fallback
        let domain = canonicalDomain(for: url)
        return store.withLock { $0[domain] ?? "" }
    }

    /// Stores `cookie` for the host of `url`.
    /// Writes to both `HTTPCookieStorage` and the persistent file.
    /// Always splits by `;` (Cookie-header style) rather than relying on
    /// `HTTPCookie.cookies(withResponseHeaderFields:)` which treats `;` as
    /// attribute separator (Set-Cookie style) and drops non-standard pairs
    /// such as the `dttoken` in `"key=xxx; dttoken=yyy"`.
    func set(url: String, cookie: String) {
        guard !cookie.isEmpty, let cookieURL = URL(string: url) else { return }

        // Write to HTTPCookieStorage — always use makeCookies which splits by ;
        makeCookies(cookie, for: cookieURL).forEach {
            HTTPCookieStorage.shared.setCookie($0)
        }

        // Persist: merge with existing value for this domain
        let domain = canonicalDomain(for: url)
        store.withLock { $0[domain] = merge(existing: $0[domain], incoming: cookie) }
        save()
    }

    /// Returns the value of a single cookie named `key` for the host of `url`.
    /// Mirrors Legado's `cookie.getKey(tag, key)`. `url` may be a bare domain
    /// (e.g. `"fanqienovel.com"`) or a full URL; a missing scheme is treated as https.
    /// Returns the whole cookie string when `key` is empty, or "" when not found.
    func getKey(url: String, key: String) -> String {
        let cookieStr = get(url: Self.normalizedURLString(url))
        guard !key.isEmpty else { return cookieStr }
        for segment in cookieStr.components(separatedBy: ";") {
            let parts = segment.split(separator: "=", maxSplits: 1).map {
                $0.trimmingCharacters(in: .whitespaces)
            }
            if parts.count == 2, parts[0] == key { return parts[1] }
        }
        return ""
    }

    /// Normalize a cookie "tag" to a URL string: bare domains gain an https scheme
    /// so `URL(string:)` exposes a `host` for `HTTPCookieStorage` lookups.
    static func normalizedURLString(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return trimmed }
        return trimmed.contains("://") ? trimmed : "https://" + trimmed
    }

    /// Removes all cookies for the host of `url`.
    func remove(url: String) {
        if let cookieURL = URL(string: url),
           let cookies = HTTPCookieStorage.shared.cookies(for: cookieURL) {
            cookies.forEach { HTTPCookieStorage.shared.deleteCookie($0) }
        }
        let domain = canonicalDomain(for: url)
        store.withLock { _ = $0.removeValue(forKey: domain) }
        save()
    }

    /// Removes one cookie while preserving every other cookie for the site.
    ///
    /// When `includingRelatedDomains` is true, parent and sibling hosts are included.
    /// This is needed for double-submit CSRF sites: a source may mint a host-only token
    /// on `m.example.com` but another rule reads it through `example.com`. Removing only
    /// the parent-domain copy leaves the stale sibling value available to that lookup.
    func remove(
        url: String,
        key: String,
        includingRelatedDomains: Bool = false
    ) {
        guard !key.isEmpty,
              let cookieURL = URL(string: Self.normalizedURLString(url)),
              let host = cookieURL.host
        else { return }
        let normalizedHost = host.lowercased()

        let domainMatches: @Sendable (String) -> Bool = { rawDomain in
            let domain = (rawDomain.hasPrefix(".")
                ? String(rawDomain.dropFirst())
                : rawDomain).lowercased()
            if includingRelatedDomains {
                return domain == normalizedHost
                    || domain.hasSuffix("." + normalizedHost)
                    || normalizedHost.hasSuffix("." + domain)
            }
            return domain == normalizedHost
        }

        for cookie in HTTPCookieStorage.shared.cookies ?? []
        where cookie.name == key && domainMatches(cookie.domain) {
            HTTPCookieStorage.shared.deleteCookie(cookie)
        }

        store.withLock { store in
            for domain in Array(store.keys) where domainMatches(domain) {
                let remaining = removingCookie(named: key, from: store[domain] ?? "")
                if remaining.isEmpty {
                    store.removeValue(forKey: domain)
                } else {
                    store[domain] = remaining
                }
            }
        }
        save()
    }

    /// Wipes all persisted cookies and clears HTTPCookieStorage.
    func clearAll() {
        HTTPCookieStorage.shared.removeCookies(since: .distantPast)
        store.withLock { $0.removeAll() }
        save()
    }

    // MARK: - Private: Persistence

    private static func load(from fileURL: URL) -> [String: String] {
        guard FileManager.default.fileExists(atPath: fileURL.path),
              let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([String: String].self, from: data) else {
            return [:]
        }
        return decoded
    }

    private func save() {
        let snapshot = store.withLock { $0 }
        guard let data = try? JSONEncoder().encode(snapshot) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }

    /// Replay persisted cookies into HTTPCookieStorage on startup.
    private func replayIntoHTTPCookieStorage() {
        for (domain, cookieStr) in store.withLock({ $0 }) {
            let baseURL = URL(string: "https://\(domain)") ?? URL(string: "https://example.com")!
            makeCookies(cookieStr, for: baseURL).forEach {
                HTTPCookieStorage.shared.setCookie($0)
            }
        }
    }

    // MARK: - Private: Helpers

    private func canonicalDomain(for urlString: String) -> String {
        (URL(string: urlString)?.host ?? urlString).lowercased()
    }

    /// Parse a `name=value; name2=value2` string into HTTPCookie objects.
    /// Skips standard Set-Cookie attribute names (Domain, Path, Expires, etc.)
    /// so they are never treated as cookies.
    private func makeCookies(_ raw: String, for url: URL) -> [HTTPCookie] {
        guard let host = url.host else { return [] }
        let knownAttributes: Set<String> = [
            "domain", "path", "expires", "max-age", "secure", "httponly", "samesite"
        ]
        return raw.components(separatedBy: ";").compactMap { segment in
            let trimmed = segment.trimmingCharacters(in: .whitespaces)
            guard !trimmed.isEmpty else { return nil }
            let parts = trimmed.split(separator: "=", maxSplits: 1).map(String.init)
            guard parts.count == 2, !parts[0].isEmpty else { return nil }
            let name = parts[0].trimmingCharacters(in: .whitespaces)
            guard !knownAttributes.contains(name.lowercased()) else { return nil }
            return HTTPCookie(properties: [
                .name: name,
                .value: parts[1].trimmingCharacters(in: .whitespaces),
                .domain: host,
                .path: "/"
            ])
        }
    }

    /// Merge incoming `name=value` pairs into an existing cookie string.
    /// Incoming values overwrite existing ones with the same name.
    private func merge(existing: String?, incoming: String) -> String {
        var dict: [String: String] = [:]
        // Parse existing
        for segment in (existing ?? "").components(separatedBy: ";") {
            let trimmed = segment.trimmingCharacters(in: .whitespaces)
            let parts = trimmed.split(separator: "=", maxSplits: 1).map(String.init)
            if parts.count == 2, !parts[0].isEmpty {
                dict[parts[0].trimmingCharacters(in: .whitespaces)] =
                    parts[1].trimmingCharacters(in: .whitespaces)
            }
        }
        // Overwrite with incoming
        for segment in incoming.components(separatedBy: ";") {
            let trimmed = segment.trimmingCharacters(in: .whitespaces)
            let parts = trimmed.split(separator: "=", maxSplits: 1).map(String.init)
            if parts.count == 2, !parts[0].isEmpty {
                dict[parts[0].trimmingCharacters(in: .whitespaces)] =
                    parts[1].trimmingCharacters(in: .whitespaces)
            }
        }
        return dict.map { "\($0.key)=\($0.value)" }.joined(separator: "; ")
    }

    private func removingCookie(named key: String, from raw: String) -> String {
        raw.components(separatedBy: ";").compactMap { segment -> String? in
            let trimmed = segment.trimmingCharacters(in: .whitespaces)
            let parts = trimmed.split(separator: "=", maxSplits: 1)
            guard parts.count == 2 else { return trimmed.isEmpty ? nil : trimmed }
            let name = parts[0].trimmingCharacters(in: .whitespaces)
            return name == key ? nil : trimmed
        }.joined(separator: "; ")
    }
}
