import Foundation
import JavaScriptCore
import os

/// JavaScript execution engine wrapping JavaScriptCore.
/// Provides Legado-compatible `java.*` bridge functions so book source
/// rules written for Legado's Rhino engine run on iOS.
///
/// Usage:
/// ```
/// let engine = JSCoreEngine()
/// engine.getData = { key in storage[key] }
/// engine.putData = { key, val in storage[key] = val }
/// let html = engine.evaluate("java.ajax(url)", result: previousResult)
/// ```
class JSCoreEngine {

    private var context: JSContext
    private let bridge: LegadoJSBridge
    private let cookieBridge = LegadoCookieBridge()
    /// Bridge for `source.*` — replaces the plain dictionary with a full Legado-compatible object.
    private(set) var sourceBridge: LegadoSourceBridge
    /// Bridge for `cache.*` — persistent + memory key-value store.
    private(set) var cacheBridge: LegadoCacheBridge
    /// Bridge for Legado's mutable `book` object.
    private(set) var bookBridge: LegadoBookBridge
    /// Bridge for Legado's mutable `chapter` object.
    private(set) var chapterBridge: LegadoChapterBridge

    // Serial queue owns the JSContext — all evaluations run on this queue.
    // Using a dedicated queue instead of NSLock eliminates the deadlock that
    // NSLock causes when JS calls java.ajax() (semaphore) while the lock is held.
    private var jsQueue = DispatchQueue(label: "com.yuedu.jsengine.serial", qos: .userInitiated)
    private let jsQueueKey = DispatchSpecificKey<Void>()

    /// JS evaluation timeout. If a script takes longer than this, the engine is
    /// reset and the evaluation returns nil. Guards against infinite loops in
    /// book-source rule JS that would otherwise permanently block the serial
    /// queue and freeze the calling Task (common on iOS 17).
    private static let jsTimeout: TimeInterval = 30

    /// Last JavaScript error message (nil if no error on last evaluation).
    private(set) var lastError: String?

    /// Human-readable pipeline stage included in structured compatibility errors.
    private(set) var executionStage = "javascript"

    // MARK: - Delegates

    /// Retrieve a stored variable by key (wired to RuleDataInterface).
    var getData: ((String) -> String?)? {
        didSet { bridge.getData = getData }
    }

    /// Store a variable by key (wired to RuleDataInterface).
    var putData: ((String, String) -> Void)? {
        didSet { bridge.putData = putData }
    }

    /// Handle network requests originating from `java.ajax` / `java.connect`.
    var networkHandler: SourceScriptTransport? {
        didSet { bridge.networkHandler = networkHandler }
    }

    /// Handle AnalyzeUrl parsing for `java.ajax` URLs with ,{json} options. Called on the JS
    /// thread; the request it builds keeps its network apart from its JS (`PreparedSourceRequest`).
    var analyzeUrlHandler: ((String) -> PreparedSourceRequest?)? {
        didSet { bridge.analyzeUrlHandler = analyzeUrlHandler }
    }

    /// Handle `java.getString(ruleStr)` — connected to ModernRuleEngine later.
    var getStringHandler: ((String) -> String?)? {
        didSet { bridge.getStringHandler = getStringHandler }
    }

    /// Handle `java.getStringList(ruleStr)` — connected to ModernRuleEngine later.
    var getStringListHandler: ((String) -> [String]?)? {
        didSet { bridge.getStringListHandler = getStringListHandler }
    }

    /// Handle `java.setContent(content, baseUrl)` — updates engine content and result.
    var setContentHandler: ((Any?, String?) -> Void)? {
        didSet { bridge.setContentHandler = setContentHandler }
    }

    /// Handle `java.getElements(ruleStr)` — extracts elements from stored content.
    var getElementsHandler: ((String) -> [Any]?)? {
        didSet { bridge.getElementsHandler = getElementsHandler }
    }

    /// Handle `java.getString(ruleStr)` against previously stored setContent content.
    var getStringWithContentHandler: ((String, Any?) -> String?)? {
        didSet { bridge.getStringWithContentHandler = getStringWithContentHandler }
    }

    /// Called when JS invokes `java.startBrowser` / `java.startBrowserAwait`. Unset, pages
    /// open through `LegadoJSBridge.sharedBrowserPresenter`.
    var browserPresentHandler: ((SourceBrowserRequest, @escaping @Sendable (String?) -> Void) -> Void)? {
        didSet { bridge.browserPresentHandler = browserPresentHandler }
    }

    /// Called when JS invokes `java.getVerificationCode`. Unset, the captcha opens through
    /// `LegadoJSBridge.sharedCaptchaPresenter`.
    var captchaPresentHandler: ((SourceCaptchaRequest, @escaping @Sendable (String?) -> Void) -> Void)? {
        didSet { bridge.captchaPresentHandler = captchaPresentHandler }
    }

    /// See `LegadoJSBridge.sourceBrowserRequest(urlString:)`.
    func sourceBrowserRequest(urlString: String) -> URLRequest? {
        bridge.sourceBrowserRequest(urlString: urlString)
    }

    /// Called for Legado's source-authored four-argument browser pages.
    var browserPagePresentHandler: ((LegadoBrowserPageRequest) -> Void)? {
        didSet { bridge.browserPagePresentHandler = browserPagePresentHandler }
    }

    /// Called when JS invokes `java.reLoginView()` — re-render the source's custom login menu.
    var reLoginViewHandler: (() -> Void)? {
        didSet { bridge.reLoginViewHandler = reLoginViewHandler }
    }

    /// Called when JS invokes `java.upLoginData(map)` — persist source-menu setting values.
    var upLoginDataHandler: ((JSValue) -> Void)? {
        didSet { bridge.upLoginDataHandler = upLoginDataHandler }
    }

    /// Called when JS invokes `java.toast` / `java.longToast`.
    var toastHandler: (@Sendable (String) -> Void)? {
        didSet { bridge.toastHandler = toastHandler }
    }

    /// Called when JS invokes `java.refreshBookInfo()` / `java.refreshBookToc()`.
    var refreshBookInfoHandler: (() -> Void)? {
        didSet { bridge.refreshBookInfoHandler = refreshBookInfoHandler }
    }

    var refreshBookTocHandler: (() -> Void)? {
        didSet { bridge.refreshBookTocHandler = refreshBookTocHandler }
    }

    /// Called when JS invokes `java.refreshExplore()`.
    var refreshExploreHandler: (() -> Void)? {
        didSet { bridge.refreshExploreHandler = refreshExploreHandler }
    }

    /// Called when JS invokes `java.setResponseBase64(data, mimeType)` — captures
    /// base64-decoded audio data from TTS `loginCheckJs` response processing.
    var responseBase64Handler: ((Data, String) -> Void)? {
        didSet { bridge.setResponseBase64Handler = responseBase64Handler }
    }

    /// Book source object injected as `source` in JS — set this before evaluating rule scripts.
    var bookSource: BookSource? {
        didSet {
            onJSQueue {
                clearResolvedHeaderCache()
                guard let src = bookSource else {
                    sourceBridge = LegadoSourceBridge(
                        bookSourceUrl: "", bookSourceName: "", bookSourceGroup: "",
                        bookSourceComment: "", loginUrl: "", header: "", loginCheckJs: ""
                    )
                    cacheBridge = LegadoCacheBridge(sourceId: "")
                    bridge.requestTimeoutSeconds = 8
                    injectSourceObject(into: context)
                    context.setObject(cacheBridge, forKeyedSubscript: "cache" as NSString)
                    return
                }
                let prevHandlers = sourceBridge.getVariableHandler
                sourceBridge = LegadoSourceBridge.from(src)
                sourceBridge.getVariableHandler = prevHandlers
                cacheBridge = LegadoCacheBridge(sourceId: src.bookSourceUrl)
                injectSourceObject(into: context)
                context.setObject(cacheBridge, forKeyedSubscript: "cache" as NSString)
                installExploreInfoMap(into: context)
                bridge.requestTimeoutSeconds = Self.clampedRequestTimeoutSeconds(src.respondTime)
            }
        }
    }

    // MARK: - Resolved source headers

    private var resolvedHeaderCache: [String: String]?
    private var resolvedHeaderLoginInfoRevision: UInt64?
    private let resolvedHeaderCacheLock = NSLock()
    private var isResolvingHeaders = false
    /// Where every resolution is also published for readers off the source's host (cover
    /// cells on the main thread read it through `BookSource.parsedHeaders`).
    var headerSnapshot: SourceHeaderSnapshot?

    /// The source's `header` rule resolved to request headers (Legado
    /// `getHeaderMap()`): plain JSON, or a `@js:` / `<js>` rule evaluated here.
    ///
    /// Resolved on first use — not when the source is attached — so a rule that
    /// calls `jsLib` helpers sees them. Cached because a JS rule would otherwise
    /// re-run for every `java.get`/`java.ajax` (段評 fires hundreds), and guarded
    /// against re-entry because a header rule may itself issue a request.
    ///
    /// Never called on the main thread: the source's host resolves it, and readers that
    /// cannot wait read `headerSnapshot` (`BookSource.parsedHeaders`).
    func resolvedSourceHeaders() -> [String: String] {
        // `java.ajaxAll` waits on worker requests while occupying the JS queue, so no worker
        // may reach here: hopping onto that queue deadlocks the batch until its timeout.
        // Every request reads its headers on the JS thread instead — `ajaxAll` resolves them
        // before it fans out, and the AnalyzeUrl handler while it builds each request
        // (`PreparedSourceRequest`). `work` caches every result it resolves — `[:]` for a
        // source with no header rule, or no source — except the `[:]` a header rule's own
        // request gets on re-entry.
        let loginInfoRevision = currentLoginInfoRevision()
        resolvedHeaderCacheLock.lock()
        let cached = resolvedHeaderCache
        let cachedRevision = resolvedHeaderLoginInfoRevision
        resolvedHeaderCacheLock.unlock()
        if let cached, cachedRevision == loginInfoRevision { return cached }

        let work = { [self] () -> [String: String] in
            let currentRevision = currentLoginInfoRevision()
            resolvedHeaderCacheLock.lock()
            let cached = resolvedHeaderCache
            let cachedRevision = resolvedHeaderLoginInfoRevision
            resolvedHeaderCacheLock.unlock()
            if let cached, cachedRevision == currentRevision { return cached }
            guard !isResolvingHeaders else { return [:] }
            var headers: [String: String] = [:]
            if let header = bookSource?.header {
                isResolvingHeaders = true
                headers = parseHeaders(header)
                isResolvingHeaders = false
            }
            resolvedHeaderCacheLock.lock()
            resolvedHeaderCache = headers
            resolvedHeaderLoginInfoRevision = currentRevision
            resolvedHeaderCacheLock.unlock()
            headerSnapshot?.store(headers)
            return headers
        }
        return onJSQueue(work)
    }

    /// Headers visible to `java.*` requests. Legado's request layer merges the
    /// source header rule with the payload stored by `source.putLoginHeader()`;
    /// the latter wins when both declare the same field.
    func resolvedRequestHeaders() -> [String: String] {
        var headers = resolvedSourceHeaders()
        guard let sourceUrl = bookSource?.bookSourceUrl,
              let loginHeaders = LoginManager.shared.getLoginHeaderMap(sourceUrl: sourceUrl)
        else { return headers }
        headers.merge(loginHeaders) { _, loginValue in loginValue }
        return headers
    }

    private func currentLoginInfoRevision() -> UInt64 {
        guard let sourceUrl = bookSource?.bookSourceUrl else { return 0 }
        return LoginManager.shared.loginInfoRevision(sourceUrl: sourceUrl)
    }

    private func clearResolvedHeaderCache() {
        resolvedHeaderCacheLock.lock()
        resolvedHeaderCache = nil
        resolvedHeaderLoginInfoRevision = nil
        resolvedHeaderCacheLock.unlock()
    }

    /// Called when JS evaluation fails, with the error message and the script that caused it.
    var errorHandler: ((String, String) -> Void)?

    // MARK: - Initializer

    init() {
        let ctx = JSContext()!
        self.context = ctx
        self.bridge = LegadoJSBridge()
        self.sourceBridge = LegadoSourceBridge(
            bookSourceUrl: "", bookSourceName: "", bookSourceGroup: "",
            bookSourceComment: "", loginUrl: "", header: "", loginCheckJs: ""
        )
        self.cacheBridge = LegadoCacheBridge(sourceId: "")
        self.bookBridge = LegadoBookBridge()
        self.chapterBridge = LegadoChapterBridge()

        jsQueue.setSpecific(key: jsQueueKey, value: ())
        configureContext(ctx)

        // `java.get`/`java.post`/`java.ajax` inside rule JS ask for the source's
        // headers per request; resolve them lazily so a `@js:` rule runs after
        // jsLib is in place (and only once — see `resolvedSourceHeaders`).
        bridge.sourceHeadersProvider = { [weak self] in
            self?.resolvedRequestHeaders() ?? [:]
        }
        // Read live rather than snapshotted: the toggle can change while a
        // source stays attached, and the next request must see it.
        bridge.presentsAndroidIdentityProvider = { [weak self] in
            self?.bookSource?.presentsAndroidIdentity ?? false
        }
        bridge.sourceIdentityProvider = { [weak self] in
            (self?.bookSource?.bookSourceName ?? "", self?.bookSource?.bookSourceUrl ?? "")
        }
        bridge.importScriptCacheProvider = { [weak self] in
            self?.cacheBridge
        }
    }

    private static func clampedRequestTimeoutSeconds(_ respondTimeMilliseconds: Int64) -> TimeInterval {
        guard respondTimeMilliseconds > 0 else { return 8 }
        let seconds = Double(respondTimeMilliseconds) / 1000.0
        return min(30, max(8, seconds))
    }

    // MARK: - Public API

    // Lock protecting `jsQueue` swap during timeout recovery.
    private let queueLock = NSLock()

    /// Read the current jsQueue under lock (safe to call from any thread).
    private var safeJsQueue: DispatchQueue {
        queueLock.lock()
        let q = jsQueue
        queueLock.unlock()
        return q
    }

    /// Dispatch work to the JS serial queue, re-entrant-safe.
    /// If already executing on the JS queue (e.g. java.getString → engine.getString → evaluate),
    /// the work runs inline to avoid a deadlock.
    private func onJSQueue<T>(_ work: () -> T) -> T {
        if DispatchQueue.getSpecific(key: jsQueueKey) != nil {
            return work() // already on the JS queue — run inline
        }
        return SourcePerfTrace.mainThreadWait("wait.jsQueue") { safeJsQueue.sync { work() } }
    }

    /// Like `onJSQueue` but with a timeout. Returns `.timedOut` when the JS
    /// evaluation takes longer than `Self.jsTimeout` seconds. On timeout the
    /// engine is reset so subsequent evaluations can proceed.
    private enum JSTimeoutResult<T> {
        case completed(T)
        case timedOut
    }

    private func onJSQueueWithTimeout<T>(_ work: @escaping () -> T) -> JSTimeoutResult<T> {
        if DispatchQueue.getSpecific(key: jsQueueKey) != nil {
            return .completed(work())
        }

        // Written on the JS queue, read here after the group says it finished. After a timeout
        // the late write lands in the lock and is never read.
        let result = OSAllocatedUnfairLock<JSConfined<T>?>(initialState: nil)
        let group = DispatchGroup()
        let queue = safeJsQueue
        let work = JSConfined(work)
        // Only guards against the engine being torn down; the engine itself is unused
        // because `work` is a self-contained closure.
        let engine = JSConfined<() -> JSCoreEngine?>({ [weak self] in self })

        group.enter()
        queue.async {
            guard engine.value() != nil else { group.leave(); return }
            let value = JSConfined(work.value())
            result.withLock { $0 = value }
            group.leave()
        }

        // The timeout stops runaway rule JS. A script parked in `java.startBrowserAwait` or
        // `java.getVerificationCode` is waiting for the reader — a login, a Cloudflare check,
        // a captcha — not stuck, and Legado waits for as long as that takes; resetting the
        // engine under it threw away the script's state and its result. The sheet always
        // ends (`BrowserAwaitBox`) — but it is shown on the main thread, so a caller blocking
        // the main thread here keeps the timeout: waiting on would leave it unable to appear.
        var timedOut = false
        SourcePerfTrace.mainThreadWait("wait.jsQueue", "timeout=\(Int(Self.jsTimeout))s timedOut=\(timedOut)") {
            while group.wait(timeout: .now() + Self.jsTimeout) == .timedOut {
                if bridge.isAwaitingUser, !Thread.isMainThread { continue }
                resetEngine()
                timedOut = true
                return
            }
        }
        if timedOut { return .timedOut }

        return .completed(result.withLock { $0 }!.value)
    }

    // MARK: - JS network attribution
    //
    // Forwards to the java bridge's accumulator so a caller (ModernParserBridge) can measure
    // how much of a parse was spent blocked on `java.*` network (段評 review fetches) vs JS CPU.
    func resetJSNetworkMs() { bridge.resetNetworkMs() }
    func takeJSNetworkMs() -> Double { bridge.takeNetworkMs() }

    /// Executes a nested evaluation under a precise pipeline stage. The JS queue is
    /// re-entrant, so callers can wrap existing evaluation APIs without a second path.
    func withExecutionStage<T>(_ stage: String, _ work: () -> T) -> T {
        onJSQueue {
            let previous = executionStage
            executionStage = stage
            updateRuntimeErrorContext()
            defer {
                executionStage = previous
                updateRuntimeErrorContext()
            }
            return work()
        }
    }

    private func updateRuntimeErrorContext() {
        context.setObject([
            "stage": executionStage,
            "sourceName": bookSource?.bookSourceName ?? "?",
            "sourceId": Self.redactedSourceIdentifier(bookSource?.bookSourceUrl),
        ], forKeyedSubscript: "__yueduLegadoErrorContext" as NSString)
    }

    private static func redactedSourceIdentifier(_ rawValue: String?) -> String {
        guard let rawValue, !rawValue.isEmpty else { return "?" }
        guard var components = URLComponents(string: rawValue), components.host != nil else {
            return String(rawValue.prefix(160))
        }
        components.query = nil
        components.fragment = nil
        return String((components.string ?? rawValue).prefix(160))
    }

    /// Evaluate JavaScript code and return the result as a string.
    /// Returns `nil` on JS error, timeout, or if the result is `undefined`/`null`.
    func evaluate(_ script: String) -> String? {
        switch onJSQueueWithTimeout({ [self] () -> String? in
            lastError = nil
            let prepared = Self.prepareSourceJS(script)
            guard let value = context.evaluateScript(prepared) else { return nil }
            return extractString(from: value)
        }) {
        case .completed(let r): return r
        case .timedOut: return nil
        }
    }

    /// Evaluate with a `result` variable pre-set (Legado convention:
    /// the previous rule step's output is available as `result` in JS).
    func evaluate(_ script: String, result: String?) -> String? {
        evaluate(script, result: result as Any?, bindings: [:])
    }

    /// Evaluate with an arbitrary `result` value and extra bindings. JSON strings
    /// are exposed to JS as objects so rules can use `result.book_id` after
    /// a `$.data` extraction, matching Legado's dynamic result semantics.
    func evaluate(_ script: String, result: Any?, bindings: [String: Any] = [:]) -> String? {
        switch onJSQueueWithTimeout({ [self] () -> String? in
            lastError = nil
            setResult(result)
            for (key, value) in bindings {
                context.setObject(value, forKeyedSubscript: key as NSString)
            }
            let prepared = Self.prepareSourceJS(script)
            guard let value = context.evaluateScript(prepared) else { return nil }
            return extractString(from: value)
        }) {
        case .completed(let r): return r
        case .timedOut: return nil
        }
    }

    /// Executes `loginCheckJs` with Legado's response-shaped `result`. When the
    /// script returns another StrResponse, use it; scalar/undefined completion
    /// values mean the script only performed side effects (for example refreshing
    /// a login header), so the original response remains authoritative.
    func evaluateResponseScript(
        _ script: String,
        response: LegadoStrResponse,
        bindings: [String: Any] = [:]
    ) -> LegadoStrResponse {
        switch onJSQueueWithTimeout({ [self] in
            lastError = nil
            setResult(response)
            for (key, value) in bindings {
                context.setObject(value, forKeyedSubscript: key as NSString)
            }
            guard let value = context.evaluateScript(Self.prepareSourceJS(script)),
                  lastError == nil,
                  !value.isUndefined,
                  !value.isNull,
                  let replacement = value.toObject() as? LegadoStrResponse else {
                return response
            }
            return replacement
        }) {
        case .completed(let result): return result
        case .timedOut: return response
        }
    }

    /// Normalizes Android/Rhino-isms that JavaScriptCore rejects, so source rule JS authored for
    /// Legado-on-Android compiles on iOS. Applied to every rule-JS evaluation path.
    private static func prepareSourceJS(_ script: String) -> String {
        LegadoRhinoNormalizer.normalize(script).source
    }

    /// Detect a `return` that belongs to the rule snippet itself. Returns inside
    /// a function/arrow body are valid in a block and must not force the outer
    /// function wrapper, otherwise the block's final expression is lost.
    private static func containsTopLevelReturn(_ script: String) -> Bool {
        let bytes = Array(script.utf8)
        var braceDepth = 0
        var canStartRegex = true
        var quote: UInt8?
        var escaped = false
        var lineComment = false
        var blockComment = false
        var index = 0

        while index < bytes.count {
            let byte = bytes[index]
            let next = index + 1 < bytes.count ? bytes[index + 1] : 0

            if lineComment {
                if byte == 10 || byte == 13 { lineComment = false }
                index += 1
                continue
            }
            if blockComment {
                if byte == 42 && next == 47 {
                    blockComment = false
                    index += 2
                } else {
                    index += 1
                }
                continue
            }
            if let activeQuote = quote {
                if escaped {
                    escaped = false
                } else if byte == 92 {
                    escaped = true
                } else if byte == activeQuote {
                    quote = nil
                    canStartRegex = false
                }
                index += 1
                continue
            }
            if byte == 47 && next == 47 {
                lineComment = true
                index += 2
                continue
            }
            if byte == 47 && next == 42 {
                blockComment = true
                index += 2
                continue
            }
            if byte == 39 || byte == 34 || byte == 96 {
                quote = byte
                index += 1
                continue
            }
            // A regular-expression literal may contain an escaped slash immediately
            // followed by its closing slash (for example `/^https?:\/\//`). A plain
            // byte scan mistakes that pair for a `//` comment, then loses the braces
            // on the rest of the line and can classify a nested `return` as top-level.
            // Skip the complete literal, including character classes, before tracking
            // block depth. This is the same lexical distinction Rhino makes.
            if byte == 47, canStartRegex {
                index += 1
                var inCharacterClass = false
                var regexEscaped = false
                while index < bytes.count {
                    let regexByte = bytes[index]
                    if regexEscaped {
                        regexEscaped = false
                    } else if regexByte == 92 {
                        regexEscaped = true
                    } else if regexByte == 91 {
                        inCharacterClass = true
                    } else if regexByte == 93 {
                        inCharacterClass = false
                    } else if regexByte == 47, !inCharacterClass {
                        index += 1
                        while index < bytes.count,
                              (bytes[index] >= 65 && bytes[index] <= 90)
                                || (bytes[index] >= 97 && bytes[index] <= 122) {
                            index += 1
                        }
                        break
                    }
                    index += 1
                }
                canStartRegex = false
                continue
            }
            if byte == 123 {
                braceDepth += 1
                canStartRegex = true
                index += 1
                continue
            }
            if byte == 125 {
                braceDepth = max(0, braceDepth - 1)
                canStartRegex = false
                index += 1
                continue
            }
            if isIdentifierByte(byte), !(byte >= 48 && byte <= 57) {
                let start = index
                index += 1
                while index < bytes.count, isIdentifierByte(bytes[index]) {
                    index += 1
                }
                let word = String(decoding: bytes[start..<index], as: UTF8.self)
                if braceDepth == 0, word == "return" {
                    return true
                }
                canStartRegex = [
                    "return", "case", "throw", "delete", "void", "typeof",
                    "new", "in", "of", "yield", "await", "else", "do",
                ].contains(word)
                continue
            }
            if byte >= 48 && byte <= 57 {
                index += 1
                while index < bytes.count,
                      isIdentifierByte(bytes[index]) || bytes[index] == 46 {
                    index += 1
                }
                canStartRegex = false
                continue
            }
            if byte == 40 || byte == 91 || byte == 44 || byte == 59
                || byte == 58 || byte == 61 || byte == 63 || byte == 33
                || byte == 38 || byte == 124 || byte == 43 || byte == 45
                || byte == 42 || byte == 37 || byte == 94 || byte == 126 {
                canStartRegex = true
            } else if byte == 41 || byte == 93 {
                canStartRegex = false
            }
            index += 1
        }
        return false
    }

    private static func isIdentifierByte(_ byte: UInt8) -> Bool {
        (byte >= 48 && byte <= 57)
            || (byte >= 65 && byte <= 90)
            || (byte >= 97 && byte <= 122)
            || byte == 95
            || byte == 36
    }

    /// Evaluate with multiple bindings injected into the context before execution.
    func evaluate(_ script: String, bindings: [String: Any]) -> String? {
        switch onJSQueueWithTimeout({ [self] () -> String? in
            lastError = nil
            for (key, value) in bindings {
                context.setObject(value, forKeyedSubscript: key as NSString)
            }
            guard let val = context.evaluateScript(Self.prepareSourceJS(script)) else { return nil }
            return extractString(from: val)
        }) {
        case .completed(let r): return r
        case .timedOut: return nil
        }
    }

    /// Evaluate a rule snippet in an isolated scope so `let`/`const` declarations
    /// from one Legado rule segment do not leak into later segments. Legado also
    /// permits a top-level `return` in rule snippets, which JavaScriptCore only
    /// accepts inside a function body. Most snippets instead rely on the final
    /// expression's completion value; wrapping those in a function would turn
    /// the same valid value into `undefined`.
    func evaluateIsolated(_ script: String, result: Any?, bindings: [String: Any] = [:]) -> String? {
        let prepared = Self.prepareSourceJS(script)
        let isolated = Self.containsTopLevelReturn(prepared)
            ? "(function() {\n\(prepared)\n})()"
            : "{\n\(prepared)\n}"
        return evaluate(isolated, result: result, bindings: bindings)
    }

    func evaluateIsolated(_ script: String, bindings: [String: Any]) -> String? {
        let prepared = Self.prepareSourceJS(script)
        let isolated = Self.containsTopLevelReturn(prepared)
            ? "(function() {\n\(prepared)\n})()"
            : "{\n\(prepared)\n}"
        return evaluate(isolated, bindings: bindings)
    }

    /// `evaluateIsolated(_:bindings:)` with `overlay` read in place of the source's stored
    /// variable for this one evaluation, and never stored (unified library 5d-5:
    /// `LegadoSourceBridge.withVariableOverlay`). The overlay is put in place on the JS queue,
    /// around the script alone.
    func evaluateIsolated(_ script: String, bindings: [String: Any], variableOverlay overlay: [String: String]) -> String? {
        guard !overlay.isEmpty else { return evaluateIsolated(script, bindings: bindings) }
        switch onJSQueueWithTimeout({ [self] () -> String? in
            LegadoSourceBridge.withVariableOverlay(overlay) { evaluateIsolated(script, bindings: bindings) }
        }) {
        case .completed(let r): return r
        case .timedOut: return nil
        }
    }

    /// Evaluate a script whose result is BYTES (Legado image-decode convention:
    /// `result` holds the raw bytes, the script returns decoded bytes). The
    /// input bytes are exposed as a JS number array (0–255); the return value
    /// may be a number array (Java byte semantics tolerated) or a base64 string.
    func evaluateBytes(_ script: String, data: Data, bindings: [String: Any] = [:]) -> Data? {
        let numbers = data.map { NSNumber(value: $0) }
        switch onJSQueueWithTimeout({ [self] () -> Data? in
            lastError = nil
            context.setObject(numbers, forKeyedSubscript: "result" as NSString)
            for (key, value) in bindings {
                context.setObject(value, forKeyedSubscript: key as NSString)
            }
            let prepared = Self.prepareSourceJS(script)
            guard let value = context.evaluateScript(prepared) else { return nil }
            let bytes = Self.extractBytes(from: value)
            if bytes == nil, lastError == nil, !value.isUndefined, !value.isNull {
                lastError = "Image decode result must contain finite bytes and fit within 32 MiB"
            }
            return bytes
        }) {
        case .completed(let r): return r
        case .timedOut: return nil
        }
    }

    private static func extractBytes(from value: JSValue) -> Data? {
        if value.isUndefined || value.isNull { return nil }
        if value.isArray {
            // JSValue.toArray recursively bridges the entire graph to NSArray.
            // A sparse/cyclic result or an enormous declared length can trap in
            // Foundation before a Swift cast can reject it. Decode scalar bytes
            // directly on the JS queue, with the image payload bounded to 32 MiB.
            guard let lengthValue = value.forProperty("length") else { return nil }
            let length = lengthValue.toDouble()
            guard length.isFinite, length > 0, length <= 32 * 1024 * 1024,
                  length.rounded(.towardZero) == length else { return nil }
            var data = Data(capacity: Int(length))
            for index in 0..<Int(length) {
                guard let element = value.atIndex(index), element.isNumber else { return nil }
                let number = element.toDouble()
                guard number.isFinite else { return nil }
                // Java signed bytes and JS unsigned bytes share the same low byte.
                let byte = Int(number.rounded(.towardZero).truncatingRemainder(dividingBy: 256))
                data.append(UInt8(truncatingIfNeeded: byte))
            }
            return data.isEmpty ? nil : data
        }
        if value.isString, let string = value.toString() {
            if let decoded = Data(base64Encoded: string), !decoded.isEmpty {
                return decoded
            }
            let utf8 = Data(string.utf8)
            return utf8.isEmpty ? nil : utf8
        }
        return nil
    }

    /// Reset the context — clears all JS variables and re-injects the bridge.
    func reset() {
        onJSQueue {
            let ctx = JSContext()!
            self.context = ctx
            configureContext(ctx)
            lastError = nil
        }
    }

    /// Monotonically increasing generation counter. Incremented on `resetEngine()`.
    /// `ModernParserBridge` uses this to know when to re-evaluate jsLib.
    private(set) var generation: UInt64 = 0

    /// Hard-reset the engine by creating a fresh serial queue and JSContext.
    /// Used after a JS evaluation timeout to break free from a hung script;
    /// the old queue and context are abandoned (they continue running on their
    /// thread but never affect the new engine).
    private func resetEngine() {
        let label = "com.yuedu.jsengine.\(UUID().uuidString.prefix(8))"
        let newQueue = DispatchQueue(label: label, qos: .userInitiated)
        newQueue.setSpecific(key: jsQueueKey, value: ())
        let newContext = JSContext()!
        configureContext(newContext)

        queueLock.lock()
        jsQueue = newQueue
        context = newContext
        generation += 1
        queueLock.unlock()

        lastError = nil
    }

    /// Runs `body` — the content rule of the video episode being played — with
    /// `java.openVideoPlayer` and `java.startBrowser` handing their link or page to the caller
    /// instead of opening a player or a sheet (`LegadoJSBridge.videoEpisodeHandover`).
    func handingOverVideoEpisode<T>(_ body: () throws -> T) rethrows -> (T, LegadoJSBridge.VideoEpisodeHandover) {
        onJSQueue { bridge.videoEpisodeHandover = .init() }
        defer { onJSQueue { bridge.videoEpisodeHandover = nil } }
        let result = try body()
        return (result, onJSQueue { bridge.videoEpisodeHandover ?? .init() })
    }

    func setBookBridge(_ bridge: LegadoBookBridge) {
        onJSQueue {
            self.bookBridge = bridge
            context.setObject(bridge, forKeyedSubscript: "book" as NSString)
        }
    }

    func setChapterBridge(_ bridge: LegadoChapterBridge) {
        onJSQueue {
            self.chapterBridge = bridge
            context.setObject(bridge, forKeyedSubscript: "chapter" as NSString)
            injectChapterGlobals(bridge, into: context)
        }
    }

    // MARK: - Private Helpers

    /// Configure a fresh JSContext with the bridge object and helpers.
    private func configureContext(_ ctx: JSContext) {
        // Exception handler
        ctx.exceptionHandler = { [weak self] _, exception in
            let msg = exception?.toString() ?? "Unknown JS error"
            self?.lastError = msg
            if msg.contains("eval() is disabled") {
                AppLogger.security("Book source JS attempted to use disabled eval(); blocked", context: ["error": msg])
            }
            // Surface uncaught rule-JS exceptions to the device log (Console) so book
            // source failures (TOC/content not loading, etc.) are diagnosable without
            // the in-app debug engine. Only uncaught exceptions reach this handler.
            AppLogger.parse("Book source rule JS exception", context: [
                "source": self?.bookSource?.bookSourceName ?? "?",
                "error": msg
            ])
            self?.errorHandler?(msg, "js exception")
            #if DEBUG
            print("[JSCoreEngine] JS Error: \(msg)")
            #endif
        }

        // Inject the `java` bridge object
        ctx.setObject(bridge, forKeyedSubscript: "java" as NSString)
        // JSExport cannot expose two `showBrowser` overloads under one JavaScript name.
        // Keep the native two-argument method for ordinary URLs, and route Legado's
        // four-argument source-page form through a uniquely named native block.
        let showBrowserPageBlock: @convention(block) (String, String, String, String) -> Void = {
            [weak bridge] url, html, injectedJavaScript, configurationJSON in
            bridge?.browserPagePresentHandler?(
                LegadoBrowserPageRequest(
                    baseURL: url,
                    // JavaScript null crosses as "" (the shim's `String(x == null ? '' : x)`).
                    html: html.isEmpty ? nil : html,
                    injectedJavaScript: injectedJavaScript,
                    configurationJSON: configurationJSON
                )
            )
        }
        ctx.setObject(showBrowserPageBlock, forKeyedSubscript: "__yueduShowBrowserPage" as NSString)
        ctx.evaluateScript("""
            (function () {
                var nativeShowBrowser = java.showBrowser.bind(java);
                java.showBrowser = function (url, titleOrHTML, injectedJavaScript, configurationJSON) {
                    if (arguments.length >= 3) {
                        return __yueduShowBrowserPage(
                            String(url == null ? '' : url),
                            String(titleOrHTML == null ? '' : titleOrHTML),
                            String(injectedJavaScript == null ? '' : injectedJavaScript),
                            String(configurationJSON == null ? '' : configurationJSON)
                        );
                    }
                    return nativeShowBrowser(url, titleOrHTML);
                };
            })();
        """)
        // Legado overloads `startBrowserAwait(url, title[, refetchAfterSuccess[, html]])` and
        // `startBrowser(url, title[, html])` by arity, and JSExport cannot: the Swift overloads
        // land on one JavaScript name, so which one a call reached — and whether an omitted
        // `refetchAfterSuccess` meant Legado's `true` — was up to JavaScriptCore. An absent
        // `html` crosses as "" (a JavaScript null would arrive as the string "null").
        let startBrowserAwaitBlock: @convention(block) (String, String, Bool, String) -> LegadoStrResponse = {
            [weak bridge] url, title, refetchAfterSuccess, html in
            bridge?.startBrowserAwait(url, title, refetchAfterSuccess, html.isEmpty ? nil : html)
                ?? LegadoStrResponse(url: url, body: "")
        }
        let startBrowserBlock: @convention(block) (String, String, String) -> Void = {
            [weak bridge] url, title, html in
            bridge?.startBrowser(url, title, html.isEmpty ? nil : html)
        }
        ctx.setObject(startBrowserAwaitBlock, forKeyedSubscript: "__yueduStartBrowserAwait" as NSString)
        ctx.setObject(startBrowserBlock, forKeyedSubscript: "__yueduStartBrowser" as NSString)
        ctx.evaluateScript("""
            (function (nativeStartBrowserAwait, nativeStartBrowser) {
                function text(value) { return String(value == null ? '' : value); }
                java.startBrowserAwait = function (url, title, refetchAfterSuccess, html) {
                    return nativeStartBrowserAwait(
                        text(url),
                        text(title),
                        arguments.length < 3 ? true : !!refetchAfterSuccess,
                        text(html)
                    );
                };
                java.startBrowser = function (url, title, html) {
                    nativeStartBrowser(text(url), text(title), text(html));
                };
            })(__yueduStartBrowserAwait, __yueduStartBrowser);
            delete __yueduStartBrowserAwait;
            delete __yueduStartBrowser;
        """)
        // JavaScriptCore performs an Objective-C receiver check when an exported
        // bridge method is called as a detached function (`const b64 =
        // java.base64Encode; b64(...)`). Legado sources commonly use that form;
        // install closures for the string codecs so those calls retain a valid
        // receiver instead of throwing `self type check failed`.
        let base64EncodeBlock: @convention(block) (String) -> String = { [weak bridge] value in
            bridge?.base64Encode(value) ?? ""
        }
        let base64DecodeBlock: @convention(block) (String) -> String = { [weak bridge] value in
            bridge?.base64Decode(value) ?? ""
        }
        ctx.setObject(base64EncodeBlock, forKeyedSubscript: "__yueduBase64Encode" as NSString)
        ctx.setObject(base64DecodeBlock, forKeyedSubscript: "__yueduBase64Decode" as NSString)
        ctx.evaluateScript("""
            java.base64Encode = __yueduBase64Encode;
            java.base64Decode = __yueduBase64Decode;
            delete __yueduBase64Encode;
            delete __yueduBase64Decode;
        """)
        let getCookieBlock: @convention(block) (String, JSValue?) -> String = { [weak bridge] url, keyValue in
            guard let bridge else { return "" }
            let key: String
            if let keyValue, !keyValue.isUndefined, !keyValue.isNull {
                key = keyValue.toString() ?? ""
            } else {
                key = ""
            }
            return key.isEmpty ? bridge.getCookie(url) : bridge.getCookieValue(url, key)
        }
        ctx.setObject(getCookieBlock, forKeyedSubscript: "__yueduGetCookie" as NSString)
        ctx.evaluateScript("java.getCookie = __yueduGetCookie;")

        // Inject the `cookie` bridge object (get/set/remove via HTTPCookieStorage)
        ctx.setObject(cookieBridge, forKeyedSubscript: "cookie" as NSString)

        // SwiftSoup backing for the `org.jsoup.*` polyfill installed below.
        // The context retains its own DOM bridge/cache. A timeout can leave the old
        // context running, so a replacement context must not share mutable SwiftSoup nodes.
        ctx.setObject(LegadoJsoupBridge(), forKeyedSubscript: "__yueduJsoup" as NSString)

        // Inject `source` as a full bridge object (Legado-compatible)
        injectSourceObject(into: ctx)

        // Inject `cache` bridge object (persistent + memory key-value store)
        ctx.setObject(cacheBridge, forKeyedSubscript: "cache" as NSString)

        // Inject mutable book/chapter bridge objects used by Legado rule JS.
        ctx.setObject(bookBridge, forKeyedSubscript: "book" as NSString)
        ctx.setObject(chapterBridge, forKeyedSubscript: "chapter" as NSString)
        injectChapterGlobals(chapterBridge, into: ctx)

        // Inject a top-level `print` that delegates to java.log
        let printBlock: @convention(block) (String) -> Void = { msg in
            #if DEBUG
            print("[JS] \(msg)")
            #endif
        }
        ctx.setObject(printBlock, forKeyedSubscript: "print" as NSString)

        // Note: eval() is intentionally LEFT ENABLED. The sandbox boundary for book
        // source JS is the bridge layer (java.*/source.*/cookie.*): JavaScriptCore code
        // can only reach the network/filesystem through those bridges, and eval()'d code
        // is confined to exactly the same surface as ordinary code. Many legitimate Legado
        // sources require eval — e.g. obfuscated jsLib loaders (`eval(java.importScript(url))`)
        // and explore builders (`eval('sort'+i+'.push(json)')`). Disabling it broke those
        // sources without adding real isolation, so native eval is used.
        //
        // The source an eval compiles is Rhino source as much as a rule is, so
        // `LegadoRhinoNormalizer` wraps every direct `eval(x)` argument in this, and a string
        // gets the same rewrites before JavaScriptCore compiles it.
        let rhinoSourceBlock: @convention(block) (JSValue) -> JSValue = { value in
            guard value.isString, let source = value.toString() else { return value }
            return JSValue(object: LegadoRhinoNormalizer.normalize(source).source, in: value.context)
        }
        ctx.setObject(rhinoSourceBlock, forKeyedSubscript: "__yueduRhinoSource" as NSString)

        // The normalizer rewrites a no-argument `.length()` call to this: a Java String's
        // `length()` (every `java.*` result under Rhino) is the JS string's `length`, and an
        // object that really has a `length()` method still gets it called.
        ctx.evaluateScript("""
            Object.defineProperty(Object.prototype, '__yueduJavaLength', {
                value: function () {
                    var length = this.length;
                    return typeof length === 'function' ? length.call(this) : length;
                },
                enumerable: false, configurable: true, writable: true
            });
        """)

        // JSON is always natively available in JSContext — this guard is a safety net only.
        // The eval() fallback from the original Legado port has been removed (eval is disabled).
        ctx.evaluateScript("""
            if (typeof JSON === 'undefined') {
                var JSON = {
                    parse: function(s) { return null; },
                    stringify: function(o) { return ''; }
                };
            }
        """)

        // Legado/Rhino exposes a JSON response dynamically: source JS can read
        // `result.field`, while `String(result)` / `result.toString()` still yield
        // the original JSON text. A plain JavaScriptCore object loses that second
        // half of the contract and becomes "[object Object]". Build the parsed value
        // inside JS so arrays keep their native methods, then attach non-enumerable
        // primitive conversion hooks that preserve the exact response string.
        // JSON.stringify remains structural because the hooks are non-enumerable.
        ctx.evaluateScript("""
            (function () {
                var __nativeParse = JSON.parse;
                Object.defineProperty(this, '__yueduWrapJSONResult', {
                    enumerable: false,
                    configurable: false,
                    writable: false,
                    value: function (raw) {
                        var parsed = __nativeParse(raw);
                        if (parsed === null || typeof parsed !== 'object') return parsed;
                        var asString = function () { return raw; };
                        if (!Object.prototype.hasOwnProperty.call(parsed, 'toString')) {
                            Object.defineProperty(parsed, 'toString', {
                                value: asString, enumerable: false, configurable: true
                            });
                        }
                        if (!Object.prototype.hasOwnProperty.call(parsed, 'valueOf')) {
                            Object.defineProperty(parsed, 'valueOf', {
                                value: asString, enumerable: false, configurable: true
                            });
                        }
                        if (typeof Symbol !== 'undefined' && Symbol.toPrimitive) {
                            Object.defineProperty(parsed, Symbol.toPrimitive, {
                                value: asString, enumerable: false, configurable: true
                            });
                        }
                        return parsed;
                    }
                });
                JSON.parse = function (value, reviver) {
                    if (value !== null && typeof value === 'object') { return value; }
                    return __nativeParse(value, reviver);
                };
            })();
        """)

        // Legado helper functions frequently used by complex sources.
        // getArgument(key) reads source-level variables; setArgument(key, val) writes them.
        ctx.evaluateScript("""
            function getArgument(key) { return java.get(key) || ''; }
            function setArgument(key, value) { java.put(key, value); }
        """)

        // java.util.Map compatibility shim.
        // Legado runs on Rhino, where `source.getLoginInfoMap()` / `source.getHeaderMap()`
        // return real `java.util.Map` instances. Source jsLib routinely calls `.get(key)`
        // / `.put(key,val)` / `.containsKey(key)` on them (e.g. `getConfigValue` →
        // `infomap.get(key)`). JavaScriptCore bridges a Swift dictionary to a plain JS
        // object with no such methods, so those calls throw `… is not a function` and
        // abort the whole rule (symptom: book opens but TOC/content silently fail).
        // `__yueduJavaMap` augments a plain object in place with the Map methods as
        // non-enumerable properties, so `obj[key]` / `for..in` / `Object.keys` are
        // unaffected while `.get()` etc. work.
        ctx.evaluateScript("""
            function __yueduJavaMap(o) {
                o = o || {};
                function def(name, fn) {
                    Object.defineProperty(o, name, { value: fn, enumerable: false, configurable: true });
                }
                def('get', function (k) { var v = o[k]; return v === undefined ? null : v; });
                def('put', function (k, v) { o[k] = v; return v; });
                def('containsKey', function (k) { return Object.prototype.hasOwnProperty.call(o, k); });
                def('remove', function (k) { var v = o[k]; delete o[k]; return v === undefined ? null : v; });
                def('size', function () { return Object.keys(o).length; });
                def('isEmpty', function () { return Object.keys(o).length === 0; });
                def('keySet', function () { return Object.keys(o); });
                def('values', function () { return Object.keys(o).map(function (k) { return o[k]; }); });
                // LYC sources persist filter metadata through infoMap.save().
                // Their map is process-local here, so saving is intentionally a no-op.
                def('save', function () { return o; });
                return o;
            }
        """)

        // java.util.List compatibility. Rhino exposes both native Java lists (including
        // AnalyzeRule.getElements()) and JSON arrays with Java collection methods. JSC
        // exposes both as ordinary arrays, so source rules calling `.size()`, `.get()` or
        // `.add()` otherwise abort even though the rows are present. Keep these methods
        // non-enumerable so JSON.stringify, for..in and native array iteration are unchanged.
        ctx.evaluateScript("""
            (function (prototype) {
                function def(name, fn) {
                    if (typeof prototype[name] !== 'function') {
                        Object.defineProperty(prototype, name, {
                            value: fn, enumerable: false, configurable: true, writable: true
                        });
                    }
                }
                def('size', function () { return this.length; });
                def('get', function (index) {
                    index = Number(index);
                    return index >= 0 && index < this.length ? this[index] : null;
                });
                def('set', function (index, value) {
                    index = Number(index);
                    var previous = this.get(index);
                    this[index] = value;
                    return previous;
                });
                def('add', function (indexOrValue, value) {
                    if (arguments.length >= 2) {
                        this.splice(Number(indexOrValue), 0, value);
                    } else {
                        this.push(indexOrValue);
                    }
                    return true;
                });
                def('addAll', function (values) {
                    if (values == null) return false;
                    var incoming = Array.prototype.slice.call(values);
                    if (incoming.length === 0) return false;
                    this.push.apply(this, incoming);
                    return true;
                });
                def('toArray', function () { return this.slice(); });
                def('isEmpty', function () { return this.length === 0; });
                def('contains', function (value) { return this.indexOf(value) >= 0; });
            })(Array.prototype);
        """)

        // Luo-Ya-Cheng (洛雅橙/lyc) mod compatibility shim.
        // This must be installed after `__yueduJavaMap`: LYC explore scripts call
        // `infoMap.save()` while assembling their filter rows.
        //
        // `Set` doubles as LYC's key-value setter AND JavaScript's built-in Set
        // constructor. A plain `function Set(key, value)` shadowed the builtin, so any
        // source rule constructing `new Set()` (e.g. 企点 chapterList de-dups volume
        // names this way when 显示卷名 is on) got a method-less object, threw
        // "addedVolumes.has is not a function", and the whole TOC parse aborted
        // (symptom: 目录为空). Worse, the constructor call leaked a
        // `source.put(undefined, undefined)` into the variable store. Keep both callers
        // working: `new Set(...)` / bare `Set()` delegate to the native constructor,
        // while LYC's `Set(key, value)` call form still writes through `source.put`.
        ctx.evaluateScript("""
            function csh() {
                if (typeof source === 'undefined') return;
                var d = {
                    sort: '全部',
                    size: '30',
                    isfinish: 'all',
                    orderBy: 'newest',
                    fmale: '男频',
                    fxy: '0',
                    img: '1',
                    dp: '1',
                    jj: '0',
                    api: '1',
                    lock: '0',
                    zdy: '',
                };
                for (var k in d) {
                    if (!source.get(k)) source.put(k, d[k]);
                }
            }
            function Get(key) {
                if (typeof source !== 'undefined') return source.get(key) || '';
                return '';
            }
            (function (global) {
                var NativeSet = global.Set;
                function lycSet(key, value) {
                    if (new.target || arguments.length === 0) {
                        return arguments.length ? new NativeSet(key) : new NativeSet();
                    }
                    if (typeof source !== 'undefined') source.put(key, value);
                }
                lycSet.prototype = NativeSet.prototype;
                global.Set = lycSet;
            })(this);
            var infoMap = __yueduJavaMap({});
            function createFilter(sort, size, isfinish, orderBy, fmale) {
                // The source's jsLib may replace this fallback with its filter builder.
            }
        """)

        // Legado overloads `java.get` by arity — Rhino dispatches on argument count:
        //   java.get(key)          → the source's variable store
        //   java.get(url, headers) → an HTTP GET returning a response with `.body()`
        // JSExport maps one selector to one JS name, so only the variable getter
        // existed. 同人小说网's 段评 does `java.get(url, {}).body()`; `.body()` on a
        // String threw straight into the rule's own `catch`, which returns the
        // paragraph text unchanged — 段评 silently never appeared.
        // Shadows the exported method with a dispatcher (verified: an own property on
        // a JSExport-backed object wins over its prototype).
        Self.installJavaGetOverload(in: ctx)
        Self.installJavaConnectOverload(in: ctx)
        Self.installJavaHeadAndPostOverloads(in: ctx)

        // Install the authoritative registry-backed Java/Android contract.
        LegadoJavaInteropRuntime.install(in: ctx)
        updateRuntimeErrorContext()

        // org.jsoup.Jsoup polyfill.
        // Legado Android uses Rhino with full Java interop, so book sources can call
        // `org.jsoup.Jsoup.connect(url).execute().body()` directly. JavaScriptCore has
        // no Java interop, so `org` is undefined → "undefined is not an object" crashes
        // obfuscated content scripts (e.g. 番茄酱's remote `to.js`). This polyfill delegates
        // HTTP to the existing `java.ajax` (GET) / `java.post` (POST) bridges. Response
        // headers are not available through `java.ajax` (it returns body only), so
        // `headers().get(name)` returns null — sources that rely on ETag caching fall
        // back to their catch block, which is the existing behaviour.
        ctx.evaluateScript("""
            (function () {
                function Connection(url) {
                    this._url = String(url || '');
                    this._method = 'GET';
                    this._headers = {};
                    this._data = {};
                    this._timeout = 10000;
                    this._ua = '';
                    this._referrer = '';
                    this._body = null;
                }
                var P = Connection.prototype;
                P.method = function (m) { this._method = (typeof m === 'string') ? m : (m && m.name) || 'GET'; return this; };
                P.header = function (k, v) { this._headers[k] = String(v); return this; };
                P.headers = function (h) { if (h) for (var k in h) this._headers[k] = String(h[k]); return this; };
                P.data = function (k, v) {
                    if (arguments.length === 1 && typeof k === 'object') { for (var key in k) this._data[key] = String(k[key]); }
                    else { this._data[k] = String(v); }
                    return this;
                };
                P.requestBody = function (b) { this._body = (arguments.length === 0) ? null : String(b); return this; };
                P.cookie = function (k, v) { return this; };
                P.ignoreContentType = function (b) { return this; };
                P.timeout = function (ms) { this._timeout = parseInt(ms) || 10000; return this; };
                P.userAgent = function (ua) { this._ua = String(ua); return this; };
                P.referrer = function (r) { this._referrer = String(r); return this; };
                P.followRedirects = function (b) { return this; };
                P.sslSocketFactory = function () { return this; };
                P.execute = function () { return new Response(this._fetch(), this._url); };
                P.get = function () { this._method = 'GET'; return JsoupParse(this._fetch(), this._url); };
                P.post = function () { this._method = 'POST'; return JsoupParse(this._fetch(), this._url); };
                P._fetch = function () {
                    var url = this._url, pairs = [], hasData = false;
                    for (var k in this._data) { hasData = true; pairs.push(encodeURIComponent(k) + '=' + encodeURIComponent(this._data[k])); }
                    var dataStr = pairs.join('&');
                    if (this._method === 'POST' || this._method === 'PUT') {
                        var body = this._body || dataStr;
                        var hdrs = this._headers;
                        if (dataStr && !this._body && !hdrs['Content-Type']) hdrs['Content-Type'] = 'application/x-www-form-urlencoded';
                        var r = java.post(url, body, hdrs);
                        return (r && typeof r.body === 'function') ? r.body() : String(r || '');
                    }
                    if (hasData) url += (url.indexOf('?') < 0 ? '?' : '&') + dataStr;
                    return java.ajax(url);
                };
                function Response(body, url) { this._body = body || ''; this._url = url; }
                var RP = Response.prototype;
                RP.body = function () { return this._body; };
                RP.text = function () { return this._body; };
                RP.html = function () { return this._body; };
                RP.header = function (n) { return null; };
                RP.get = function (n) { return null; };
                RP.headers = function () { return { get: function () { return null; }, has: function () { return false; }, size: function () { return 0; } }; };
                RP.statusCode = function () { return 200; };
                RP.contentType = function () { return 'text/html'; };
                RP.url = function () { return this._url; };
                RP.parse = function () { return JsoupParse(this._body, this._url); };
                RP.statusMessage = function () { return 'OK'; };

                // `_n` is a native SwiftSoup node (`__yueduJsoup`). JavaScriptCore owns its
                // lifetime, so a selected element stays valid for as long as JS holds it —
                // serialising back to a string between calls would mangle fragments the HTML
                // parser is context-sensitive about (`<body>`, `<td>`, `<li>`, …).
                // Mutating methods stay no-ops: wrappers in this context reuse parsed documents.
                function Element(node, baseUrl) { this._n = node || null; this._baseUrl = baseUrl || ''; }
                function wrap(list, baseUrl) {
                    var out = [];
                    if (list) for (var i = 0; i < list.length; i++) out.push(new Element(list[i], baseUrl));
                    return new Elements(out);
                }
                var EP = Element.prototype;
                EP.html = function () { return this._n ? this._n.html() : ''; };
                EP.text = function () { return this._n ? this._n.text() : ''; };
                EP.ownText = function () { return this._n ? this._n.ownText() : ''; };
                EP.outerHtml = function () { return this._n ? this._n.outerHtml() : ''; };
                EP.toString = function () { return this.outerHtml(); };
                // A rule's JS result reaches the rule engine as JSON. Rhino hands Legado the
                // jsoup node itself, whose string form is its outer HTML; the rule engine's own
                // list extraction represents an element the same way (JsoupDefaultExtractor).
                EP.toJSON = function () { return this.outerHtml(); };
                EP.attr = function (k, v) { if (arguments.length === 2) { return this; } return this._n ? this._n.attr(String(k)) : ''; };
                EP.select = function (q) { return wrap(this._n ? this._n.select(String(q)) : [], this._baseUrl); };
                // jsoup `Element.selectFirst`: the first match, or null. jsoup 1.16.2 (the
                // version every Legado fork pins) has no `Elements.selectFirst`, so neither do we.
                EP.selectFirst = function (q) { return this.select(q).first(); };
                EP.first = function () { return null; };
                EP.last = function () { return null; };
                EP.children = function () { return wrap(this._n ? this._n.children() : [], this._baseUrl); };
                EP.child = function (i) { return this.children().get(i); };
                EP.parent = function () { var p = this._n ? this._n.parent() : null; return p ? new Element(p, this._baseUrl) : null; };
                EP.nextElementSibling = function () { return null; };
                EP.previousElementSibling = function () { return null; };
                EP.appendChild = function (el) { return this; };
                EP.prependChild = function (el) { return this; };
                EP.remove = function () { return this; };
                EP.tagName = function () { return (this._n ? this._n.tagName() : '') || 'div'; };
                EP.nodeName = function () { return this.tagName(); };
                EP.id = function () { return this._n ? this._n.id() : ''; };
                EP.className = function () { return this._n ? this._n.className() : ''; };
                EP.hasClass = function (c) { return (' ' + this.className() + ' ').indexOf(' ' + c + ' ') >= 0; };
                EP.getElements = function () { return this.select('*'); };
                EP.getAllElements = function () { return this.select('*'); };
                EP.getElementById = function (id) { return this.select('#' + id).first(); };
                EP.getElementsByClass = function (c) { return this.select('.' + c); };
                EP.getElementsByTag = function (t) { return this.select(String(t)); };
                EP.getElementsByAttribute = function (a) { return this.select('[' + a + ']'); };
                EP.getElementsByAttributeValue = function (a, v) { return this.select('[' + a + '="' + v + '"]'); };
                EP.getElementsByAttributeValueContaining = function (a, v) { return this.select('[' + a + '*="' + v + '"]'); };
                EP.absUrl = function (k) { return this.attr(k); };
                EP.baseUri = function () { return this._baseUrl; };
                EP.parentNode = function () { return this.parent(); };
                EP.wholeText = function () { return this.text(); };
                EP.data = function () { return ''; };
                EP.val = function () { return this.attr('value'); };
                EP.textNode = function () { return this.text(); };
                EP.hasAttr = function (k) { return this._n ? this._n.hasAttr(String(k)) : false; };
                EP.removeAttr = function () { return this; };

                // jsoup's Elements is a java.util.ArrayList, and Rhino lets Legado scripts use it
                // as one: `els[0]`, `els.toArray()`, and `for (i in els)` over its indices
                // (🥝猕猴桃漫画's explore rule does all three). The elements are the wrapper's
                // own index properties; `_arr` and every method are non-enumerable, so for-in
                // sees the indices and nothing else. An Elements is never mutated after this.
                function Elements(arr) {
                    arr = arr || [];
                    Object.defineProperty(this, '_arr', { value: arr });
                    for (var i = 0; i < arr.length; i++) this[i] = arr[i];
                }
                var ESP = Elements.prototype;
                ESP.size = function () { return this._arr.length; };
                ESP.size2 = function () { return this._arr.length; };
                Object.defineProperty(ESP, 'length', { get: function () { return this._arr.length; }, configurable: true });
                ESP.get = function (i) { return this._arr[i] || null; };
                ESP.toArray = function () { return this._arr.slice(); };
                ESP.first = function () { return this._arr[0] || null; };
                ESP.last = function () { return this._arr[this._arr.length - 1] || null; };
                ESP.text = function () { return this._arr.map(function (e) { return e.text(); }).join(''); };
                ESP.html = function () { return this._arr.map(function (e) { return e.html(); }).join(''); };
                ESP.each = function (fn) { this._arr.forEach(fn); return this; };
                ESP.forEach = function (fn) { this._arr.forEach(fn); return this; };
                ESP.attr = function () { return this._arr[0] ? this._arr[0].attr.apply(this._arr[0], arguments) : ''; };
                ESP.hasAttr = function (k) { return this._arr.some(function (e) { return e.hasAttr(k); }); };
                ESP.select = function (q) {
                    var out = [];
                    this._arr.forEach(function (e) { e.select(q).each(function (m) { out.push(m); }); });
                    return new Elements(out);
                };
                ESP.outerHtml = function () { return this._arr.map(function (e) { return e.outerHtml(); }).join(''); };
                ESP.toString = function () { return this.outerHtml(); };
                // Legado's list rules take a returned jsoup Elements as the list itself
                // (AnalyzeRule.getElements). As JSON it is the array of its elements, so a
                // chapterList ending in `doc.select(…)` yields one row per element.
                ESP.toJSON = function () { return this._arr; };
                ESP.not = function () { return this; };
                ESP.eq = function (i) { return new Elements([this._arr[i]]); };
                ESP.is = function () { return false; };
                ESP.empty = function () { return this._arr.length === 0; };
                ESP.iterator = function () { return this._arr[Symbol.iterator](); };
                ESP[Symbol.iterator] = function () { return this._arr[Symbol.iterator](); };
                Object.keys(ESP).forEach(function (k) { Object.defineProperty(ESP, k, { enumerable: false }); });

                function Document(node, baseUrl) { Element.call(this, node, baseUrl); }
                Document.prototype = Object.create(Element.prototype);
                Document.prototype.constructor = Document;
                Document.prototype.body = function () { var b = this._n ? this._n.body() : null; return new Element(b, this._baseUrl); };
                Document.prototype.head = function () { return this.select('head').first() || new Element(null, this._baseUrl); };
                Document.prototype.title = function () { return this._n ? this._n.title() : ''; };
                Document.prototype.setBaseUri = function () { return this; };
                Document.prototype.outputSettings = function () { return this; };

                function JsoupParse(html, baseUrl) {
                    return new Document(__yueduJsoup.parse(html == null ? '' : String(html), baseUrl), baseUrl);
                }

                var Method = { GET: 'GET', POST: 'POST', HEAD: 'HEAD', PUT: 'PUT', DELETE: 'DELETE', OPTIONS: 'OPTIONS', PATCH: 'PATCH', TRACE: 'TRACE' };

                this.org = {
                    jsoup: {
                        Jsoup: { connect: function (url) { return new Connection(url); }, parse: function (h, b) { return JsoupParse(h, b); }, parseBodyFragment: function (h, b) { return JsoupParse(h, b); }, clean: function (h) { return h; } },
                        Connection: { Method: Method, Response: Response, KeyVal: { create: function (k, v) { return { key: function () { return k; }, value: function () { return v; } }; } } },
                        nodes: { Document: Document, Element: Element, TextNode: Element },
                        safety: { Clean: { clean: function (h) { return h; } } },
                        select: { Selector: { select: function (q, root) { return root ? root.select(q) : new Elements([]); } } },
                        parser: { Parser: { parse: function (h, b) { return JsoupParse(h, b); } } },
                        helper: { HttpConnection: { connect: function (url) { return new Connection(url); } } }
                    }
                };
            })();
        """)

        installExploreInfoMap(into: ctx)
    }

    // MARK: - Explore infoMap

    /// Legado's explore `infoMap`: one map per source that the explore page's buttons,
    /// inputs and toggles write and the source's JS reads — in its explore rule, its
    /// category URLs and its explore actions. Legado keeps it in `CacheManager` under
    /// `infoMap_<source URL>`; here it lives in the source's `cache` store under the same
    /// key, and the JS global `infoMap` is loaded from it whenever a context is set up or
    /// the source changes. `infoMap.save()` writes it back.
    private var exploreInfoMapKey: String? {
        bookSource.map { "infoMap_" + $0.bookSourceUrl }
    }

    private func installExploreInfoMap(into ctx: JSContext) {
        let stored = exploreInfoMapKey.flatMap { cacheBridge.get($0) } ?? "{}"
        let persist: @convention(block) (String) -> Void = { [weak self] json in
            guard let self, let key = self.exploreInfoMapKey else { return }
            self.cacheBridge.put(key, json)
        }
        ctx.setObject(persist, forKeyedSubscript: "__yueduPersistInfoMap" as NSString)
        ctx.setObject(stored, forKeyedSubscript: "__yueduStoredInfoMap" as NSString)
        ctx.evaluateScript("""
            (function () {
                var stored = {};
                try {
                    stored = JSON.parse(__yueduStoredInfoMap) || {};
                } catch (e) {
                    if (typeof java !== 'undefined' && java.log) java.log('infoMap: stored map is not JSON: ' + e);
                }
                var map = __yueduJavaMap(stored);
                Object.defineProperty(map, 'save', {
                    value: function () { __yueduPersistInfoMap(JSON.stringify(map)); return map; },
                    enumerable: false,
                    configurable: true
                });
                infoMap = map;
            })();
        """)
    }

    /// The source's explore `infoMap` as its JS holds it now, values as strings.
    func exploreInfoMapValues() -> [String: String] {
        onJSQueue {
            let json = context.evaluateScript(
                "JSON.stringify(typeof infoMap === 'undefined' ? {} : infoMap)"
            )?.toString() ?? "{}"
            do {
                guard let object = try JSONSerialization.jsonObject(with: Data(json.utf8)) as? [String: Any] else {
                    return [:]
                }
                return object.mapValues { value in
                    (value as? String) ?? (value is NSNull ? "" : "\(value)")
                }
            } catch {
                AppLogger.parse("Explore infoMap is not JSON", context: ["error": "\(error)"])
                return [:]
            }
        }
    }

    /// Sets one `infoMap` entry, as an explore input or toggle does, and saves the map.
    func setExploreInfoMapValue(_ value: String, forKey key: String) {
        onJSQueue {
            context.setObject(key, forKeyedSubscript: "__yueduInfoMapKey" as NSString)
            context.setObject(value, forKeyedSubscript: "__yueduInfoMapValue" as NSString)
            context.evaluateScript("infoMap.put(__yueduInfoMapKey, __yueduInfoMapValue); infoMap.save();")
        }
    }

    /// Some Legado/Rhino source scripts read current-chapter fields as bare globals
    /// (`title`, `url`, `index`) instead of going through `chapter.title`.
    /// JavaScriptCore does not synthesize those globals from the exported `chapter` object,
    /// so keep them explicitly mirrored whenever the chapter bridge changes.
    /// Restores Legado's arity overload of `java.get` (see the call site for why).
    /// Idempotent: re-running it re-binds the already-installed dispatcher, and it
    /// no-ops if the native `httpGet` is missing rather than clobbering `java.get`.
    private static func installJavaGetOverload(in ctx: JSContext) {
        ctx.evaluateScript("""
        (function () {
            if (typeof java === 'undefined' || typeof java.httpGet !== 'function') { return; }
            if (java.__yueduGetOverloaded) { return; }
            var storeGet = (typeof java.get === 'function')
                ? java.get.bind(java)
                : function () { return ''; };
            var httpGet = java.httpGet.bind(java);
            java.get = function (a, b) {
                return arguments.length >= 2 ? httpGet(String(a), b) : storeGet(String(a));
            };
            java.__yueduGetOverloaded = true;
        })();
        """)
    }

    private static func installJavaConnectOverload(in ctx: JSContext) {
        ctx.evaluateScript("""
        (function () {
            if (typeof java === 'undefined' || typeof java.connectWithOptions !== 'function') { return; }
            if (java.__yueduConnectOverloaded) { return; }
            var simpleConnect = java.connect.bind(java);
            var optionConnect = java.connectWithOptions.bind(java);
            java.connect = function (url, headers, timeout) {
                return arguments.length === 1
                    ? simpleConnect(String(url))
                    : optionConnect(String(url), headers == null ? null : headers, timeout == null ? null : timeout);
            };
            java.__yueduConnectOverloaded = true;
        })();
        """)
    }

    private static func installJavaHeadAndPostOverloads(in ctx: JSContext) {
        ctx.evaluateScript("""
        (function () {
            if (typeof java === 'undefined' || java.__yueduHeadPostOverloaded) { return; }
            if (typeof java.headWithOptions === 'function') {
                var simpleHead = java.head.bind(java);
                var optionHead = java.headWithOptions.bind(java);
                java.head = function (url, headers, timeout) {
                    return arguments.length < 3
                        ? simpleHead(String(url), headers)
                        : optionHead(String(url), headers, timeout);
                };
            }
            if (typeof java.postWithOptions === 'function') {
                var simplePost = java.post.bind(java);
                var optionPost = java.postWithOptions.bind(java);
                java.post = function (url, body, headers, timeout) {
                    return arguments.length < 4
                        ? simplePost(String(url), String(body), headers)
                        : optionPost(String(url), String(body), headers, timeout);
                };
            }
            java.__yueduHeadPostOverloaded = true;
        })();
        """)
    }

    private func injectChapterGlobals(_ bridge: LegadoChapterBridge, into ctx: JSContext) {
        ctx.setObject(bridge.title, forKeyedSubscript: "title" as NSString)
        ctx.setObject(bridge.title, forKeyedSubscript: "chapterTitle" as NSString)
        ctx.setObject(bridge.url, forKeyedSubscript: "url" as NSString)
        ctx.setObject(bridge.url, forKeyedSubscript: "chapterUrl" as NSString)
        ctx.setObject(bridge.index, forKeyedSubscript: "index" as NSString)
        ctx.setObject(bridge.index, forKeyedSubscript: "chapterIndex" as NSString)
        ctx.setObject(bridge.order, forKeyedSubscript: "order" as NSString)
        ctx.setObject(bridge.order, forKeyedSubscript: "chapterOrder" as NSString)
        ctx.setObject(bridge.isVip(), forKeyedSubscript: "isVip" as NSString)
    }

    /// Inject `source` as a Legado-compatible bridge object with methods and properties.
    private func injectSourceObject(into ctx: JSContext) {
        ctx.setObject(sourceBridge, forKeyedSubscript: "source" as NSString)
    }

    private func setResult(_ result: Any?) {
        guard let result else {
            context.setObject(NSNull(), forKeyedSubscript: "result" as NSString)
            return
        }
        if let string = result as? String,
           Self.jsonObjectIfPossible(from: string) != nil,
           let wrapper = context.objectForKeyedSubscript("__yueduWrapJSONResult"),
           let wrapped = wrapper.call(withArguments: [string]),
           !wrapped.isUndefined {
            context.setObject(wrapped, forKeyedSubscript: "result" as NSString)
            return
        }
        // Values extracted by Swift rule evaluators arrive here as Foundation
        // arrays/dictionaries. JavaScriptCore exposes those as Obj-C collection
        // proxies rather than native JS values, so they do not inherit the
        // java.util.List compatibility methods installed on Array.prototype.
        // Legado/Rhino exposes the same intermediate list as a mutable Java List;
        // rules such as 番茄酱's `result.add("有声书")` must therefore be able to
        // mutate it. Re-enter through JSON only for JSON-safe value collections;
        // bridge objects such as LegadoStrResponse keep their native identity.
        if JSONSerialization.isValidJSONObject(result),
           let data = try? JSONSerialization.data(withJSONObject: result),
           let raw = String(data: data, encoding: .utf8),
           let wrapper = context.objectForKeyedSubscript("__yueduWrapJSONResult"),
           let wrapped = wrapper.call(withArguments: [raw]),
           !wrapped.isUndefined {
            context.setObject(wrapped, forKeyedSubscript: "result" as NSString)
            return
        }
        context.setObject(result, forKeyedSubscript: "result" as NSString)
    }

    private static func jsonObjectIfPossible(from string: String) -> Any? {
        let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.hasPrefix("{") || trimmed.hasPrefix("["),
              let data = trimmed.data(using: .utf8) else { return nil }
        return try? JSONSerialization.jsonObject(with: data, options: .fragmentsAllowed)
    }

    /// Parse a Legado header string (JSON object, `@js:`/`<js>` rule, or
    /// "Key: Value\nKey2: Value2") into a dictionary.
    ///
    /// Mirrors `BaseSource.getHeaderMap()`: a header rule may be JS that *builds*
    /// the map (书山聚合 emits `java.getWebViewUA()` plus a constant API token that
    /// its server requires on every endpoint). Evaluating it here is what makes
    /// those headers reach the request at all.
    func parseHeaders(_ headerStr: String) -> [String: String] {
        let trimmed = headerStr.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [:] }
        if let script = Self.headerJSScript(trimmed) {
            let evaluated = (evaluateHeaderScript(script) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            guard !evaluated.isEmpty, let data = evaluated.data(using: .utf8),
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: String] else {
                // A JS header rule that fails must yield nothing: the line-format
                // fallback below would otherwise mine the *script text* for colons
                // and emit junk headers such as `"User-Agent": java.getWebViewUA(),`.
                AppLogger.parse("header JS produced no header map", context: [
                    "rule": String(trimmed.prefix(120)),
                    "result": String(evaluated.prefix(120)),
                    "jsError": lastError ?? "-"
                ])
                return [:]
            }
            return json
        }
        if let data = trimmed.data(using: .utf8),
           let json = try? JSONSerialization.jsonObject(with: data) as? [String: String] {
            return json
        }
        // Fallback: "Key: Value" line format
        var result: [String: String] = [:]
        trimmed.components(separatedBy: "\n").forEach { line in
            let parts = line.split(separator: ":", maxSplits: 1).map {
                $0.trimmingCharacters(in: .whitespaces)
            }
            if parts.count == 2 { result[parts[0]] = parts[1] }
        }
        return result
    }

    /// Every fork evaluates a header rule through `BaseSource.evalJS`, which binds `baseUrl`
    /// to the source URL (`getKey()`); a header script reading it here hit a ReferenceError.
    /// A header rule can be resolved while another rule is running — the first `java.ajax`
    /// of a TOC script — so the global is put back afterwards and that rule keeps its own
    /// `baseUrl`.
    private func evaluateHeaderScript(_ script: String) -> String? {
        onJSQueue { [self] () -> String? in
            let global: JSValue = context.globalObject
            let hadBaseURL = global.hasProperty("baseUrl")
            let previous = global.forProperty("baseUrl")
            global.setValue(bookSource?.bookSourceUrl ?? "", forProperty: "baseUrl")
            defer {
                if hadBaseURL {
                    global.setValue(previous, forProperty: "baseUrl")
                } else {
                    global.deleteProperty("baseUrl")
                }
            }
            return evaluate(script)
        }
    }

    /// The JS body of a `@js:` / `<js>…</js>` header rule, or nil for a plain header.
    static func headerJSScript(_ headerStr: String) -> String? {
        let trimmed = headerStr.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasPrefix("@js:") {
            return String(trimmed.dropFirst(4))
        }
        if trimmed.lowercased().hasPrefix("<js>"),
           let close = trimmed.range(of: "</js>", options: [.caseInsensitive, .backwards]) {
            return String(trimmed[trimmed.index(trimmed.startIndex, offsetBy: 4)..<close.lowerBound])
        }
        return nil
    }

    /// Extract a usable String from a JSValue, returning nil for undefined/null/error.
    private func extractString(from value: JSValue) -> String? {
        if lastError != nil { return nil }
        if value.isUndefined || value.isNull { return nil }

        // Arrays and objects → JSON string.
        // Uses JavaScriptCore's own JSON.stringify instead of NSJSONSerialization,
        // because NSJSONSerialization raises an *uncatchable* ObjC exception
        // (NSInvalidArgumentException) for values that JS bridges as non-JSON-safe
        // objects (Map, Set, Proxy, functions with custom toJSON, etc.).
        // JSON.stringify returns `undefined` for unserialisable values, which we
        // fall through from gracefully.
        if value.isArray || value.isObject {
            guard let ctx = value.context else { return value.toString() }
            ctx.setObject(value, forKeyedSubscript: "__yuedu_jsonify" as NSString)
            let jsonVal = ctx.evaluateScript("JSON.stringify(__yuedu_jsonify)")
            ctx.evaluateScript("delete __yuedu_jsonify")
            if let jsonVal,
               !jsonVal.isUndefined, !jsonVal.isNull,
               let json = jsonVal.toString(), !json.isEmpty {
                // An object whose JSON form is a string stands in for a Java object that
                // Rhino would hand Legado as its `toString()`: a jsoup Element (its outer
                // HTML) or a `java.lang.String` (a boxed JS string). Return that string, not
                // a quoted JSON literal. JSON.stringify's own output always parses.
                if json.hasPrefix("\""),
                   let data = json.data(using: .utf8),
                   let string = try? JSONSerialization.jsonObject(with: data, options: .fragmentsAllowed) as? String {
                    return string
                }
                return json
            }
        }

        return value.toString()
    }
}
