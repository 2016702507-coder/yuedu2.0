// Port of Legado's BaseSource login system.
// Manages book-source authentication: login execution, cookie/header
// persistence, and login-check evaluation.

import Foundation
import Security
import JavaScriptCore
import os

extension Notification.Name {
    /// Posted after a source's stored login information changes. Consumers use
    /// the source URL in `userInfo` to invalidate only that source's runtime.
    static let bookSourceLoginInfoDidChange = Notification.Name(
        "bookSourceLoginInfoDidChange"
    )
}

// MARK: - Login State

/// Represents the authentication state of a book source.
enum LoginState: Equatable {
    case notRequired
    case loggedIn
    case loggedOut
    case failed(String)

    static func == (lhs: LoginState, rhs: LoginState) -> Bool {
        switch (lhs, rhs) {
        case (.notRequired, .notRequired),
             (.loggedIn, .loggedIn),
             (.loggedOut, .loggedOut):
            return true
        case (.failed(let a), .failed(let b)):
            return a == b
        default:
            return false
        }
    }
}

// MARK: - Login Field (Legado RowUi)

/// A single field in a login form, parsed from the source's `loginUi` JSON.
/// Mirrors Legado's `RowUi` data class. The one model behind both the book-source
/// and TTS login sheets.
struct LoginField: Identifiable, Equatable {
    let name: String
    let type: LoginFieldType
    let action: String?
    let options: [String]
    let defaultValue: String?
    /// Grid/layout hints from the row's `style` object, `nil` when absent.
    let style: LoginFieldStyle?
    /// Legado's `viewName`: a quoted literal label, or a JS expression to evaluate.
    let viewName: String?

    var id: String { name }

    enum LoginFieldType: String {
        case text     = "text"
        case password = "password"
        case select   = "select"
        case button   = "button"
        case toggle   = "toggle"
    }

    /// The label Legado authors literally: a short `viewName` wrapped in single quotes
    /// (length 3...19, matching the Android app's check) is shown as-is.
    var literalViewName: String? {
        guard let viewName else { return nil }
        let length = viewName.utf16.count
        guard length >= 3, length <= 19,
              viewName.hasPrefix("'"), viewName.hasSuffix("'")
        else { return nil }
        return String(viewName.dropFirst().dropLast())
    }

    /// A `viewName` that is neither absent nor a quoted literal has to be evaluated as
    /// JS in the source's login context before it can be displayed.
    var hasDynamicViewName: Bool {
        viewName != nil && literalViewName == nil
    }
}

extension Array where Element == LoginField {
    /// Labels available without running JS, keyed by field name.
    var literalViewNames: [String: String] {
        Dictionary(
            compactMap { field in
                field.literalViewName.map { (field.name, $0) }
            },
            uniquingKeysWith: { first, _ in first }
        )
    }

    var hasDynamicViewNames: Bool {
        contains { $0.hasDynamicViewName }
    }
}

// MARK: - Toggle chars (Legado `chars` on a `toggle` row)

/// The two strings a `toggle` row switches between, taken from its `chars`.
///
/// A `toggle` stores its current char as the field's value — nothing else. The
/// source reads it straight back: 同人小说网's `qdToggle()` fetches the value via
/// `source.getLoginInfoMap()` and calls the switch on when it equals `"✅"`
/// (its `chars` are `["🔳", "✅"]`, off first).
struct LoginToggleChars {
    let off: String
    let on: String

    /// Only a two-state `chars` is a switch; anything else has to be rendered as
    /// a list of choices instead.
    init?(options: [String]) {
        guard options.count == 2 else { return nil }
        off = options[0]
        on = options[1]
    }

    /// Whether the switch reads as on, given what is stored and what the source
    /// declared as `default`.
    ///
    /// The declared default is for display only — it must never be written back.
    /// 同人小说网 declares `default: "🔳"` for 段评开关 while its own
    /// `qdToggle("段评开关", true)` treats a *missing* value as on, so persisting
    /// the default would silently turn 段评 off for everyone who opens the menu.
    func isOn(stored: String?, default defaultValue: String?) -> Bool {
        let value = (stored?.isEmpty == false ? stored : defaultValue) ?? ""
        return value == on
    }

    func value(isOn: Bool) -> String { isOn ? on : off }
}

// MARK: - Login Error

enum LoginError: LocalizedError {
    case noLoginUrl
    case invalidLoginUrl(String)
    case networkError(Error)
    case loginFunctionMissing
    case javaScriptError(String)
    case httpError(Int)

    var errorDescription: String? {
        switch self {
        case .noLoginUrl:
            return "Book source has no loginUrl configured."
        case .invalidLoginUrl(let url):
            return "Invalid login URL: \(url)"
        case .networkError(let err):
            return "Network error during login: \(err.localizedDescription)"
        case .loginFunctionMissing:
            return "loginUrl JS does not define a login() function."
        case .javaScriptError(let msg):
            return "Login JS error: \(msg)"
        case .httpError(let code):
            return "Login request returned HTTP \(code)."
        }
    }
}

// MARK: - LoginManager

/// Singleton that manages book-source authentication.
///
/// Mirrors Legado's `BaseSource` login helpers:
/// - `getLoginHeader` / `putLoginHeader` / `removeLoginHeader`
/// - `getLoginInfo` / `putLoginInfo`
/// - `login()` — evaluates loginUrl JS
/// - `loginCheckJs` — post-response check evaluated by the caller
///
/// Cookie and header data are persisted via UserDefaults keyed by the
/// source's `bookSourceUrl`.
final class LoginManager: Sendable {

    static let shared = LoginManager()

    // MARK: - Storage Keys (mirrors Legado CacheManager keys)

    private static let loginHeaderPrefix = "loginHeader_"
    private static let loginInfoPrefix   = "userInfo_"
    private static let suiteName         = "com.yuedu.loginStore"

    /// Dedicated UserDefaults suite so login data is isolated. Resolved per use rather than
    /// stored: `UserDefaults` is not `Sendable`, and the suite is only touched on writes and
    /// on the legacy-credential fallback, never on the header read path.
    private var defaults: UserDefaults { UserDefaults(suiteName: LoginManager.suiteName) ?? .standard }

    /// In-memory cache of the raw `putLoginHeader` payload keyed by source URL.
    ///
    /// Legado's `BaseSource.putLoginHeader` stores the string *verbatim* and only
    /// `getLoginHeaderMap()` (a GSON object parse) turns it into request headers.
    /// That distinction matters: 书山聚合 stores a bare API key here and reads it
    /// back through `source.getLoginHeader()` to build `?key=` URLs — it must never
    /// be sent as an HTTP header, because guessing a header name for it overwrites
    /// the constant token the source's own `header` rule sends.
    ///
    /// `loginInfoRevisions` is a monotonically increasing revision for credential-dependent
    /// JS rules. It is intentionally separate from the credential value so it can invalidate
    /// request-header caches without exposing the token.
    private struct State: Sendable {
        var headerCache: [String: String]
        var loginInfoRevisions: [String: UInt64] = [:]
    }

    /// Guards the caches. Writes persist inside the lock, as the barrier queue it replaced
    /// did, so the cache and the stored copy never disagree.
    private let state: OSAllocatedUnfairLock<State>

    // MARK: - Init

    private init() {
        let defaults = UserDefaults(suiteName: LoginManager.suiteName) ?? .standard
        state = OSAllocatedUnfairLock(initialState: State(headerCache: Self.loadAllHeaders(from: defaults)))
    }

    // MARK: - Login Check

    /// Whether the source has a `loginUrl` configured (i.e., *could* require login).
    func requiresLogin(source: BookSource) -> Bool {
        return !source.loginUrl.isEmpty
    }

    /// Evaluate the source's `loginCheckJs` against a response body.
    ///
    /// Legado runs `loginCheckJs` after every network response; if it
    /// returns a *modified* response (e.g. with login-redirect handled)
    /// the caller should use that instead.
    ///
    /// - Parameters:
    ///   - source: The book source.
    ///   - responseBody: The raw HTTP response body.
    ///   - jsEngine: A configured `JSCoreEngine`.
    /// - Returns: Possibly-modified response body, or the original if
    ///   no loginCheckJs is configured.
    func evaluateLoginCheck(
        source: BookSource,
        responseBody: String,
        jsEngine: JSCoreEngine
    ) -> String {
        let checkJs = source.loginCheckJs.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !checkJs.isEmpty else { return responseBody }

        let bindings: [String: Any] = [
            "result": responseBody,
            "baseUrl": source.bookSourceUrl,
            "source": sourceBindings(for: source)
        ]
        if let modified = jsEngine.evaluate(checkJs, bindings: bindings) {
            return modified
        }
        return responseBody
    }

    // MARK: - Login Execution

    /// Execute the source's login procedure.
    ///
    /// Legado's `login()` extracts JS from `loginUrl` (stripping the
    /// `@js:` or `<js>…</js>` wrapper), appends a call to a user-
    /// defined `login()` function, and evaluates the whole thing.
    ///
    /// For simple-URL sources the loginUrl is fetched directly via
    /// URLSession; for JS-based sources the JS engine handles everything.
    func login(
        source: BookSource,
        credentials: [String: String] = [:],
        jsEngine: JSCoreEngine
    ) async throws -> LoginState {
        let raw = source.loginUrl.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return .notRequired }

        // Store credential info so JS can access it via source.getLoginInfo()
        if !credentials.isEmpty {
            storeLoginInfo(sourceUrl: source.bookSourceUrl, info: credentials)
        }

        let loginJs = extractLoginJs(raw)

        if let loginJs = loginJs {
            // JS-based login (Legado convention)
            return try executeJsLogin(
                source: source,
                loginJs: loginJs,
                jsEngine: jsEngine
            )
        } else {
            // Simple URL login — substitute credentials and fetch
            return try await executeUrlLogin(
                source: source,
                rawUrl: raw,
                credentials: credentials
            )
        }
    }

    // MARK: - JS Login

    /// Execute a JS-based login.
    ///
    /// Mirrors Legado `BaseSource.login()`:
    /// ```kotlin
    /// val js = "$loginJs\nif(typeof login=='function'){ login.apply(this); }"
    /// evalJS(js)
    /// ```
    private func executeJsLogin(
        source: BookSource,
        loginJs: String,
        jsEngine: JSCoreEngine
    ) throws -> LoginState {
        let wrappedJs = """
        \(loginJs)
        if (typeof login === 'function') {
            login.apply(this);
        } else {
            throw('Function login not implements!!!');
        }
        """

        let bindings: [String: Any] = [
            "baseUrl": source.bookSourceUrl,
            "source": sourceBindings(for: source)
        ]

        let result = jsEngine.evaluate(wrappedJs, bindings: bindings)

        if let err = jsEngine.lastError {
            if err.contains("Function login not implements") {
                throw LoginError.loginFunctionMissing
            }
            throw LoginError.javaScriptError(err)
        }

        // If the JS set a login header we consider it successful.
        if let resultStr = result, !resultStr.isEmpty {
            // Attempt to store it as login header (Legado convention).
            if let data = resultStr.data(using: .utf8),
               let dict = try? JSONSerialization.jsonObject(with: data) as? [String: String] {
                storeLoginHeaders(sourceUrl: source.bookSourceUrl, headers: dict)
            }
        }

        return .loggedIn
    }

    // MARK: - Simple URL Login

    /// Fetch a loginUrl directly (non-JS path).
    private func executeUrlLogin(
        source: BookSource,
        rawUrl: String,
        credentials: [String: String]
    ) async throws -> LoginState {
        var urlString = rawUrl

        // Replace `{{key}}` placeholders with credential values.
        for (key, value) in credentials {
            urlString = urlString.replacingOccurrences(
                of: "{{\(key)}}",
                with: value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? value
            )
        }

        guard let url = URL(string: urlString) else {
            throw LoginError.invalidLoginUrl(urlString)
        }

        var request = URLRequest(url: url)
        request.timeoutInterval = 30

        // Apply source-level headers.
        if let headerData = source.header.data(using: .utf8),
           let headerDict = try? JSONSerialization.jsonObject(with: headerData) as? [String: String] {
            for (k, v) in headerDict {
                request.setValue(v, forHTTPHeaderField: k)
            }
        }

        let (_, response): (Data, URLResponse)
        do {
            (_, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw LoginError.networkError(error)
        }

        guard let http = response as? HTTPURLResponse else {
            return .failed("Non-HTTP response")
        }

        guard (200..<400).contains(http.statusCode) else {
            throw LoginError.httpError(http.statusCode)
        }

        // Capture Set-Cookie from the response.
        let cookies = extractCookies(from: http)
        if !cookies.isEmpty {
            var headers = getLoginHeaders(sourceUrl: source.bookSourceUrl)
            let cookieString = cookies.map { "\($0.key)=\($0.value)" }.joined(separator: "; ")
            headers["Cookie"] = cookieString
            storeLoginHeaders(sourceUrl: source.bookSourceUrl, headers: headers)
        }

        return .loggedIn
    }

    // MARK: - Cookie Extraction

    /// Extract cookies from an HTTP response's `Set-Cookie` headers.
    private func extractCookies(from response: HTTPURLResponse) -> [String: String] {
        var result: [String: String] = [:]
        guard let headerFields = response.allHeaderFields as? [String: String],
              let url = response.url else { return result }

        let cookies = HTTPCookie.cookies(withResponseHeaderFields: headerFields, for: url)
        for cookie in cookies {
            result[cookie.name] = cookie.value
        }
        return result
    }

    // MARK: - Login URL JS Extraction (mirrors Legado getLoginJs)

    /// Extract the JS body from a loginUrl string.
    /// Returns `nil` if the loginUrl is a plain URL (not JS).
    func extractLoginJs(_ loginUrl: String) -> String? {
        let trimmed = loginUrl.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasPrefix("@js:") {
            return String(trimmed.dropFirst(4))
        }
        if trimmed.hasPrefix("<js>") {
            if let endRange = trimmed.range(of: "</js>", options: .backwards) {
                return String(trimmed[trimmed.index(trimmed.startIndex, offsetBy: 4)..<endRange.lowerBound])
            }
            return String(trimmed.dropFirst(4))
        }
        if trimmed.hasPrefix("//"), trimmed.contains("\n") {
            return trimmed
        }
        // If it looks like JS code (contains function definitions / statements)
        // rather than a URL, treat it as JS. Legado does this implicitly.
        if !trimmed.hasPrefix("http://") && !trimmed.hasPrefix("https://") && !trimmed.hasPrefix("/") {
            // Heuristic: contains function keyword or multi-line
            if trimmed.contains("function ") || trimmed.contains("\n") {
                return trimmed
            }
        }
        return nil
    }

    // MARK: - Login UI Parsing

    /// Parse the source's `loginUi` JSON into an array of `LoginField`.
    ///
    /// Legado format. Example: `[{"name":"用户名(username)","type":"text"},{"name":"密码(password)","type":"password"}]`
    func parseLoginUi(_ loginUiJson: String) -> [LoginField] {
        parseLoginUiResult(loginUiJson) ?? []
    }

    /// The result-preserving variant: `nil` means the JSON itself was unusable, while
    /// a valid `[]` is an intentionally empty menu. Callers that must distinguish a
    /// parse failure from an empty form (the login sheets, and the tests) use this.
    func parseLoginUiResult(_ loginUiJson: String) -> [LoginField]? {
        guard let array = LoginManager.lenientJSONArray(loginUiJson) else { return nil }

        return array.compactMap { dict in
            guard let name = dict["name"] as? String, !name.isEmpty else { return nil }
            let typeStr = dict["type"] as? String ?? "text"
            let type = LoginField.LoginFieldType(rawValue: typeStr) ?? .text
            let action = dict["action"] as? String
            return LoginField(
                name: name,
                type: type,
                action: action,
                options: Self.stringArray(dict["chars"]),
                defaultValue: Self.stringValue(dict["default"]),
                style: LoginFieldStyle.parse(dict["style"]),
                viewName: dict["viewName"] as? String
            )
        }
    }

    private static func stringArray(_ value: Any?) -> [String] {
        guard let array = value as? [Any] else { return [] }
        return array.compactMap(stringValue)
    }

    private static func stringValue(_ value: Any?) -> String? {
        switch value {
        case let string as String:
            return string
        case let number as NSNumber:
            return number.stringValue
        case let value?:
            return String(describing: value)
        case nil:
            return nil
        }
    }

    /// Parse a possibly-lenient JSON array of objects.
    ///
    /// Legado's `loginUi` (and some other fields) are authored as JavaScript
    /// object literals rather than strict JSON — single-quoted keys/values and
    /// trailing commas are common (e.g. the 大灰狼/光遇 aggregation sources).
    /// Strict `JSONSerialization` rejects those, so we first try strict JSON and,
    /// on failure, normalize the literal through JavaScriptCore (mirroring the
    /// lenient GSON parsing Legado uses on Android).
    static func lenientJSONArray(_ raw: String) -> [[String: Any]]? {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        if let data = trimmed.data(using: .utf8),
           let array = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            return array
        }

        guard let normalized = normalizeJSLiteral(trimmed),
              let data = normalized.data(using: .utf8),
              let array = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
            return nil
        }
        return array
    }

    /// Evaluate a JS array/object literal and re-emit it as canonical JSON.
    private static func normalizeJSLiteral(_ literal: String) -> String? {
        let context = JSContext()
        context?.exceptionHandler = { _, _ in }
        context?.setObject(literal, forKeyedSubscript: "__legadoLiteral" as NSString)
        // Wrap in parens so a leading `[`/`{` parses as an expression, and stringify.
        let script = "(function(){try{return JSON.stringify(eval('('+__legadoLiteral+')'));}catch(e){return '';}})()"
        guard let value = context?.evaluateScript(script),
              value.isString,
              let result = value.toString(),
              !result.isEmpty, result != "undefined", result != "null" else {
            return nil
        }
        return result
    }

    // MARK: - Login Header Management (mirrors Legado BaseSource)

    /// Headers to attach to requests — the stored payload parsed as a JSON object.
    /// A non-object payload (bare token) contributes nothing, matching Legado.
    func getLoginHeaders(sourceUrl: String) -> [String: String] {
        getLoginHeaderMap(sourceUrl: sourceUrl) ?? [:]
    }

    /// Retrieve the raw stored payload (Legado `getLoginHeader()`).
    func getLoginHeader(sourceUrl: String) -> String? {
        state.withLock { $0.headerCache[sourceUrl] }
    }

    /// Retrieve login headers as a map (Legado `getLoginHeaderMap()`):
    /// `nil` unless the stored payload is a JSON object of string values.
    func getLoginHeaderMap(sourceUrl: String) -> [String: String]? {
        guard let raw = getLoginHeader(sourceUrl: sourceUrl),
              let data = raw.data(using: .utf8),
              let dict = try? JSONSerialization.jsonObject(with: data) as? [String: String],
              !dict.isEmpty
        else { return nil }
        return dict
    }

    /// Store the raw `putLoginHeader` payload verbatim (Legado semantics).
    func storeLoginHeader(sourceUrl: String, raw: String) {
        let changed = state.withLock { state in
            let changed = state.headerCache[sourceUrl] != raw
            state.headerCache[sourceUrl] = raw
            persistHeader(sourceUrl: sourceUrl, raw: raw)
            return changed
        }
        if changed {
            // Source JS commonly calls `putLoginHeader()` and immediately issues
            // `java.ajax()` in the same evaluation (书旗's Token/GetUrl flow).
            // Keep the write synchronous and invalidate credential-dependent
            // header rules before that next request is constructed.
            markLoginInfoChanged(sourceUrl: sourceUrl)
        }
    }

    /// Store a header dictionary (serialized to the JSON form Legado expects).
    func storeLoginHeaders(sourceUrl: String, headers: [String: String]) {
        guard let data = try? JSONSerialization.data(withJSONObject: headers),
              let json = String(data: data, encoding: .utf8) else { return }
        storeLoginHeader(sourceUrl: sourceUrl, raw: json)
    }

    /// Remove all login data for a source (Legado `removeLoginHeader`).
    func clearLogin(sourceUrl: String) {
        state.withLock { state in
            state.headerCache.removeValue(forKey: sourceUrl)
            defaults.removeObject(
                forKey: LoginManager.loginHeaderPrefix + sourceUrl
            )
            // loginInfo is stored in Keychain; also clear any legacy UserDefaults entry
            KeychainHelper.delete(account: LoginManager.loginInfoPrefix + sourceUrl)
            defaults.removeObject(
                forKey: LoginManager.loginInfoPrefix + sourceUrl
            )
        }
        markLoginInfoChanged(sourceUrl: sourceUrl)
    }

    /// Removes only the stored login header payload for a source, keeping the
    /// credentials (Legado `source.removeLoginHeader()` — the 删除登录头 menu item).
    func removeLoginHeader(sourceUrl: String) {
        state.withLock { state in
            state.headerCache.removeValue(forKey: sourceUrl)
            defaults.removeObject(
                forKey: LoginManager.loginHeaderPrefix + sourceUrl
            )
        }
        markLoginInfoChanged(sourceUrl: sourceUrl)
    }

    /// Apply stored login headers to a URLRequest.
    func applyLoginHeaders(to request: inout URLRequest, sourceUrl: String) {
        let headers = getLoginHeaders(sourceUrl: sourceUrl)
        for (key, value) in headers {
            request.setValue(value, forHTTPHeaderField: key)
        }
    }

    // MARK: - Login Info (Credential) Storage

    /// Store user-provided login credentials in the **Keychain** (Legado `putLoginInfo`).
    /// Passwords are never stored in UserDefaults — Keychain is the only accepted location
    /// for sensitive data on iOS.
    func storeLoginInfo(sourceUrl: String, info: [String: String]) {
        guard let data = try? JSONSerialization.data(withJSONObject: info),
              let json = String(data: data, encoding: .utf8) else { return }
        let previous = getLoginInfo(sourceUrl: sourceUrl)
        guard KeychainHelper.save(
            account: LoginManager.loginInfoPrefix + sourceUrl,
            data: json,
            accessibility: kSecAttrAccessibleAfterFirstUnlock
        ) else { return }
        if previous != info {
            markLoginInfoChanged(sourceUrl: sourceUrl)
        }
    }

    /// Revision of the credentials used by a source's dynamic header rule.
    /// This is safe to read from request workers and never returns credential data.
    func loginInfoRevision(sourceUrl: String) -> UInt64 {
        state.withLock { $0.loginInfoRevisions[sourceUrl] ?? 0 }
    }

    private func markLoginInfoChanged(sourceUrl: String) {
        state.withLock { $0.loginInfoRevisions[sourceUrl, default: 0] &+= 1 }
        NotificationCenter.default.post(
            name: .bookSourceLoginInfoDidChange,
            object: nil,
            userInfo: ["sourceURL": sourceUrl]
        )
    }

    /// Retrieve stored login credentials (Legado `getLoginInfo`).
    /// Reads from Keychain; migrates legacy UserDefaults data transparently on first access.
    func getLoginInfo(sourceUrl: String) -> [String: String]? {
        let account = LoginManager.loginInfoPrefix + sourceUrl

        // Primary: Keychain
        // TTS rules read this for every segment, including locked-screen playback and
        // authenticated chapter transitions. Keep it in Keychain, but allow access after
        // the first unlock; the default WhenUnlocked class made a saved MiMo key disappear
        // mid-session. load also migrates credentials saved by earlier app versions.
        if let json = KeychainHelper.load(account: account, accessibility: kSecAttrAccessibleAfterFirstUnlock),
           let data = json.data(using: .utf8),
           let dict = try? JSONSerialization.jsonObject(with: data) as? [String: String] {
            return dict
        }

        // Legacy: UserDefaults (migrate and remove)
        if let json = defaults.string(forKey: account),
           let data = json.data(using: .utf8),
           let dict = try? JSONSerialization.jsonObject(with: data) as? [String: String] {
            if KeychainHelper.save(account: account, data: json, accessibility: kSecAttrAccessibleAfterFirstUnlock) {
                defaults.removeObject(forKey: account)
            }
            return dict
        }

        return nil
    }

    // MARK: - Persistence Helpers

    private func persistHeader(sourceUrl: String, raw: String) {
        defaults.set(raw, forKey: LoginManager.loginHeaderPrefix + sourceUrl)
    }

    private static func loadAllHeaders(from defaults: UserDefaults) -> [String: String] {
        var headers: [String: String] = [:]
        for (key, value) in defaults.dictionaryRepresentation() {
            guard key.hasPrefix(LoginManager.loginHeaderPrefix),
                  let raw = value as? String
            else { continue }
            let sourceUrl = String(key.dropFirst(LoginManager.loginHeaderPrefix.count))
            headers[sourceUrl] = raw
        }
        return headers
    }

    // MARK: - Source Bindings for JS

    /// Build a lightweight dictionary that JS can access as `source.*`.
    private func sourceBindings(for source: BookSource) -> [String: Any] {
        var bindings: [String: Any] = [
            "bookSourceUrl": source.bookSourceUrl,
            "bookSourceName": source.bookSourceName,
            "loginUrl": source.loginUrl,
            "header": source.header
        ]
        if let info = getLoginInfo(sourceUrl: source.bookSourceUrl) {
            bindings["loginInfo"] = info
        }
        if let headerJson = getLoginHeader(sourceUrl: source.bookSourceUrl) {
            bindings["loginHeader"] = headerJson
        }
        return bindings
    }
}
